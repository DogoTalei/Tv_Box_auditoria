#!/bin/sh
# Ejecutar desde la terminal Android: bash instalar-termux.sh
set -eu
umask 077
TVBOX_SETUP_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
TVBOX_SETUP_MODE=${1:-instalar}
case "$TVBOX_SETUP_MODE" in
    instalar|--comprobar) ;;
    *) echo 'Uso: bash instalar-termux.sh [--comprobar]' >&2; exit 2 ;;
esac
if [ -z "${PREFIX:-}" ] || ! command -v pkg >/dev/null 2>&1; then
    echo 'Este instalador requiere Termux o un derivado con PREFIX y pkg.' >&2
    echo 'Otros entornos: consulta TERMUX.md para la instalación manual con Python.' >&2
    exit 1
fi
case "$TVBOX_SETUP_DIR" in
    /sdcard|/sdcard/*|/storage/*|/mnt/media_rw/*)
        echo 'Copia o extrae el proyecto dentro de tu HOME privado antes de instalarlo.' >&2
        echo 'El almacenamiento compartido de Android limita permisos y ejecución.' >&2
        exit 1 ;;
esac
if [ "$(id -u)" = 0 ]; then
    echo 'Ejecuta el instalador como usuario normal de Termux, sin su ni sudo.' >&2
    exit 1
fi
cd -- "$TVBOX_SETUP_DIR"
echo 'Dogo_Box_Tv · Firma: Dogo · Preparación para Termux'
echo 'Paquetes: python python-pip python-ensurepip-wheels android-tools tmux iproute2'
echo 'Interfaz Python: requirements.txt, en .venv (sin actualizar pip del sistema).'
if [ "$TVBOX_SETUP_MODE" = --comprobar ]; then
    echo 'Comprobación terminada; no se instalaron paquetes ni se modificó la configuración.'
    exit 0
fi
pkg update -y
pkg install -y python python-pip python-ensurepip-wheels android-tools tmux iproute2
TVBOX_SETUP_PYTHON=$(command -v python3 || command -v python)
"$TVBOX_SETUP_PYTHON" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else "Se requiere Python 3.10 o posterior.")'
if [ ! -x .venv/bin/python ]; then
    "$TVBOX_SETUP_PYTHON" -m venv .venv
fi
.venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
.venv/bin/python Dogo_Box_Tv.py --version
echo 'Instalación terminada. Inicio: bash iniciar.sh'
echo 'Diagnóstico: bash iniciar.sh doctor'
echo 'Ping es opcional: se usa el de Android si está disponible; también puedes descubrir por TCP.'
echo 'Consulta TERMUX.md para ADB por Wi-Fi, permisos de Android y directo con entorno gráfico.'
