# Validación de Dogo_Box_Tv 1.16.1

Firma: Dogo

Fechas: 2026-11-09 a 2026-11-11. Entorno: Linux, Python 3.14.8, ADB y scrcpy 4.1. Equipo del propietario conectado por ADB de red.

## Corrección del instalador y ping Android (1.16.1)

- El propietario comprobó en Termux real que el instalador 1.16.0 fallaba al no encontrar iputils. Las pruebas anteriores con pkg simulado no detectaban nombres de paquetes inexistentes; no constituían una validación contra su repositorio real.
- Se eliminó iputils de las dependencias y se corrigió el mensaje de instalación. El gestor simulado de las pruebas ahora rechaza ese paquete expresamente; el instalador corregido completa su flujo sin solicitarlo.
- Tres pruebas nuevas verifican detección de /system/bin/ping fuera de PATH, ausencia de ping en Android sin buscar rutas Android en un escritorio y alternativa TCP cuando se verificó la subred local pero no existe ping.
- Se verificaron las recetas oficiales de Termux: iputils no está presente en la ruta de paquetes consultada, iproute2 sí está definido e inetutils desactiva explícitamente ping/ping6. No se reemplazó un paquete inexistente por otro que tampoco aporta ping.
- Las 159 pruebas aprobaron en Linux, incluida la PTY real local. La ejecución completa del instalador corregido en el Termux del propietario sigue pendiente; no se afirma haberla realizado desde esta PC.

## Portabilidad a Termux y terminales Android (1.16.0, 2026-11-11)

- 24 pruebas nuevas cubren detección de Python Android y derivaciones con otro PREFIX, rutas privadas/configuración explícita, temporales privados, selección de shell desde PATH, bloqueo de directo sin entorno gráfico, rechazo de señales si no se puede identificar un proceso, descubrimiento TCP con puertos abiertos/rechazados y límites de alcance, subred manual en el menú, permisos de red denegados y conservación de respuestas IPv6 multicast cuando falla la tabla de vecinos.
- También se cubren guardado sin enlaces duros, no sobrescritura y limpieza de copias parciales; lanzamiento desde otro directorio con espacios y argumentos intactos; instalador con pkg simulado, entorno Python privado, modo sin modificaciones y rechazo de ejecución como root o sin gestor compatible.
- Una prueba adicional utiliza una PTY real local, tmux, PREFIX/HOME de otra aplicación simulada y una ruta con espacios. Verifica ancho/alto interior 16×34, 18×46 y 16×30 al pasar por terminales de 36, 48 y 32 columnas, manteniendo el estado de la shell y el código de salida 7. La identidad de la sesión ADB no se recrea al ajustar el marco; solo se reconstruye la ventana exterior y se sincroniza la PTY.
- Se comprobó una entrada real de 200 caracteres en un campo delimitado de 36 columnas. Si falta la dependencia del editor, el menú termina con un error accionable sin entrar en un bucle de reintentos.
- Prueba real adicional con el TV-box por ADB/IPv6 desde la PC: shell operativa como uid 2000, escritura tras redimensionar, Ctrl+C manteniendo la sesión y cierre normal con exit 0. No se instaló nada ni se cambiaron privilegios en el TV-box.
- Prueba real desde la PC del descubrimiento TCP acotado a 192.168.0.96/28 y puerto 3222: se observó únicamente la IP local, sin errores locales. No se afirmó encontrar el TV-box por IPv4 en esa prueba ni se interpretó la ausencia de respuesta como inexistencia de equipos. No se ejecutó Nmap.
- Los comandos JSON no llevan cuadros, y la interfaz de PC conserva la ubicación previa de configuración/salidas. El instalador no se ejecutó contra el gestor de paquetes real de la PC.
- **Límite de evidencia:** no se instaló ni ejecutó esta versión dentro de Termux real en Android. Las pruebas del entorno Android son simuladas; la prueba de PTY se realiza sobre Linux. Las dependencias y los permisos varían entre aplicaciones y firmwares. El directo en Android requiere preparación gráfica adicional y la búsqueda por vecinos puede estar restringida por el sistema.

## Cuadros adaptables y shell enmarcada (1.15.0, 2026-11-11)

- Resultados, errores, listas y progresos dentro de paneles; preguntas con editor delimitado. Pruebas de ancho entre 6 y 100 columnas para resultados y menú, incluidas rutas largas, IPv6, colores ANSI, caracteres anchos, emojis y acentos combinados. Se comprobó la neutralización de secuencias externas que borran pantalla o cambian el título.
- Pruebas de paneles anidados, cierre tras error, suspensión para introducir datos y reapertura al redimensionar. JSON por CLI continúa siendo parseable, sin bordes ni colores.
- Entradas reales por PTY de 200 caracteres en terminal de 36 columnas, ampliada a 48, sin pérdida del contenido. Ctrl+C genera cancelación y Ctrl+D en vacío cierra la entrada.
- Shell local real dentro de tmux: reducción de 80 a 48 columnas con el marco reajustado, entrada funcional después del cambio y código de salida 7 conservado. La salida de estado de tmux no se imprime fuera del marco.
- Prueba real con el TV-box seleccionado por IPv6: estado ADB, apertura desde la opción 18, `pwd` con resultado `/`, salida larga ajustada al interior, interrupción de `sleep` con Ctrl+C y salida por Ctrl+D con regreso al menú. La shell conservó el código 130 del comando interrumpido. La selección ADB no se modificó.
- Se verifican limpieza de la sesión tmux privada, entorno aislado de sesiones previas, archivos temporales privados, cierre acotado ante interrupción, conservación del código remoto y error explícito si falta tmux o no se pudo confirmar la salida.
- Entorno adicional: tmux 3.7c y prompt_toolkit 3.0.53. Los cuadros de entrada requieren prompt_toolkit; la shell enmarcada requiere tmux con display-popup. Las pruebas PTY se realizaron sobre terminales con al menos 18 filas; el ajuste del menú a anchos mínimos se comprobó mediante renderizado, no mediante una shell real a 6 columnas.

## Pruebas automatizadas

**159 pruebas aprobadas**, ejecutadas con:

```bash
python3 -m unittest discover -s tests -v
```

Cubren integridad y truncamiento PNG, estructura y metadatos MP4, límites de argumentos, prevención de sobrescritura, salida mediante enlace simbólico, errores y tiempos de espera de ADB, selección de dispositivo, transferencia/limpieza simuladas, conservación del vídeo remoto cuando falla la copia, y cancelación con comprobación de la identidad del proceso.

Las pruebas nuevas cubren directos en segundo plano, registro de sesiones, cierre sin ADB, selección del dispositivo, comprobación de nacimiento/argumentos/usuario del proceso y rechazo de PIDs reutilizados o registros que no coinciden. Antes de escalar una señal de cierre se vuelve a comprobar la identidad.

La versión 1.2.0 añade ocho pruebas: normalización de MAC, selección de subred predeterminada y subconjuntos, rechazo de subredes externas o excesivas, ambigüedad de interfaces, persistencia sin ADB conservando opciones, fallo de conexión sin guardar cambios, rechazo de destinos inválidos y descubrimiento pasivo con filtrado de vecinos fallidos o ajenos a la subred.

## Validación de identidad y menú (1.14.0, 2026-11-11)

- Se conservan las 122 pruebas existentes aprobadas; se actualizó la expectativa del tema predeterminado a dogo.
- Renderizado comprobado a 20, 36, 60, 80 y 100 columnas: ninguna línea superó el ancho y se conservaron todas las opciones 0–20, el nombre y la firma.
- Prueba real en PTY con `iniciar.sh --color always`: encabezado Dogo_Box_Tv, firma Dogo, paneles en dos columnas, colores por sección y salida normal con 0.
- El nombre y autor se incluyen en los nuevos metadatos de capturas, comprobaciones de puertos y reportes de auditoría/vulnerabilidades. Los reportes anteriores conservan su contenido original.
- Se mantiene el modo JSON sin decoración. No se repitieron operaciones de red, capturas ni cambios de configuración del TV-box para esta actualización visual.

## Validación de retirada de imagen (1.13.0, 2026-11-10)

- Seis pruebas adicionales cubren asociación de la intención al registro activo en vez de a imágenes antiguas del historial, retirada por Atrás conservando copia y selección, alternativa Inicio solo mientras sigue activa una imagen de la herramienta, ausencia de navegación sobre imágenes ajenas, rechazo de confirmación cuando se desconoce el primer plano y regreso al menú desde la opción 20.
- Prueba real por CLI con la imagen multicolor mostrada en la versión anterior: `hide-image` reconoció la Galería y su URI administrada, envió Atrás y confirmó que dejó de estar en primer plano. Resultado `hidden`, navegación `back`.
- Se mantuvo la copia `/sdcard/Pictures/TVBoxTools/imagen-ed2bb3ff49304b58ba36a9d5cba8d3a3.png`; la función de retirada no ejecuta comandos de eliminación ni fuerza la detención de una aplicación.

## Validación de visualización de imágenes (1.12.0, 2026-11-10)

- Siete pruebas adicionales cubren rechazo de archivos inexistentes, vacíos o con formato inválido antes de contactar al dispositivo; filtrado de actividades y duplicados; nombres remotos generados sin interpretar el nombre local y escape del componente Android; rechazo de visor ausente o desconocido antes de subir; limpieza acotada de una transferencia fallida; rechazo de errores Android aunque am devuelva código 0; y elección de ruta local entrecomillada con espacios y visor explícito desde el menú.
- Prueba real: imagen PNG de barras de colores de 1280×720, 10898 bytes, enviada al TV-box IPv6. Android confirmó apertura con Galería `com.hisilicon.higallery/.NetworkHiGallery` y el usuario confirmó que vio la imagen multicolor en su televisor.
- Archivo local de prueba: `salidas/prueba-imagen-20261110-234011.png`. Resultado: `salidas/prueba-imagen-resultado.json`. Copia remota: `/sdcard/Pictures/TVBoxTools/imagen-ed2bb3ff49304b58ba36a9d5cba8d3a3.png`.
- La función conserva la selección ADB. No se repitieron capturas o grabaciones para verificarla; la confirmación visual provino del usuario.

## Validación de shell interactiva (1.11.0, 2026-11-10)

- Nueve pruebas adicionales cubren rechazo de JSON o flujos sin terminal antes de contactar al dispositivo, herencia de la terminal y serial IPv6 exacto, interrupción local con cierre del cliente, espera acotada y cierre forzado de un cliente que no termina, restauración de terminal tras fallo al iniciar, bloqueo si la autorización falla, propagación del código de salida por CLI, regreso al menú conservando el destino y rechazo de `--json shell` antes de inicializar la aplicación.
- Prueba real en PTY con el destino IPv6 guardado: opción 18, prompt `AndroidTV:/ $`, ejecución de `pwd` y respuesta `/`. Ctrl+C mantuvo la shell; `exit` regresó al menú conservando el último estado remoto (130 tras Ctrl+C).
- Se abrió otra sesión y Ctrl+D devolvió al menú con código 0. La opción 0 cerró después el programa con normalidad, comprobando la restauración de la entrada de terminal.
- La prueba real solo ejecutó el comando de lectura `pwd` y los controles de salida/interrupción; no se hicieron nuevas capturas, grabaciones ni cambios de configuración remotos.

## Validación de conexión ADB IPv6 (1.10.0, 2026-11-10)

- Nueve pruebas adicionales verifican conexión temporal con serial IPv6 exacto, selección persistente con ámbito y MAC, rechazo de estados unauthorized/offline sin cambiar la configuración, rechazo de entradas inválidas antes de ejecutar ADB, compatibilidad de DNS e IPv6 global, restauración de la selección si falla el guardado, reconexión de un destino IPv6 guardado, conservación de la entrada del menú durante llamadas ADB no interactivas y flujo de menú 17 con la última IP/puerto.
- Prueba real en PTY: opción 15 por wlan0, volver con 0, opción 17, fila del TV-box, puerto 3222 y guardado. ADB confirmó `device`; se guardó `[fe80::2e73:60ff:fef1:78d0%wlan0]:3222` con MAC `2C:73:60:F1:78:D0`.
- La opción 2 consultó modelo y estado. Una ejecución independiente de `tvbox.py --json status`, sin `--device`, reutilizó la selección IPv6 guardada y confirmó `device`. `adb devices -l` también listó esa conexión.
- No se hicieron nuevas capturas, grabaciones ni directos de hardware para esta versión; las funciones conservan sus pruebas automatizadas existentes y usan el serial ADB activo. Las consultas reales fueron de estado y propiedades.
- Las llamadas ADB programáticas usan stdin cerrado para que sus procesos no consuman respuestas destinadas al menú.

## Validación de revisión de vulnerabilidades (1.9.0, 2026-11-10)

- Diez pruebas adicionales verifican: reto AUTH sin falso positivo ni envío de claves; aceptación CNXN con validación de cabecera, checksum e identidad y rechazo de tramas incompletas; servidor HTTP Basic real en loopback sin enviar credenciales ni guardar cookies; confirmación TLS solo tras negociar esa versión; TLS 1.2 real por IPv6 con certificado temporal; CVE de texto siempre pendientes de validación y errores de red explícitos; conservación de evidencias al cancelar; estado inconcluso cuando no se pueden revisar servicios; y uso de la última IPv6/puertos como destino del menú 16.
- Las pruebas de reportes verifican hashes, permisos privados y conservación de config.json.
- Prueba real del TV-box por IPv6, puertos `22,80,443,3222,5555`: 3222 abierto y el resto cerrados. Un cliente nuevo sin claves recibió CNXN al iniciar el saludo ADB; se registró `ADB-NO-AUTH`. La misma respuesta se comprobó en otra conexión independiente. No se abrió un stream ADB ni se ejecutaron comandos para comprobar impacto o privilegios.
- Evidencia: `salidas/vulnerabilidades-20261110-143556-63ddf735/vulnerabilidades.json` y su reporte Markdown. Se observó una conexión sin reto AUTH, no una CVE identificada ni una explotación.
- La API NVD respondió correctamente a una consulta de referencia para `OpenSSH 8.2p1` con cero coincidencias de texto; esto no atribuye ese producto al TV-box ni demuestra ausencia de CVE para esa versión. La correlación con configuración y versiones afectadas requiere revisión manual.
- No se ejecutó Nmap ni se solicitaron privilegios para estas comprobaciones.
- Se probó el flujo real en PTY desde opción 15 y reconocimiento de puertos hasta opción 16. La última IPv6 y sus puertos se ofrecieron correctamente sin cambiar el destino ADB. En esa ejecución posterior el TV-box no respondió; ese estado motivó y quedó cubierto por la prueba de resultado inconcluso. Las observaciones ADB anteriores no se atribuyen a esa ejecución posterior.

## Validación de descubrimiento y puertos IPv6 (1.8.0–1.8.1, 2026-11-10)

- Ocho pruebas adicionales cubren el ámbito IPv6 en la conexión TCP, rechazo de ámbito ausente o contradictorio, puertos abiertos/cerrados sobre loopback IPv6 real, conservación de la selección ADB al elegir otra IP, lectura de la MAC desde metadatos del enlace en una interfaz IPv6 sin IPv4, deduplicación de respuestas y distinción de caché, consulta pasiva sin sondas, errores explícitos del sondeo y flujo de menú desde descubrimiento hasta la fila elegida, además de IP manual y cancelación.
- Prueba real en `wlan0`: entre seis y siete filas IPv6, incluida la PC local; las entradas sin respuesta actual se conservaron como caché. El inventario varía según el momento y no garantiza todos los equipos.
- Prueba real de TCP al TV-box `fe80::2e73:60ff:fef1:78d0%wlan0`: `3222` abierto; `22`, `80`, `443` y `5555` cerrados. Reporte en `salidas/tvbox-20261110-141739-968202-56d449.json`.
- La variante con `--host fe80::2e73:60ff:fef1:78d0 --interface wlan0` también confirmó `3222` abierto y produjo JSON válido.
- Flujo real en terminal PTY: opción 15, interfaz wlan0, opción 11, fila 2 del TV-box, puertos `80,3222,5555`, espera de 0.5 segundos y regreso al menú. Se confirmó `3222` abierto, los otros dos cerrados y la conservación del destino ADB anterior. Reporte en `salidas/tvbox-20261110-142001-045808-7f9a8b.json`.
- No se cambió `config.json`, no se ejecutó Nmap y no se solicitaron privilegios para estas pruebas de descubrimiento o TCP.
- La versión 1.8.1 añade el ingreso directo de IPv6 al finalizar la opción 15. Una prueba adicional verifica la interfaz automática al pegar una dirección sin ámbito, el rechazo de IPv4 en ese acceso directo y la comprobación de los puertos elegidos sin modificar la configuración. La opción 11 conserva el acceso independiente a filas e IP manual.
- Prueba real de 1.8.1 en terminal PTY: después de descubrir, se pegó `fe80::2e73:60ff:fef1:78d0` sin ámbito y se reconocieron los puertos `80,3222,5555`; el script añadió `%wlan0`, confirmó `3222` abierto y guardó `salidas/tvbox-20261110-142637-604498-0a6fb6.json`.

## Validación de localización por MAC (2026-11-10)

- Cinco pruebas adicionales cubren coincidencia exacta, cambio de IP conservando puerto ADB, búsqueda sin cambios de configuración, rechazo de caché/duplicados, entradas inválidas y rechazo de la interfaz local como destino.
- Búsqueda real de `2C:73:60:F1:78:D0` en `192.168.0.0/24`, interfaz eth0, IP local 192.168.0.112: estado `not_found`, sin modificar la selección existente. No se afirma haber encontrado el TV-box.
- La actualización de IP se verificó con datos simulados; no pudo validarse sobre el TV-box porque su MAC no era visible desde este segmento durante la prueba.

## Validación de auditoría por etapas (2026-11-10)

- Diez pruebas adicionales cubren confirmación en todas las rondas y resultados inconsistentes, generación de reportes y hashes, permisos privados, ausencia de ADB/servicios por defecto, conservación de evidencias al cancelar, fallo de Nmap sin perder los puertos, exclusión de puertos no confirmados de las sondas de servicio, inclusión del puerto ADB de futuros equipos, rechazo de un destino USB, inventario de lectura con errores parciales y distinción entre identificación activa y etiquetas de tablas de puertos.
- Prueba real básica con `22,3222,5555`: ambas rondas confirmaron 3222 abierto y 22/5555 cerrados; reporte, evidencias y hashes generados.
- Prueba real extendida con Nmap e inventario ADB: se consultaron propiedades, identidad, SELinux, paquetes, procesos, listeners y conexiones. Se observaron `ro.debuggable=1`, SELinux permisivo y parche declarado `2019-03-05`.
- Nmap devolvió una etiqueta `glbp` de tabla para 3222, sin versión identificada. Se añadió una distinción explícita para impedir presentarla como un protocolo identificado; ADB se corrobora por su propia conexión, sin afirmar que sea accesible a clientes no autorizados.
- No se ejecutaron exploits, elevación de privilegios, capturas ni cambios en la configuración Android durante estas pruebas.

## Validación de temas y personalización (2026-11-10)

- Seis pruebas adicionales cubren guardado y recarga de tema/RGB conservando destino y salida, rechazo de colores o roles inválidos sin modificar la configuración, restauración de preferencias predeterminadas, cancelación y Ctrl+C con restauración visual y sin guardar, y rechazo de configuraciones de apariencia malformadas.
- Prueba de integración real en PTY, con configuración temporal: abrir opción 12, elegir fuego, personalizar el título a `#FF8800`, guardar y salir. Se verificaron los códigos RGB en la salida y la persistencia en el archivo.
- Una segunda ejecución recargó las preferencias. `--color always --json appearance` devolvió las preferencias correctas sin códigos ANSI.
- No se abrieron conexiones al TV-box para validar esta actualización visual.

## Validación de interfaz y control (2026-11-10)

- Siete pruebas nuevas cubren colores automáticos y desactivados, NO_COLOR, ausencia de colores/progreso en modo JSON, eliminación de caracteres de control externos, orden de resultados y límite de concurrencia, cancelación de tareas pendientes y cierre del ejecutor, recuperación del menú después de Ctrl+C y errores del sistema, y prevención de directos duplicados del destino desde el menú.
- Prueba real en una terminal PTY: menú coloreado, opción 11, progreso 1/2 y 2/2, resultado verde para 3222 abierto y gris para 5555 cerrado, regreso al menú y salida normal mediante 0.
- Prueba real de `--color always --json scan-ports`: JSON sin códigos ANSI ni mensajes de progreso.
- No se repitieron capturas o directos de hardware en esta versión. No se midió un aumento de velocidad; se conservaron los límites de concurrencia y se mejoró la respuesta visual y la cancelación de trabajo pendiente.

## Validación de puertos TCP (2026-11-10)

- Seis pruebas adicionales cubren listas/rangos y límites de puertos, tiempos de espera inválidos o no finitos, clasificación de códigos de conexión y cierre de sockets, destino seleccionado sin ADB y reporte persistido, rechazo de selección ausente o USB, y conexiones reales en loopback a un puerto abierto y otro cerrado.
- Prueba real en el TV-box seleccionado `192.168.0.101`, con espera de 0.5 segundos por puerto: `3222/TCP` abierto; `22`, `80`, `443` y `5555/TCP` cerrados. Se verificó la generación del reporte JSON en `salidas/`.
- Se usaron conexiones TCP sin datos de aplicación. No se hizo identificación de versiones ni comprobación de CVE. Los estados de tiempo de espera y red inalcanzable se verificaron mediante pruebas simuladas.

## Validación de descubrimiento y selección (2026-11-10)

- Descubrimiento activo real en `192.168.0.0/24` por `eth0`: se recibió respuesta del TV-box `192.168.0.101` y se obtuvo la MAC `2C:73:60:F1:78:D0`, con fabricante Earda Technologies mediante la base local de Nmap.
- Consulta pasiva real: devolvió vecinos y la IP/MAC del ordenador local, sin ejecutar ping. Se excluyó la interfaz Docker sin enlace.
- Selección real de `192.168.0.101:3222`: conexión ADB comprobada y dirección/MAC guardadas en una configuración temporal. Se conservó la configuración habitual del usuario.
- No se repitieron capturas, grabaciones o directos de hardware para este cambio. Las pruebas de esas funciones indicadas debajo corresponden al 2026-11-09.

## Comprobaciones con el TV-box

| Función | Resultado |
|---|---|
| `doctor` | Detectó ADB, scrcpy y el dispositivo conectado |
| `status` | Consultó correctamente modelo, versión declarada, API y parche |
| `capture` | PNG de 1920 × 1080, 1,361,162 bytes, CRC válido, hash y metadatos guardados |
| `record --duration 2` | MP4 de 1.997 segundos, 1280 × 720, sin audio, 94,168 bytes |
| `stream --profile equilibrado` | Ventana abierta, textura de vídeo y FPS positivos observados; 1920 px máximos, 30 FPS máximos y 6 Mbps |
| Cierre del directo | Terminó correctamente al interrumpir la prueba; no quedó la sesión de prueba abierta |
| `stream --background` y `stream-stop` desde otra ejecución | Se abrió la ventana con vídeo, se verificó su registro y se cerró exactamente esa sesión, sin errores |
| Limpieza de grabación | No quedaron archivos con prefijo `tvbox-tools-` en `/data/local/tmp/` |

La prueba del nuevo directo duró aproximadamente siete segundos. Los archivos de captura, vídeo y registros de las pruebas locales están en `salidas/`, que se excluye del paquete de distribución. La cancelación y los errores de transferencia se verificaron con pruebas automatizadas; no se provocaron cortes de red reales.

## Límites

- No se probó el programa con hardware desde Windows o macOS.
- No se probó el perfil nitido de 10 Mbps en este equipo; el perfil equilibrado usa la configuración previamente validada.
- No se garantiza captura de contenido DRM o ventanas seguras.
- La grabación no captura audio y admite hasta 180 segundos por ejecución.
- Las pruebas no modificaron el firmware, no habilitaron root ni instalaron una app permanente en el TV-box.
