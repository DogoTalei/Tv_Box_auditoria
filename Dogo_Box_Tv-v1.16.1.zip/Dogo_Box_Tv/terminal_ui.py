"""Bounded terminal output and editable prompts for Dogo_Box_Tv."""
import contextlib
import os
import re
import shutil
import sys
import unicodedata

try:
    from wcwidth import wcswidth
except ImportError:
    wcswidth = None

from branding import APP_NAME, SIGNATURE
from tvbox_runtime import install_hint

SGR = re.compile(r'\x1b\[[0-9;]*m')
ESCAPE = re.compile(r'\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)|\x1b\[[0-?]*[ -/]*[@-~]|\x1b.')


class InputDependencyError(OSError):
    """Missing input editor: stop the menu instead of retrying forever."""


def clean(value):
    value = ESCAPE.sub(lambda m: m[0] if SGR.fullmatch(m[0]) else '', str(value))
    return ''.join(c for c in value.expandtabs(4) if c == '\x1b' or ord(c) >= 32 and not 127 <= ord(c) < 160)


def cells(value):
    plain = SGR.sub('', value)
    if wcswidth is not None:
        measured = wcswidth(plain)
        if measured >= 0:
            return measured
    return sum(0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in 'WF' else 1
               for c in plain)


def wrap_cells(value, width):
    """Wrap by terminal columns, preserving SGR and every printable character."""
    width = max(1, width)
    value = clean(value)
    row, used = '', 0
    for token in re.findall(r'\x1b\[[0-9;]*m|[^\x1b]', value):
        length = cells(row + token) - used
        if used + length > width:
            yield row
            row, used = '', 0
            length = cells(token)
        if length <= width:
            row += token
            used += length
    yield row


def color_spec(ui, role):
    """Translate the configured ANSI foreground to a shared RGB style."""
    if ui is None or not ui.enabled():
        return ''
    code = ui.palette[role].removeprefix('1;')
    if code.startswith('38;2;'):
        return '#' + ''.join(f'{int(v):02x}' for v in code.split(';')[2:])
    palette = ['#000000', '#aa0000', '#00aa00', '#aa5500', '#0000aa', '#aa00aa', '#00aaaa', '#aaaaaa',
               '#555555', '#ff5555', '#55ff55', '#ffff55', '#5555ff', '#ff55ff', '#55ffff', '#ffffff']
    index = int(code) - (82 if int(code) >= 90 else 30)
    return palette[index]


def terminal_width():
    return max(6, min(shutil.get_terminal_size((80, 24)).columns, 100))


class FrameWriter:
    def __init__(self, stream, title, ui=None):
        self.stream, self.title, self.ui = stream, title, ui
        self.pending = ''
        self.opened = False
        self.width = terminal_width()

    def __getattr__(self, name):
        return getattr(self.stream, name)

    def paint(self, text):
        return self.ui.paint(text, 'border') if self.ui else text

    def edge(self, bottom=False):
        width = self.width
        label = next(wrap_cells(' ' + self.title + ' ', width - 4))
        edge = ('╰' + '─' * (width-2) + '╯') if bottom else ('╭─' + label + '─' * (width-3-cells(label)) + '╮')
        self.stream.write(self.paint(edge) + '\n')

    def line(self, value):
        current_width = terminal_width()
        if self.opened and current_width != self.width:
            self.width = current_width
            self.edge(bottom=True)
            self.opened = False
        self.width = current_width
        if not self.opened:
            self.edge()
            self.opened = True
        for row in wrap_cells(value, self.width - 4):
            reset = '\x1b[0m' if '\x1b' in row else ''
            self.stream.write(self.paint('│ ') + row + reset + ' ' * (self.width-4-cells(row)) + self.paint(' │') + '\n')

    def write(self, value):
        # CR progress updates become bounded rows; no raw cursor motion reaches the frame.
        self.pending += value.lstrip('\r').replace('\r', '\n')
        while '\n' in self.pending:
            line, self.pending = self.pending.split('\n', 1)
            if line or self.opened:
                self.line(line)
        return len(value)

    def flush(self):
        if self.pending:
            self.line(self.pending)
            self.pending = ''
        self.stream.flush()

    def finish(self):
        self.flush()
        if self.opened:
            self.width = terminal_width()
            self.edge(bottom=True)
            self.opened = False
        self.stream.flush()


@contextlib.contextmanager
def output_frame(title=APP_NAME + ' · Resultados', ui=None, stream=None):
    if isinstance(sys.stdout, FrameWriter):
        yield sys.stdout
        return
    writer = FrameWriter(stream or sys.stdout, title, ui)
    with contextlib.redirect_stdout(writer):
        try:
            yield writer
        finally:
            writer.finish()


@contextlib.contextmanager
def unframed_terminal():
    writer = sys.stdout
    if isinstance(writer, FrameWriter):
        writer.finish()
        with contextlib.redirect_stdout(writer.stream):
            yield
    else:
        yield


def read_input(prompt, ui=None):
    """Use a real editable frame on terminals; retain builtin input for pipes/tests."""
    try:
        real_terminal = os.isatty(sys.stdin.fileno()) and os.isatty(sys.stdout.fileno())
    except (AttributeError, OSError, ValueError):
        real_terminal = False
    with unframed_terminal():
        if not real_terminal:
            return input(prompt)
        try:
            from prompt_toolkit.application import Application
            from prompt_toolkit.key_binding import KeyBindings
            from prompt_toolkit.layout import Layout
            from prompt_toolkit.styles import Style
            from prompt_toolkit.widgets import Frame, Label, TextArea
            from prompt_toolkit.layout.containers import HSplit
        except ImportError as error:
            raise InputDependencyError('Los cuadros de entrada requieren prompt_toolkit. ' + install_hint('prompt_toolkit')) from error
        bindings = KeyBindings()
        field = TextArea(height=1, multiline=False, wrap_lines=False)
        @bindings.add('enter')
        def accept(event):
            event.app.exit(result=field.text)
        @bindings.add('c-c')
        def cancel(event):
            event.app.exit(exception=KeyboardInterrupt())
        @bindings.add('c-d')
        def eof(event):
            if not field.text:
                event.app.exit(exception=EOFError())
            else:
                field.buffer.delete()
        caption = SGR.sub('', clean(prompt)).strip()
        content = Frame(HSplit([Label(caption), field,
                              Label('Enter: aceptar · Ctrl+C: cancelar · Ctrl+D: salir')]),
                        title=APP_NAME + ' · ' + SIGNATURE)
        application = Application(layout=Layout(content, focused_element=field), key_bindings=bindings,
                                  style=Style.from_dict({'frame.border': color_spec(ui, 'border'),
                                                        'frame.label': 'bold ' + color_spec(ui, 'title')}),
                                  full_screen=False, mouse_support=False)
        return application.run()
