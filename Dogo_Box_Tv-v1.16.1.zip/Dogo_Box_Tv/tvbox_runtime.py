"""Host capabilities without assuming a desktop Linux installation."""
from __future__ import annotations

import os
from pathlib import Path
import platform
import shutil
import sys


def is_android() -> bool:
    return (sys.platform == "android" or hasattr(sys, "getandroidapilevel")
            or bool(os.environ.get("TERMUX_VERSION"))
            or bool(os.environ.get("ANDROID_ROOT") and Path("/system/bin/getprop").exists()))


def is_termux() -> bool:
    prefix = os.environ.get("PREFIX")
    return bool(prefix and (os.environ.get("TERMUX_VERSION")
                           or Path(prefix, "bin", "pkg").is_file()))


def android_host() -> bool:
    return is_android() or is_termux()


def linux_processes() -> bool:
    return sys.platform.startswith("linux") or android_host()


def default_config(root: Path) -> Path:
    if os.environ.get("TVBOX_CONFIG"):
        return Path(os.environ["TVBOX_CONFIG"]).expanduser()
    if android_host():
        base = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
        return base / "Dogo_Box_Tv" / "config.json"
    return root / "config.json"


def default_output() -> str:
    if android_host():
        base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
        return str(base / "Dogo_Box_Tv" / "salidas")
    return "salidas"


def prepare_environment() -> None:
    """Android has no universal /tmp; use the terminal's private storage."""
    if not android_host():
        return
    temporary = os.environ.get("TMPDIR")
    if temporary and Path(temporary).is_dir() and os.access(temporary, os.W_OK | os.X_OK):
        return
    prefix = os.environ.get("PREFIX")
    directory = (Path(prefix) / "tmp" if prefix else Path.home() / ".cache" / "Dogo_Box_Tv" / "tmp")
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.environ["TMPDIR"] = str(directory)
    # tempfile may already have cached an unsuitable directory before startup.
    import tempfile
    tempfile.tempdir = None


def host_shell() -> str:
    shell = shutil.which("sh")
    if shell:
        return shell
    for candidate in (os.environ.get("SHELL"), "/system/bin/sh", "/bin/sh"):
        if candidate and Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return candidate
    raise RuntimeError("No se encontró una shell local. Instala bash/sh en tu entorno Android.")


def install_hint(tool: str) -> str:
    if tool == "ping" and android_host():
        return ("Se utiliza ping del sistema Android cuando está disponible. "
                "Sin él, usa discover --method tcp --network TU_SUBRED para IPv4, "
                "o una dirección IPv6 conocida en las opciones 11/17.")
    if is_termux():
        package = {"adb": "android-tools", "ip": "iproute2",
                   "prompt_toolkit": "python", "tmux": "tmux"}.get(tool, tool)
        if tool == "prompt_toolkit":
            return "Ejecuta bash instalar-termux.sh para instalar la interfaz en su entorno Python."
        return f"Instálalo con pkg install {package}."
    return f"Instala {tool} con el gestor de paquetes de tu entorno."


def ping_executable() -> str | None:
    binary = shutil.which("ping")
    if binary:
        return binary
    if android_host():
        candidate = Path("/system/bin/ping")
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


def gui_available() -> bool:
    return not android_host() or bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def information() -> dict:
    return {"platform": sys.platform, "android": android_host(), "termux": is_termux(),
            "architecture": platform.machine(), "prefix": os.environ.get("PREFIX"),
            "gui_configured": gui_available(),
            "scope": "Terminal con Python 3.10+, ADB y dependencias nativas compatibles; los permisos dependen de Android."}
