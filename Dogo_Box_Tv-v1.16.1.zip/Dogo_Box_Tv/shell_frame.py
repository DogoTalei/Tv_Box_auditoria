"""Isolated tmux terminal: real PTY and frame, without using the user's sessions."""
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

from tvbox_runtime import host_shell, install_hint, prepare_environment


def main():
    mode, specification = sys.argv[1:3]
    data = json.loads(Path(specification).read_text())
    if mode == 'run':
        # Keep the actual shell attached to this PTY. Never record commands or output.
        print('Destino: ' + (data['command'][2] if len(data['command']) > 2 and data['command'][1] == '-s' else 'Sesión local'), flush=True)
        print('exit / Ctrl+D: volver · Ctrl+C: interrumpir comando', flush=True)
        code = subprocess.call(data['command'])
        Path(data['result']).write_text(str(code))
        return 0
    if mode == 'attach':
        import fcntl
        import struct
        import termios
        dimensions = os.get_terminal_size(sys.stdin.fileno())
        pane = subprocess.run([data['tmux'], 'display-message', '-p', '-t', 'device', '#{pane_tty}'],
                              capture_output=True, text=True, check=True).stdout.strip()
        descriptor = os.open(pane, os.O_RDWR | os.O_NOCTTY)
        try:
            fcntl.ioctl(descriptor, termios.TIOCSWINSZ,
                        struct.pack('HHHH', dimensions.lines, dimensions.columns, 0, 0))
        finally:
            os.close(descriptor)
        environment = dict(os.environ)
        for key in ('TMUX', 'TMUX_PANE'):
            environment.pop(key, None)
        os.execvpe(data['tmux'], [data['tmux'], '-L', data['socket'],
                                 'attach-session', '-t', 'device'], environment)
    tmux = data['tmux']
    for _ in range(100):
        ready = subprocess.run([tmux, 'display-message', '-p', '#{session_attached}'],
                               capture_output=True, text=True)
        if ready.stdout.strip() == '1':
            break
        time.sleep(.05)
    else:
        return 1
    helper = [sys.executable, str(Path(__file__).resolve())]
    command = shlex.join([*helper, 'run', specification])
    started = subprocess.run([tmux, 'new-session', '-d', '-s', 'device', command],
                             capture_output=True)
    if started.returncode:
        return 1
    client = subprocess.run([tmux, 'display-message', '-p', '#{client_name}'],
                            capture_output=True, text=True).stdout.strip()
    if not client:
        return 1
    # Popups shrink automatically, but do not grow. Recreate only the surrounding
    # popup on resize; the actual ADB PTY stays alive in our private device session.
    hook = 'display-popup -C -c ' + shlex.quote(client)
    configured = subprocess.run([tmux, 'set-hook', '-t', 'shell', 'client-resized', hook],
                                capture_output=True)
    if configured.returncode:
        return 1
    command = shlex.join([*helper, 'attach', specification])
    result = Path(data['result'])
    while not result.exists():
        # -E closes when the attached client exits. Ctrl+C goes to the remote PTY.
        subprocess.run([tmux, 'display-popup', '-E', '-w', '100%', '-h', '100%',
                        '-b', 'rounded', '-S', data['border'], '-T', data['title'], command])
        if not result.exists():
            alive = subprocess.run([tmux, 'has-session', '-t', 'device'], capture_output=True)
            if alive.returncode:
                return 1
    return 0


def framed_shell(command, title, border='cyan'):
    """Run one isolated terminal, return the real ADB exit status, clean it up."""
    import shutil
    import tempfile
    import uuid
    tmux = shutil.which('tmux')
    if not tmux:
        raise RuntimeError('La shell enmarcada requiere tmux. ' + install_hint('tmux'))
    prepare_environment()
    shell = host_shell()
    socket_name = 'dogo-' + uuid.uuid4().hex
    process = None
    with tempfile.TemporaryDirectory(prefix='dogo-shell-') as folder:
        folder = Path(folder)
        configuration = folder / 'tmux.conf'
        configuration.write_text('set -g status off\nset -g prefix None\nset -g default-shell '
                                 + shlex.quote(shell) + '\nset -g destroy-unattached off\n'
                                 'set -s exit-unattached on\nset -g escape-time 10\n')
        specification = folder / 'session.json'
        result = folder / 'result'
        specification.write_text(json.dumps(dict(command=command, title=title.replace('#', '##'),
                                                 border=border, tmux=tmux, socket=socket_name, result=str(result))))
        environment = dict(os.environ)
        for key in ('TMUX', 'TMUX_PANE'):
            environment.pop(key, None)
        if environment.get('TERM', 'dumb') == 'dumb':
            environment['TERM'] = 'xterm-256color'
        bootstrap = shlex.join([sys.executable, str(Path(__file__).resolve()), 'session', str(specification)])
        diagnostics = tempfile.TemporaryFile()
        try:
            process = subprocess.Popen([tmux, '-L', socket_name, '-f', str(configuration),
                                        'new-session', '-s', 'shell', bootstrap], env=environment,
                                        stdout=diagnostics, stderr=subprocess.STDOUT)
            status = process.wait()
            if result.exists():
                return int(result.read_text())
            diagnostics.seek(0)
            detail = diagnostics.read(2000).decode(errors='replace').strip()
            raise RuntimeError(f'La terminal ADB se cerró sin confirmar el estado de la shell (tmux: {status}). {detail}')
        finally:
            diagnostics.close()
            try:
                if process is not None and process.poll() is None:
                    try:
                        process.terminate()
                        try:
                            process.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=3)
                    except ProcessLookupError:
                        pass
            finally:
                # Unique private server: never alter the user's tmux sessions.
                try:
                    subprocess.run([tmux, '-L', socket_name, 'kill-server'], stdin=subprocess.DEVNULL,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3)
                except (OSError, subprocess.TimeoutExpired):
                    pass


if __name__ == '__main__':
    raise SystemExit(main())
