"""Identidad de la aplicación y firma del proyecto."""

APP_NAME = "Dogo_Box_Tv"
AUTHOR = "Dogo"
VERSION = "1.16.1"
SIGNATURE = f"Firma: {AUTHOR}"
