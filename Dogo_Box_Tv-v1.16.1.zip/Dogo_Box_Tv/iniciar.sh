#!/bin/sh
set -eu
TVBOX_TOOLS_DIR=$(dirname -- "$0")
cd -- "$TVBOX_TOOLS_DIR"
if [ -n "${TVBOX_PYTHON:-}" ]; then
    exec "$TVBOX_PYTHON" Dogo_Box_Tv.py "$@"
elif [ -x .venv/bin/python ]; then
    exec .venv/bin/python Dogo_Box_Tv.py "$@"
elif command -v python3 >/dev/null 2>&1; then
    exec python3 Dogo_Box_Tv.py "$@"
elif command -v python >/dev/null 2>&1; then
    exec python Dogo_Box_Tv.py "$@"
fi
echo 'Falta Python 3.10 o posterior. En Termux: pkg install python' >&2
exit 127
