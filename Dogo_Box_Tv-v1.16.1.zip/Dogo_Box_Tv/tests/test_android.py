import argparse
from contextlib import redirect_stdout
import errno
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox
import tvbox_runtime as runtime
import shell_frame


class RuntimeTests(unittest.TestCase):
    def test_android_system_ping_can_be_found_outside_termux_path(self):
        with patch.object(runtime.shutil, 'which', return_value=None), patch.object(runtime, 'android_host', return_value=True), patch.object(Path, 'is_file', return_value=True), patch.object(runtime.os, 'access', return_value=True):
            self.assertEqual(runtime.ping_executable(), '/system/bin/ping')
            self.assertNotIn('iputils', runtime.install_hint('ping'))

    def test_missing_android_ping_is_optional_and_desktop_does_not_use_android_path(self):
        with patch.object(runtime.shutil, 'which', return_value=None), patch.object(runtime, 'android_host', return_value=True), patch.object(Path, 'is_file', return_value=False):
            self.assertIsNone(runtime.ping_executable())
        with patch.object(runtime.shutil, 'which', return_value=None), patch.object(runtime, 'android_host', return_value=False), patch.object(Path, 'is_file') as inspect:
            self.assertIsNone(runtime.ping_executable())
            inspect.assert_not_called()

    def test_native_android_python_and_termux_derivative_detected(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(sys, 'platform', 'android'):
            self.assertTrue(runtime.android_host())
            self.assertTrue(runtime.linux_processes())
        with tempfile.TemporaryDirectory() as folder:
            prefix = Path(folder) / 'another-terminal' / 'usr'
            (prefix / 'bin').mkdir(parents=True)
            (prefix / 'bin/pkg').write_text('')
            with patch.dict(os.environ, {'PREFIX': str(prefix)}, clear=True):
                self.assertTrue(runtime.is_termux())
                self.assertTrue(runtime.android_host())
                self.assertIn('android-tools', runtime.install_hint('adb'))

    def test_private_default_paths_do_not_import_desktop_config(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {'HOME': folder, 'TERMUX_VERSION': 'test'}, clear=True):
            args = tvbox.parser().parse_args(['devices'])
            self.assertEqual(Path(args.config), Path(folder) / '.config/Dogo_Box_Tv/config.json')
            self.assertEqual(runtime.default_output(), str(Path(folder) / '.local/share/Dogo_Box_Tv/salidas'))
            app = tvbox.App(args)
            self.addCleanup(self.close_log)
            self.assertIsNone(app.device)
            self.assertEqual(app.output, Path(runtime.default_output()))
            self.assertEqual(app.log_path.stat().st_mode & 0o777, 0o600)

    @staticmethod
    def close_log():
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)

    def test_explicit_config_and_output_override_android_defaults(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {'HOME': folder, 'TERMUX_VERSION': 'test', 'TVBOX_CONFIG': str(Path(folder)/'env.json')}, clear=True):
            configured = Path(folder) / 'custom.json'
            args = tvbox.parser().parse_args(['--config', str(configured), '--output-dir', str(Path(folder)/'captures'), 'devices'])
            app = tvbox.App(args)
            self.addCleanup(self.close_log)
            self.assertEqual(app.config_path, configured)
            self.assertEqual(app.output, Path(folder)/'captures')
            self.assertEqual(runtime.default_config(Path('/project')), Path(folder)/'env.json')

    def test_desktop_config_location_unchanged(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(runtime, 'android_host', return_value=False):
            self.assertEqual(runtime.default_config(Path('/project')), Path('/project/config.json'))
            self.assertEqual(runtime.default_output(), 'salidas')

    def test_android_temporary_directory_uses_actual_prefix(self):
        with tempfile.TemporaryDirectory() as folder:
            prefix = Path(folder) / 'fork/files/usr'
            with patch.dict(os.environ, {'HOME': folder, 'PREFIX': str(prefix), 'TERMUX_VERSION': 'test'}, clear=True), patch.object(tempfile, 'tempdir', None):
                runtime.prepare_environment()
                self.assertEqual(os.environ['TMPDIR'], str(prefix/'tmp'))
                self.assertTrue((prefix/'tmp').is_dir())
                with tempfile.TemporaryDirectory() as created:
                    self.assertEqual(Path(created).parent, prefix/'tmp')

    def test_valid_custom_tmpdir_is_respected(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {'TMPDIR': folder, 'TERMUX_VERSION': 'test'}):
            runtime.prepare_environment()
            self.assertEqual(os.environ['TMPDIR'], folder)

    def test_termux_shell_is_selected_from_path_instead_of_bin_sh(self):
        with tempfile.TemporaryDirectory() as folder:
            binary = Path(folder)/'another-app/files/usr/bin'
            binary.mkdir(parents=True)
            (binary/'sh').symlink_to(shutil.which('sh'))
            with patch.dict(os.environ, {'PATH': str(binary)}):
                self.assertEqual(runtime.host_shell(), str(binary/'sh'))

    def test_headless_android_stream_fails_before_contacting_device(self):
        app = object.__new__(tvbox.App)
        with patch.object(runtime, 'android_host', return_value=True), patch.dict(os.environ, {}, clear=True), patch.object(app, 'ensure_device') as ensure:
            with self.assertRaisesRegex(tvbox.ToolError, 'Termux:X11'):
                app.stream(argparse.Namespace())
        ensure.assert_not_called()

    def test_missing_input_dependency_stops_menu_without_retry_loop(self):
        with patch.object(sys.stdin, 'isatty', return_value=True), patch.object(tvbox, 'menu_panel'), patch.object(tvbox, 'read_input', side_effect=tvbox.InputDependencyError('install prompt_toolkit')) as read:
            with self.assertRaisesRegex(tvbox.ToolError, 'prompt_toolkit'):
                tvbox.menu(object())
        read.assert_called_once()

    def test_process_identity_permission_denied_never_authorizes_signals(self):
        with patch.object(runtime, 'linux_processes', return_value=True), patch.object(Path, 'read_text', side_effect=PermissionError('Android proc restriction')):
            self.assertIsNone(tvbox.process_identity(999999))


class AndroidDiscoveryTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        args = tvbox.parser().parse_args(['--config', str(Path(self.folder.name)/'config.json'), '--output-dir', self.folder.name, '--color', 'never', 'devices'])
        self.app = tvbox.App(args)
        self.addCleanup(RuntimeTests.close_log)

    def route(self, source='192.168.0.3'):
        context = patch.object(tvbox.socket, 'socket')
        factory = context.start()
        self.addCleanup(context.stop)
        factory.return_value.__enter__.return_value.getsockname.return_value = (source, 12345)
        return factory

    def test_tcp_discovery_finds_open_and_closed_without_mac_or_neighbor_access(self):
        self.route()
        def response(host, port, timeout):
            return {'state': 'open' if host.endswith('.2') else 'closed' if host.endswith('.4') else 'no_response'}
        with patch.object(tvbox, 'local_networks', side_effect=AssertionError('must not read netlink')), patch.object(tvbox, 'tcp_probe', side_effect=response), redirect_stdout(io.StringIO()):
            result = self.app.discover('192.168.0.0/29', method='tcp', ports=[3222])
        self.assertEqual(result['mode'], 'tcp_responses')
        self.assertEqual([host['ip'] for host in result['hosts']], ['192.168.0.2', '192.168.0.3', '192.168.0.4'])
        self.assertTrue(all(host['mac'] is None for host in result['hosts']))
        self.assertEqual(result['hosts'][0]['evidence'], 'tcp_response')
        self.assertTrue(result['hosts'][1]['is_local'])
        self.assertEqual(result['hosts'][2]['response_state'], 'closed')
        self.assertEqual(self.app.discovered_hosts, result['hosts'])

    def test_tcp_discovery_refuses_unknown_nonlocal_or_oversized_subnet(self):
        for network in (None, '192.168.0.0/16', '::/64', '127.0.0.0/24', 'bad'):
            with self.subTest(network=network), patch.object(tvbox, 'tcp_probe') as probe:
                with self.assertRaises(tvbox.ToolError):
                    self.app.discover(network, method='tcp')
                probe.assert_not_called()
        self.route(source='10.0.0.2')
        with patch.object(tvbox, 'tcp_probe') as probe:
            with self.assertRaisesRegex(tvbox.ToolError, 'IP de salida'):
                self.app.discover('192.168.0.0/24', method='tcp')
            probe.assert_not_called()

    def test_tcp_refuses_passive_interface_and_excessive_ports(self):
        for kwargs in ({'passive': True}, {'interface': 'wlan0'}, {'ports': list(range(1, 18))}):
            with self.subTest(kwargs=kwargs), patch.object(tvbox, 'tcp_probe') as probe:
                with self.assertRaises(tvbox.ToolError):
                    self.app.discover('192.168.0.0/24', method='tcp', **kwargs)
                probe.assert_not_called()

    def test_android_auto_fallback_requires_explicit_subnet(self):
        with patch.object(runtime, 'android_host', return_value=True), patch.object(tvbox, 'local_networks', side_effect=tvbox.ToolError('netlink restricted')), patch.object(self.app, 'discover_tcp', return_value={'mode': 'tcp_responses'}) as fallback, redirect_stdout(io.StringIO()):
            with self.assertRaises(tvbox.ToolError):
                self.app.discover()
            fallback.assert_not_called()
            self.app.discover('192.168.0.0/24')
            fallback.assert_called_once_with('192.168.0.0/24', None, 0.5)

    def test_android_without_ping_uses_tcp_after_local_scope_is_verified(self):
        network = {'interface': 'wlan0', 'network': '192.168.0.0/24', 'ip': '192.168.0.3', 'mac': None, 'default': True}
        with patch.object(runtime, 'android_host', return_value=True), patch.object(runtime, 'ping_executable', return_value=None), patch.object(tvbox, 'local_networks', return_value=[network]), patch.object(self.app, 'discover_tcp', return_value={'mode': 'tcp_responses'}) as fallback, redirect_stdout(io.StringIO()):
            self.app.discover()
        fallback.assert_called_once_with('192.168.0.0/24', None, 0.5)

    def test_tcp_permission_failures_are_partial_results_not_missing_devices(self):
        self.route()
        with patch.object(tvbox, 'tcp_probe', return_value={'state': 'error', 'error_code': errno.EACCES}), redirect_stdout(io.StringIO()):
            result = self.app.discover('192.168.0.0/29', method='tcp', ports=[3222])
        self.assertEqual(result['status'], 'partial')
        self.assertEqual(len(result['errors']), 5)
        self.assertEqual(len(result['hosts']), 1)
        self.assertTrue(any('permisos' in item for item in result['warnings']))

    def test_menu_offers_manual_discovery_after_android_restriction(self):
        result = {'operation': 'discover', 'interface': None, 'network': '192.168.0.0/24', 'mode': 'tcp_responses', 'hosts': [], 'warnings': []}
        with patch.object(runtime, 'android_host', return_value=True), patch.object(tvbox, 'local_networks', side_effect=tvbox.ToolError('netlink restricted')), patch.object(self.app, 'discover', return_value=result) as discover, patch('builtins.input', side_effect=['192.168.0.0/24', '3222', '0']), redirect_stdout(io.StringIO()):
            tvbox.menu_action(self.app, '10')
        discover.assert_called_once_with('192.168.0.0/24', method='tcp', ports=[3222])

    def test_permission_errors_explain_android_alternatives(self):
        with patch.object(runtime, 'linux_processes', return_value=True), patch.object(tvbox.shutil, 'which', return_value='/fake/ip'), patch.object(tvbox.subprocess, 'run', return_value=subprocess.CompletedProcess([], 1, b'', b'Permission denied')):
            with self.assertRaisesRegex(tvbox.ToolError, 'discover --method tcp'):
                tvbox.local_networks()
            with self.assertRaisesRegex(tvbox.ToolError, 'opciones 11 o 17'):
                tvbox.local_ipv6_networks()

    def test_android_ipv6_multicast_results_survive_neighbor_table_restriction(self):
        network = {'interface': 'wlan0', 'ip': 'fe80::1', 'addresses': ['fe80::1'], 'network': 'fe80::/64', 'mac': None, 'default': True}
        def run(command, **kwargs):
            if 'ff02::1%wlan0' in command:
                return subprocess.CompletedProcess(command, 0, '64 bytes from fe80::2%wlan0: icmp_seq=1\n', '')
            return subprocess.CompletedProcess(command, 1, b'', b'Permission denied')
        with patch.object(runtime, 'android_host', return_value=True), patch.object(tvbox, 'local_ipv6_networks', return_value=[network]), patch.object(tvbox.shutil, 'which', side_effect=lambda name: '/fake/'+name), patch.object(tvbox.subprocess, 'run', side_effect=run), redirect_stdout(io.StringIO()):
            result = self.app.discover_ipv6('wlan0')
        self.assertEqual([h['ip'] for h in result['hosts']], ['fe80::1%wlan0', 'fe80::2%wlan0'])
        self.assertEqual(result['hosts'][1]['evidence'], 'icmp_reply')
        self.assertTrue(any('Android' in warning for warning in result['warnings']))


class SharedStorageTests(unittest.TestCase):
    def test_shared_storage_without_hard_links_preserves_contents_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder)/'image.part', Path(folder)/'image.png'
            source.write_bytes(b'validated PNG bytes')
            with patch.object(tvbox.os, 'link', side_effect=OSError(errno.EOPNOTSUPP, 'FUSE')):
                tvbox.publish(source, output, False)
                self.assertEqual(output.read_bytes(), b'validated PNG bytes')
                self.assertFalse(source.exists())
                source.write_bytes(b'new')
                with self.assertRaises(tvbox.ToolError):
                    tvbox.publish(source, output, False)
                self.assertEqual(output.read_bytes(), b'validated PNG bytes')
                self.assertEqual(source.read_bytes(), b'new')

    def test_failed_copy_removes_partial_output_and_keeps_validated_temporary(self):
        with tempfile.TemporaryDirectory() as folder:
            source, output = Path(folder)/'file.part', Path(folder)/'file.png'
            source.write_bytes(b'validated bytes')
            def fail(source, destination):
                destination.write(b'partial')
                raise OSError('storage full')
            with patch.object(tvbox.os, 'link', side_effect=OSError(errno.EPERM, 'links disabled')), patch.object(tvbox.shutil, 'copyfileobj', side_effect=fail):
                with self.assertRaises(OSError):
                    tvbox.publish(source, output, False)
            self.assertFalse(output.exists())
            self.assertEqual(source.read_bytes(), b'validated bytes')


class LauncherInstallerTests(unittest.TestCase):
    def test_launcher_uses_venv_outside_project_cwd_and_preserves_arguments(self):
        root = Path(tvbox.__file__).parent
        with tempfile.TemporaryDirectory(prefix='dogo project ') as folder:
            project = Path(folder)/'my project';project.mkdir()
            shutil.copy(root/'iniciar.sh', project/'iniciar.sh')
            (project/'Dogo_Box_Tv.py').write_text('import json,sys; print(json.dumps(sys.argv[1:]))')
            (project/'.venv/bin').mkdir(parents=True)
            (project/'.venv/bin/python').symlink_to(sys.executable)
            result = subprocess.run(['sh', str(project/'iniciar.sh'), '--file', 'ruta con espacios.png'], cwd=folder, capture_output=True, text=True, check=True)
            self.assertEqual(json.loads(result.stdout), ['--file', 'ruta con espacios.png'])

    def setup_installer(self, folder):
        root = Path(tvbox.__file__).parent
        project = Path(folder)/'project';project.mkdir()
        shutil.copy(root/'instalar-termux.sh', project/'instalar-termux.sh')
        (project/'requirements.txt').write_text('prompt_toolkit>=3,<4\n')
        prefix = Path(folder)/'fork/files/usr';binary=prefix/'bin';binary.mkdir(parents=True)
        scripts = {
            'pkg': '#!/bin/sh\nprintf "PKG:%s\\n" "$*" >> "$TVBOX_TEST_TRACE"\nfor arg in "$@"; do if [ "$arg" = iputils ]; then echo "Unable to locate package iputils" >&2; exit 100; fi; done\n',
            'id': '#!/bin/sh\necho "${TVBOX_TEST_UID:-1000}"\n',
            'python3': '#!/bin/sh\nprintf "PY:%s\\n" "$*" >> "$TVBOX_TEST_TRACE"\nif [ "${1:-}" = -m ] && [ "${2:-}" = venv ]; then mkdir -p .venv/bin; cp "$0" .venv/bin/python; chmod 755 .venv/bin/python; fi\n'
        }
        for name, content in scripts.items():
            target = binary/name;target.write_text(content);target.chmod(0o755)
        environment = {**os.environ, 'PREFIX': str(prefix), 'PATH': str(binary)+os.pathsep+os.environ['PATH'], 'TVBOX_TEST_TRACE': str(Path(folder)/'trace')}
        return project, environment

    def test_installer_uses_pkg_and_private_venv_without_upgrading_system_pip(self):
        with tempfile.TemporaryDirectory() as folder:
            project, environment = self.setup_installer(folder)
            result = subprocess.run(['sh', str(project/'instalar-termux.sh')], env=environment, cwd=folder, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            trace = Path(environment['TVBOX_TEST_TRACE']).read_text()
            self.assertIn('PKG:install -y python python-pip python-ensurepip-wheels android-tools tmux iproute2\n', trace)
            self.assertNotIn('iputils', trace)
            self.assertIn('PY:-m venv .venv', trace)
            self.assertIn('PY:-m pip install --disable-pip-version-check -r requirements.txt', trace)
            self.assertNotIn('--upgrade pip', trace)
            self.assertFalse((project/'config.json').exists())

    def test_installer_check_mode_does_not_change_packages_or_config(self):
        with tempfile.TemporaryDirectory() as folder:
            project, environment = self.setup_installer(folder)
            result = subprocess.run(['sh', str(project/'instalar-termux.sh'), '--comprobar'], env=environment, cwd=folder, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertFalse(Path(environment['TVBOX_TEST_TRACE']).exists())
            self.assertFalse((project/'.venv').exists())

    def test_installer_rejects_root_and_missing_package_manager(self):
        with tempfile.TemporaryDirectory() as folder:
            project, environment = self.setup_installer(folder)
            environment['TVBOX_TEST_UID']='0'
            result = subprocess.run(['sh', str(project/'instalar-termux.sh')], env=environment, capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('sin su ni sudo', result.stderr)
            self.assertFalse(Path(environment['TVBOX_TEST_TRACE']).exists())
            environment['PREFIX']=''
            result = subprocess.run(['sh', str(project/'instalar-termux.sh')], env=environment, capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn('instalación manual', result.stderr)


if __name__ == '__main__':
    unittest.main()
