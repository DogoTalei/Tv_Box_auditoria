from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox


def sample_png():
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"\0\xff\0\0")) + chunk(b"IEND", b""))


def image_activity(token="current", uri=None, component="com.example.gallery/.Viewer"):
    uri = uri or "file:///sdcard/Pictures/TVBoxTools/imagen-" + "a" * 32 + ".png"
    return (f"  * Hist #0: ActivityRecord{{{token} u0 {component} t1}}\n"
            f"    Intent {{ act=android.intent.action.VIEW dat={uri} typ=image/png cmp={component} }}\n"
            "  Running activities (most recent first):\n"
            f"  mResumedActivity: ActivityRecord{{{token} u0 {component} t1}}\n")


class ShowImageTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.root = Path(self.folder.name)
        self.config = self.root / "config.json"
        self.config.write_text(json.dumps({"device": "[fe80::20%wlan0]:3222", "output_dir": "salidas"}))
        self.original = self.config.read_bytes()
        self.image = self.root / "logo con espacios;touch UNWANTED.png"
        self.image.write_bytes(sample_png())
        self.ui = tvbox.UI.machine, tvbox.UI.mode
        self.app = tvbox.App(tvbox.parser().parse_args(["--config", str(self.config), "--json", "devices"]))
        self.viewer = "com.example.gallery/.Outer$Viewer"

    def tearDown(self):
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)
        tvbox.UI.machine, tvbox.UI.mode = self.ui
        self.folder.cleanup()

    def test_invalid_local_files_never_contact_device(self):
        empty = self.root / "empty.png"
        empty.touch()
        wrong = self.root / "fake.png"
        wrong.write_text("not an image")
        for path in (self.root / "absent.png", self.root, empty, wrong):
            with self.subTest(path=path), patch.object(self.app, "ensure_device") as ensure, \
                    patch.object(self.app, "run_adb") as adb:
                with self.assertRaises(tvbox.ToolError):
                    self.app.show_image(str(path))
                ensure.assert_not_called()
                adb.assert_not_called()

    def test_viewer_query_filters_system_resolver_duplicates_and_invalid_components(self):
        output = ("3 activities found:\n android/com.android.internal.app.ResolverActivity\n"
                  " com.example.gallery/.Outer$Viewer\n com.example.gallery/.Outer$Viewer\n"
                  " bad/component;touch FILE\n")
        with patch.object(self.app, "run_adb", return_value=subprocess.CompletedProcess([], 0, output.encode(), b"")):
            viewers = self.app.image_viewers("image/png")
        self.assertEqual(viewers, [self.viewer])

    def test_show_image_uses_safe_remote_name_and_quotes_android_component(self):
        def adb(arguments, **kwargs):
            return subprocess.CompletedProcess(arguments, 0, b"Status: ok\nActivity: com.example.gallery/.Outer$Viewer\n", b"")
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "image_viewers", return_value=[self.viewer]), \
                patch.object(self.app, "run_adb", side_effect=adb) as run:
            result = self.app.show_image(str(self.image))
        commands = [call.args[0] for call in run.call_args_list]
        push = next(command for command in commands if command[0] == "push")
        self.assertEqual(push[1], str(self.image.resolve()))
        self.assertRegex(push[2], r"^/sdcard/Pictures/TVBoxTools/imagen-[a-f0-9]{32}\.png$")
        self.assertNotIn("UNWANTED", push[2])
        start = next(command for command in commands if command[:3] == ["shell", "am", "start"])
        self.assertEqual(start[-1], shlex.quote(self.viewer))
        self.assertIn("file://" + push[2], start)
        self.assertEqual(result["state"], "viewer_opened")
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_missing_or_unknown_viewer_never_uploads_image(self):
        for viewers, chosen in (([], None), ([self.viewer], "other.package/.Viewer")):
            with self.subTest(viewers=viewers, chosen=chosen), patch.object(self.app, "ensure_device"), \
                    patch.object(self.app, "image_viewers", return_value=viewers), patch.object(self.app, "run_adb") as adb:
                with self.assertRaises(tvbox.ToolError):
                    self.app.show_image(str(self.image), chosen)
                adb.assert_not_called()

    def test_failed_push_cleans_only_generated_copy(self):
        def adb(arguments, **kwargs):
            if arguments[0] == "push":
                raise tvbox.ToolError("transfer failed")
            return subprocess.CompletedProcess(arguments, 0, b"", b"")
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "image_viewers", return_value=[self.viewer]), \
                patch.object(self.app, "run_adb", side_effect=adb) as run:
            with self.assertRaisesRegex(tvbox.ToolError, "transfer failed"):
                self.app.show_image(str(self.image))
        cleanup = run.call_args_list[-1].args[0]
        self.assertEqual(cleanup[:3], ["shell", "rm", "-f"])
        self.assertRegex(cleanup[3], r"^/sdcard/Pictures/TVBoxTools/imagen-[a-f0-9]{32}\.png$")

    def test_android_error_even_with_exit_zero_is_not_reported_as_success(self):
        def adb(arguments, **kwargs):
            return subprocess.CompletedProcess(arguments, 0, b"Error: Activity not started\n", b"")
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "image_viewers", return_value=[self.viewer]), \
                patch.object(self.app, "run_adb", side_effect=adb) as run:
            with self.assertRaisesRegex(tvbox.ToolError, "no confirmó"):
                self.app.show_image(str(self.image))
        self.assertEqual(run.call_args_list[-1].args[0][:3], ["shell", "rm", "-f"])

    def test_menu_accepts_quoted_local_path_and_explicit_viewer(self):
        choices = [self.viewer, "com.android.chrome/.MediaLauncherActivity"]
        result = {"operation": "show-image", "source_path": str(self.image), "remote_path": "/sdcard/Pictures/TVBoxTools/test.png"}
        with patch("builtins.input", side_effect=['"' + str(self.image) + '"', "2"]), \
                patch.object(self.app, "ensure_device"), patch.object(self.app, "image_viewers", return_value=choices), \
                patch.object(self.app, "show_image", return_value=result) as show, redirect_stdout(io.StringIO()):
            tvbox.image_menu(self.app)
        show.assert_called_once_with(str(self.image.resolve()), choices[1])
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_active_image_parser_binds_intent_to_current_activity(self):
        active = tvbox.active_tool_image(image_activity())
        self.assertEqual(active["record"], "current")
        self.assertTrue(active["remote_path"].endswith("a" * 32 + ".png"))
        old = image_activity(token="old").split("  mResumedActivity:", 1)[0]
        unrelated = image_activity(uri="file:///sdcard/DCIM/private.jpg")
        self.assertIsNone(tvbox.active_tool_image(old + unrelated))
        self.assertIsNone(tvbox.active_tool_image("unrecognized dump"))
        ambiguous = image_activity() + "mResumedActivity: ActivityRecord{other u0 other.app/.Main t2}\n"
        self.assertIsNone(tvbox.active_tool_image(ambiguous))

    def test_hide_image_returns_after_back_and_keeps_copy_and_selection(self):
        snapshots = iter([image_activity(), "mResumedActivity: ActivityRecord{home u0 launcher.app/.Home t2}\n"])
        commands = []
        def adb(arguments, **kwargs):
            commands.append(arguments)
            output = next(snapshots).encode() if arguments[1] == "dumpsys" else b""
            return subprocess.CompletedProcess(arguments, 0, output, b"")
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "run_adb", side_effect=adb), \
                patch.object(tvbox.time, "sleep"):
            result = self.app.hide_image()
        self.assertEqual(result["state"], "hidden")
        self.assertEqual(result["navigation"], "back")
        self.assertEqual([command for command in commands if command[1] == "input"],
                         [["shell", "input", "keyevent", "KEYCODE_BACK"]])
        self.assertFalse(any("rm" in command or "force-stop" in command for command in commands))
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_hide_image_falls_back_to_home_only_while_managed_image_is_active(self):
        snapshots = iter([image_activity()] * 4 + ["mResumedActivity: ActivityRecord{home u0 launcher.app/.Home t2}\n"])
        keys = []
        def adb(arguments, **kwargs):
            if arguments[1] == "dumpsys":
                return subprocess.CompletedProcess(arguments, 0, next(snapshots).encode(), b"")
            keys.append(arguments[-1])
            return subprocess.CompletedProcess(arguments, 0, b"", b"")
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "run_adb", side_effect=adb), \
                patch.object(tvbox.time, "sleep"):
            result = self.app.hide_image()
        self.assertEqual(keys, ["KEYCODE_BACK", "KEYCODE_HOME"])
        self.assertEqual(result["navigation"], "home")

    def test_hide_image_never_navigates_an_unrelated_foreground(self):
        old = image_activity(token="old").split("  mResumedActivity:", 1)[0]
        unrelated = image_activity(uri="file:///sdcard/DCIM/private.jpg")
        with patch.object(self.app, "ensure_device"), \
                patch.object(self.app, "run_adb", return_value=subprocess.CompletedProcess([], 0, (old + unrelated).encode(), b"")) as adb:
            result = self.app.hide_image()
        self.assertEqual(result["state"], "not_active")
        adb.assert_called_once_with(["shell", "dumpsys", "activity", "activities"], timeout=10)

    def test_hide_image_does_not_claim_success_when_foreground_cannot_be_verified(self):
        snapshots = iter([image_activity(), "unknown", "unknown", "unknown"])
        keys = []
        def adb(arguments, **kwargs):
            if arguments[1] == "dumpsys":
                return subprocess.CompletedProcess(arguments, 0, next(snapshots).encode(), b"")
            keys.append(arguments[-1])
            return subprocess.CompletedProcess(arguments, 0, b"", b"")
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "run_adb", side_effect=adb), \
                patch.object(tvbox.time, "sleep"):
            with self.assertRaisesRegex(tvbox.ToolError, "No se pudo confirmar"):
                self.app.hide_image()
        self.assertEqual(keys, ["KEYCODE_BACK"])

    def test_menu_option_20_hides_image_and_returns_to_menu(self):
        result = {"operation": "hide-image", "state": "hidden", "device": self.app.device}
        output = io.StringIO()
        with patch.object(sys.stdin, "isatty", return_value=True), redirect_stdout(output), \
                patch.object(self.app, "hide_image", return_value=result) as hide, \
                patch("builtins.input", side_effect=["20", "0"]):
            tvbox.menu(self.app)
        hide.assert_called_once_with()
        self.assertIn("Imagen quitada", output.getvalue())
        self.assertEqual(self.config.read_bytes(), self.original)


if __name__ == "__main__":
    unittest.main()
