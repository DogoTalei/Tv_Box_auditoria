import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import Mock, patch

import shell_frame
import terminal_ui
import tvbox


class OutputFrameTests(unittest.TestCase):
    def test_wrap_long_ipv6_paths_ansi_wide_and_combining_without_overflow(self):
        for width in (6, 12, 20, 36, 60, 80, 100):
            output = io.StringIO()
            with self.subTest(width=width), patch.object(terminal_ui, 'terminal_width', return_value=width):
                with terminal_ui.output_frame(stream=output):
                    print('\x1b[31mfe80::2e73:60ff:fef1:78d0%wlan0\x1b[0m')
                    print('/una/ruta/' + 'archivo-largo-'*12)
                    print('漢字 e\u0301 ' * 20)
                    print('👨‍👩‍👧‍👦 🐶 ' * 12)
                    print('host\x1b[2J\x1b]0;injected\x07 visible')
            for line in output.getvalue().splitlines():
                self.assertEqual(terminal_ui.cells(line), width, repr(line))
            self.assertNotIn('\x1b[2J', output.getvalue())
            self.assertNotIn('injected', output.getvalue())

    def test_nested_frames_close_after_error_without_nested_borders(self):
        output = io.StringIO()
        with self.assertRaises(ValueError), terminal_ui.output_frame(stream=output):
            with terminal_ui.output_frame():
                print('resultado')
                raise ValueError('fail')
        self.assertEqual(output.getvalue().count('╭'), 1)
        self.assertTrue(output.getvalue().rstrip().endswith('╯'))

    def test_resize_reopens_frame_using_new_width(self):
        output = io.StringIO()
        with patch.object(terminal_ui, 'terminal_width', return_value=80) as width:
            with terminal_ui.output_frame(stream=output):
                print('antes')
                width.return_value = 20
                print('después'*30)
        lines = output.getvalue().splitlines()
        self.assertTrue(all(terminal_ui.cells(line) == 20 for line in lines[2:]))

    def test_prompt_temporarily_closes_frame_and_then_output_resumes(self):
        output = io.StringIO()
        with terminal_ui.output_frame(stream=output), patch('builtins.input', return_value='17') as prompt:
            print('antes')
            self.assertEqual(terminal_ui.read_input('opción: '), '17')
            print('después')
        prompt.assert_called_once_with('opción: ')
        self.assertEqual(output.getvalue().count('╭'), 2)
        self.assertEqual(output.getvalue().count('╯'), 2)

    def test_json_cli_stays_parseable_and_undecorated(self):
        with tempfile.TemporaryDirectory() as folder:
            config = Path(folder) / 'config.json'
            config.write_text(json.dumps({'output_dir': folder}))
            output = io.StringIO()
            with patch.object(tvbox.App, 'devices', return_value=[]), patch('sys.stdout', output):
                self.assertEqual(tvbox.main(['--config', str(config), '--json', 'devices']), 0)
            self.assertEqual(json.loads(output.getvalue()), [])
            self.assertNotIn('╭', output.getvalue())
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)


class ShellFrameTests(unittest.TestCase):
    def test_own_server_clean_environment_remote_exit_and_private_files(self):
        process = Mock()
        process.wait.return_value = 0
        process.poll.return_value = 0
        def start(command, env, **kwargs):
            self.assertNotIn('TMUX', env)
            self.assertNotIn('TMUX_PANE', env)
            self.assertIn('dogo-', command[2])
            spec = next(Path(command[4]).parent.glob('session.json'))
            self.assertEqual(spec.parent.stat().st_mode & 0o777, 0o700)
            data = json.loads(spec.read_text())
            self.assertEqual(data['command'], ['/mock/adb', '-s', '[fe80::1%wlan0]:3222', 'shell', '-t'])
            Path(data['result']).write_text('7')
            return process
        with patch('shutil.which', return_value='/mock/tmux'), \
                patch.dict(os.environ, {'TMUX': 'user-server', 'TMUX_PANE': '%1'}), \
                patch.object(shell_frame.subprocess, 'Popen', side_effect=start) as launch, \
                patch.object(shell_frame.subprocess, 'run') as cleanup:
            self.assertEqual(shell_frame.framed_shell(['/mock/adb', '-s', '[fe80::1%wlan0]:3222', 'shell', '-t'], 'Dogo'), 7)
        self.assertEqual(cleanup.call_args.args[0][2], launch.call_args.args[0][2])
        self.assertEqual(cleanup.call_args.args[0][-1], 'kill-server')

    def test_interrupt_terminates_only_own_client_and_bounded_cleanup(self):
        for stubborn in (False, True):
            process = Mock()
            process.wait.side_effect = ([KeyboardInterrupt(), subprocess.TimeoutExpired('tmux', 3), 0]
                                        if stubborn else [KeyboardInterrupt(), 0])
            process.poll.return_value = None
            with self.subTest(stubborn=stubborn), patch('shutil.which', return_value='/mock/tmux'), \
                    patch.object(shell_frame.subprocess, 'Popen', return_value=process), \
                    patch.object(shell_frame.subprocess, 'run') as cleanup:
                with self.assertRaises(KeyboardInterrupt):
                    shell_frame.framed_shell(['/mock/adb'], 'Dogo')
            process.terminate.assert_called_once()
            self.assertEqual(process.kill.call_count, int(stubborn))
            self.assertEqual(cleanup.call_args.kwargs['timeout'], 3)

    def test_missing_tmux_does_not_launch_client(self):
        with patch('shutil.which', return_value=None), patch.object(shell_frame.subprocess, 'Popen') as launch:
            with self.assertRaisesRegex(RuntimeError, 'tmux'):
                shell_frame.framed_shell(['/mock/adb'], 'Dogo')
        launch.assert_not_called()

    def test_unconfirmed_exit_is_not_reported_as_remote_success(self):
        process = Mock()
        process.wait.return_value = 0
        process.poll.return_value = 0
        with patch('shutil.which', return_value='/mock/tmux'), \
                patch.object(shell_frame.subprocess, 'Popen', return_value=process), \
                patch.object(shell_frame.subprocess, 'run'):
            with self.assertRaisesRegex(RuntimeError, 'sin confirmar'):
                shell_frame.framed_shell(['/mock/adb'], 'Dogo')


if __name__ == '__main__':
    unittest.main()
