import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox_audit as audit


def sample(state="open", port=3222):
    return {"ports": [{"port": port, "state": state, "elapsed_ms": 1}], "summary": {"error": 0}}


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.app = Mock(device="192.168.0.101:3222", version="test", output=Path(self.folder.name))
        self.app.scan_ports.return_value = sample()
        self.args = argparse.Namespace(ports=[3222], rounds=2, timeout=0.5, services=False, adb_inventory=False)

    def tearDown(self):
        self.folder.cleanup()

    def run_audit(self):
        with patch.object(audit, "recognition", return_value={"ip": "192.168.0.101"}), patch.object(audit.time, "sleep"):
            return audit.run_audit(self.app, self.args)

    def test_classification_requires_all_rounds_and_preserves_mixed_evidence(self):
        self.assertEqual(audit.classify_rounds([sample(), sample()])[0]["classification"], "confirmed_open")
        self.assertEqual(audit.classify_rounds([sample("closed"), sample("closed")])[0]["classification"], "confirmed_closed")
        self.assertEqual(audit.classify_rounds([sample(), sample("no_response")])[0]["classification"], "inconsistent")
        self.assertEqual(audit.classify_rounds([sample("no_response"), sample("no_response")])[0]["classification"], "no_response")
        self.assertEqual(audit.classify_rounds([sample(), sample()], 3)[0]["classification"], "inconsistent")

    def test_report_evidence_hashes_and_default_no_adb_or_services(self):
        result = self.run_audit()
        self.assertEqual(result["status"], "completed")
        self.app.ensure_device.assert_not_called()
        self.app.run_adb.assert_not_called()
        self.assertEqual(result["ports"][0]["classification"], "confirmed_open")
        self.assertEqual(sum(stage["status"] == "skipped" for stage in result["stages"]), 2)
        evidence = Path(result["evidence_path"])
        self.assertEqual(json.loads(evidence.read_text()), result)
        for line in (evidence.parent / "SHA256SUMS.txt").read_text().splitlines():
            expected, name = line.split("  ")
            self.assertEqual(hashlib.sha256((evidence.parent / name).read_bytes()).hexdigest(), expected)
        if os.name != "nt":
            self.assertEqual(evidence.stat().st_mode & 0o777, 0o600)
            self.assertEqual(evidence.parent.stat().st_mode & 0o777, 0o700)

    def test_cancel_keeps_partial_evidence_and_report(self):
        self.app.scan_ports.side_effect = [sample(), KeyboardInterrupt()]
        result = self.run_audit()
        self.assertEqual(result["status"], "cancelled")
        self.assertEqual(len(result["rounds"]), 1)
        self.assertEqual(result["ports"][0]["classification"], "inconsistent")
        self.assertTrue(Path(result["report_path"]).exists())
        self.assertEqual(result["stages"][-1]["status"], "cancelled")

    def test_service_failure_does_not_lose_tcp_evidence(self):
        self.args.services = True
        with patch.object(audit, "service_scan", side_effect=ValueError("nmap ausente")):
            result = self.run_audit()
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["ports"][0]["classification"], "confirmed_open")
        self.assertIn("nmap ausente", Path(result["report_path"]).read_text())

    def test_no_service_probe_on_unconfirmed_port(self):
        self.args.services = True
        self.app.scan_ports.side_effect = [sample(), sample("no_response")]
        with patch.object(audit, "service_scan") as service:
            result = self.run_audit()
        service.assert_not_called()
        self.assertEqual(result["ports"][0]["classification"], "inconsistent")

    def test_default_ports_include_future_selected_adb_port(self):
        self.app.device = "192.168.0.110:12345"
        self.args.ports = None
        result = self.run_audit()
        self.assertIn(12345, result["scope"]["ports"])
        self.app.scan_ports.assert_called_with(result["scope"]["ports"], 0.5, save_report=False)

    def test_invalid_target_creates_no_audit(self):
        self.app.device = "USB123"
        with self.assertRaises(ValueError):
            self.run_audit()
        self.assertEqual(list(self.app.output.iterdir()), [])

    def test_android_inventory_is_read_only_and_missing_commands_are_partial(self):
        self.args.adb_inventory = True
        def reply(arguments, **kwargs):
            command = arguments[1:]
            if command == ["getprop"]:
                output = b"[ro.adb.secure]: [0]\n[ro.serialno]: [private]\n"
            elif command == ["getenforce"]:
                output = b"Permissive\n"
            elif command == ["id"]:
                output = b"uid=2000(shell)\n"
            elif command[0] in ("ss", "netstat"):
                return subprocess.CompletedProcess([], 127, b"", b"unsupported")
            else:
                output = b"example\n"
            return subprocess.CompletedProcess([], 0, output, b"")
        self.app.run_adb.side_effect = reply
        result = self.run_audit()
        self.assertEqual(result["status"], "partial")
        self.assertNotIn("ro.serialno", result["android"]["properties"])
        self.assertTrue(any("permisivo" in item["title"] for item in result["findings"]))
        allowed = {"getprop", "id", "getenforce", "pm", "ps", "ss", "netstat"}
        self.assertTrue(all(call.args[0][1] in allowed for call in self.app.run_adb.call_args_list))

    def test_nmap_records_fingerprint_without_confirming_cve(self):
        xml = b'''<nmaprun><host><address addr="192.168.0.101"/><ports><port protocol="tcp" portid="3222"><state state="open"/><service name="adb" product="Android Debug Bridge" version="1.0"><cpe>cpe:/a:example:adb:1.0</cpe></service></port></ports></host><runstats><finished exit="success"/></runstats></nmaprun>'''
        with patch.object(audit.shutil, "which", return_value="/mock/nmap"), \
                patch.object(audit.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, xml, b"")) as run:
            result = audit.service_scan("192.168.0.101", [3222], self.app.output)
        self.assertEqual(result["cve_status"], "not_verified")
        command = run.call_args.args[0]
        self.assertNotIn("--script", command)
        self.assertEqual(command[-1], "192.168.0.101")
        self.assertTrue((self.app.output / "nmap.xml").exists())

    def test_port_table_service_label_is_only_a_hint(self):
        xml = b'''<nmaprun><host><address addr="192.168.0.101"/><ports><port portid="3222"><state state="open"/><service name="glbp" method="table" conf="3"/></port></ports></host><runstats><finished exit="success"/></runstats></nmaprun>'''
        with patch.object(audit.shutil, "which", return_value="/mock/nmap"), \
                patch.object(audit.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, xml, b"")):
            result = audit.service_scan("192.168.0.101", [3222], self.app.output)
        self.assertEqual(result["services"][0]["identification"], "port_table_hint_unverified")
        self.assertNotIn("advisory_search", result["services"][0])


if __name__ == "__main__":
    unittest.main()
