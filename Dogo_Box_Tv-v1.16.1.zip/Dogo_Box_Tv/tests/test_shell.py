from contextlib import contextmanager, redirect_stderr, redirect_stdout
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox


class InteractiveShellTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.config = Path(self.folder.name) / "config.json"
        self.target = "[fe80::20%wlan-test]:3222"
        self.config.write_text(json.dumps({"device": self.target, "output_dir": "salidas"}))
        self.original = self.config.read_bytes()
        self.ui = tvbox.UI.machine, tvbox.UI.mode
        self.args = tvbox.parser().parse_args(["--config", str(self.config), "shell"])
        self.app = tvbox.App(self.args)
        self.app.adb = "/mock/adb"

    def tearDown(self):
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)
        tvbox.UI.machine, tvbox.UI.mode = self.ui
        self.folder.cleanup()

    @contextmanager
    def terminal(self):
        with redirect_stdout(io.StringIO()), patch.object(sys.stdin, "isatty", return_value=True), \
                patch.object(sys.stdout, "isatty", return_value=True), \
                patch.object(tvbox, "terminal_snapshot", return_value="saved-settings"), \
                patch.object(tvbox, "restore_terminal") as restore:
            yield restore

    def test_rejects_nonterminal_or_json_before_contacting_device(self):
        for stdin, stdout, machine in ((False, True, False), (True, False, False), (True, True, True)):
            self.app.args.json = machine
            with self.subTest(stdin=stdin, stdout=stdout, json=machine), \
                    patch.object(sys.stdin, "isatty", return_value=stdin), \
                    patch.object(sys.stdout, "isatty", return_value=stdout), \
                    patch.object(self.app, "ensure_device") as ensure, patch.object(tvbox, "framed_shell") as launch:
                with self.assertRaises(tvbox.ToolError):
                    self.app.interactive_shell()
                ensure.assert_not_called()
                launch.assert_not_called()

    def test_framed_client_preserves_exact_ipv6_serial_and_terminal(self):
        with self.terminal() as restore, patch.object(self.app, "ensure_device") as ensure, \
                patch.object(tvbox, "framed_shell", return_value=7) as launch:
            result = self.app.interactive_shell()
        ensure.assert_called_once_with()
        self.assertEqual(launch.call_args.args[0], ["/mock/adb", "-s", self.target, "shell", "-t"])
        self.assertIn("Dogo_Box_Tv", launch.call_args.args[1])
        restore.assert_called_once_with("saved-settings")
        self.assertEqual(result["exit_code"], 7)
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_interrupt_restores_terminal(self):
        with self.terminal() as restore, patch.object(self.app, "ensure_device"), \
                patch.object(tvbox, "framed_shell", side_effect=KeyboardInterrupt()):
            with self.assertRaises(KeyboardInterrupt):
                self.app.interactive_shell()
        restore.assert_called_once_with("saved-settings")
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_missing_dependency_is_actionable_and_restores_terminal(self):
        with self.terminal() as restore, patch.object(self.app, "ensure_device"), \
                patch.object(tvbox, "framed_shell", side_effect=RuntimeError("requires tmux")):
            with self.assertRaisesRegex(tvbox.ToolError, "tmux"):
                self.app.interactive_shell()
        restore.assert_called_once_with("saved-settings")

    def test_start_failure_still_restores_terminal(self):
        with self.terminal() as restore, patch.object(self.app, "ensure_device"), \
                patch.object(tvbox, "framed_shell", side_effect=OSError("cannot execute")):
            with self.assertRaises(OSError):
                self.app.interactive_shell()
        restore.assert_called_once_with("saved-settings")

    def test_failed_authorization_never_launches_interactive_client(self):
        with self.terminal(), patch.object(self.app, "ensure_device", side_effect=tvbox.ToolError("unauthorized")), \
                patch.object(tvbox, "framed_shell") as launch:
            with self.assertRaises(tvbox.ToolError):
                self.app.interactive_shell()
        launch.assert_not_called()

    def test_cli_preserves_remote_exit_code(self):
        result = {"operation": "adb-shell", "device": self.target, "exit_code": 7}
        with patch.object(tvbox.App, "interactive_shell", return_value=result), redirect_stdout(io.StringIO()):
            self.assertEqual(tvbox.main(["--config", str(self.config), "shell"]), 7)

    def test_menu_returns_after_shell_exit_without_changing_selection(self):
        result = {"operation": "adb-shell", "device": self.target, "exit_code": 0}
        output = io.StringIO()
        with patch.object(sys.stdin, "isatty", return_value=True), redirect_stdout(output), \
                patch.object(self.app, "interactive_shell", return_value=result) as shell, \
                patch("builtins.input", side_effect=["18", "0"]):
            tvbox.menu(self.app)
        shell.assert_called_once_with()
        self.assertIn("Shell ADB finalizada", output.getvalue())
        self.assertEqual(output.getvalue().count("Destino activo:"), 2)
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_json_shell_is_rejected_before_app_initialization(self):
        with patch.object(tvbox, "App") as app, redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as caught:
                tvbox.main(["--json", "shell"])
        self.assertEqual(caught.exception.code, 2)
        app.assert_not_called()


if __name__ == "__main__":
    unittest.main()
