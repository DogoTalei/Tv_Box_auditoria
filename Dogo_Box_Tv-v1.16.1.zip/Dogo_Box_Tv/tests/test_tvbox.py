import argparse
import errno
import hashlib
import io
import json
import logging
import os
import socket
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import time
import threading
import unittest
from contextlib import redirect_stdout
from concurrent.futures import Future
from unittest.mock import Mock, patch
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox


def box(kind, payload):
    return struct.pack(">I4s", len(payload) + 8, kind) + payload


def sample_png():
    def chunk(kind, payload):
        return (struct.pack(">I", len(payload)) + kind + payload
                + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"\x00\x12\x34\x56")) + chunk(b"IEND", b""))


def sample_mp4(handler=b"vide", ticks=9981):
    # Container fixture for metadata validation; not an encoded video sample.
    mvhd = box(b"mvhd", struct.pack(">IIIIII", 0, 0, 0, 1000, ticks, 0))
    tkhd = box(b"tkhd", bytes(76) + struct.pack(">II", 1280 << 16, 720 << 16))
    mdia = box(b"mdia", box(b"hdlr", bytes(8) + handler + bytes(12)))
    return (box(b"ftyp", b"isom\x00\x00\x00\x00isomavc1")
            + box(b"mdat", b"fixture") + box(b"moov", mvhd + box(b"trak", tkhd + mdia)))


class FormatTests(unittest.TestCase):
    def test_bitrate_normalization_and_rejection(self):
        self.assertEqual(tvbox.bitrate("6M"), 6_000_000)
        self.assertEqual(tvbox.bitrate("800k"), 800_000)
        for bad in ["0", "6M;id", "-1", "1G", "101M"]:
            with self.subTest(value=bad), self.assertRaises(argparse.ArgumentTypeError):
                tvbox.bitrate(bad)

    def test_dimensions_and_duration_boundaries(self):
        self.assertEqual(tvbox.size("1920x1080"), (1920, 1080))
        for bad in ["1x2", "1279x720", "8194x720", "1280x720;id"]:
            with self.subTest(value=bad), self.assertRaises(argparse.ArgumentTypeError):
                tvbox.size(bad)
        with self.assertRaises(argparse.ArgumentTypeError):
            tvbox.bounded(1, 180)("181")

    def test_png_dimensions(self):
        self.assertEqual(tvbox.png_info(sample_png()), {"format": "PNG", "width": 1, "height": 1})

    def test_png_crc_failure(self):
        data = bytearray(sample_png())
        data[20] ^= 1
        with self.assertRaises(tvbox.ToolError):
            tvbox.png_info(bytes(data))

    def test_png_truncation_and_wrong_format(self):
        for data in [b"error: device offline", sample_png()[:-6]]:
            with self.subTest(data=data[:12]), self.assertRaises(tvbox.ToolError):
                tvbox.png_info(data)

    def test_mp4_metadata(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "video.mp4"
            path.write_bytes(sample_mp4())
            result = tvbox.mp4_info(path)
            self.assertEqual(result["duration_seconds"], 9.981)
            self.assertEqual((result["width"], result["height"]), (1280, 720))
            self.assertFalse(result["audio"])

    def test_mp4_rejects_missing_video_and_truncation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "video.mp4"
            for data in [sample_mp4(handler=b"soun"), sample_mp4()[:-4], sample_mp4(ticks=0)]:
                path.write_bytes(data)
                with self.subTest(length=len(data)), self.assertRaises(tvbox.ToolError):
                    tvbox.mp4_info(path)

    def test_atomic_publish_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            output, temporary = Path(folder) / "file.png", Path(folder) / "file.part"
            output.write_bytes(b"original")
            temporary.write_bytes(b"new")
            with self.assertRaises(tvbox.ToolError):
                tvbox.publish(temporary, output, False)
            self.assertEqual(output.read_bytes(), b"original")
            tvbox.publish(temporary, output, True)
            self.assertEqual(output.read_bytes(), b"new")


class AppTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.root = Path(self.folder.name)
        self.config = self.root / "config.json"
        self.config.write_text(json.dumps({"device": "192.168.0.101:3222", "output_dir": "salidas"}))
        self.args = tvbox.parser().parse_args(["--config", str(self.config), "--json", "status"])
        with patch.object(tvbox.shutil, "which", return_value="/mock/adb"):
            self.app = tvbox.App(self.args)

    def tearDown(self):
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)
        self.folder.cleanup()

    @staticmethod
    def capture_args(**values):
        return argparse.Namespace(file=None, overwrite=False, no_metadata=False, **values)

    def test_config_relative_output_is_stable(self):
        self.assertEqual(self.app.output, self.root / "salidas")

    def test_capture_binary_integrity_and_metadata(self):
        data = sample_png()
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "run_adb") as adb:
            adb.return_value = subprocess.CompletedProcess([], 0, data, b"")
            result = self.app.capture(self.capture_args())
        output = Path(result["path"])
        self.assertEqual(output.read_bytes(), data)
        self.assertEqual(result["sha256"], hashlib.sha256(data).hexdigest())
        self.assertTrue(Path(result["metadata_path"]).exists())
        self.assertEqual(adb.call_args.args[0], ["exec-out", "screencap", "-p"])

    def test_bad_capture_is_not_published(self):
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "run_adb") as adb:
            adb.return_value = subprocess.CompletedProcess([], 0, b"truncated", b"")
            with self.assertRaises(tvbox.ToolError):
                self.app.capture(self.capture_args())
        self.assertEqual(list(self.app.output.glob("*.png")), [])
        self.assertEqual(list(self.app.output.glob("*.part")), [])

    def test_destination_rejects_symlinks(self):
        original = self.root / "original.png"
        original.write_bytes(b"original")
        link = self.root / "link.png"
        try:
            link.symlink_to(original)
        except OSError:
            self.skipTest("Symlinks unavailable")
        with self.assertRaises(tvbox.ToolError):
            self.app.destination(str(link), ".png", True)
        self.assertEqual(original.read_bytes(), b"original")

    def test_adb_timeout_is_reported(self):
        with patch.object(tvbox.subprocess, "run", side_effect=subprocess.TimeoutExpired("adb", 15)):
            with self.assertRaisesRegex(tvbox.ToolError, "no respondió"):
                self.app.run_adb(["get-state"])

    def test_adb_connect_checks_actual_state(self):
        with patch.object(self.app, "run_adb") as adb:
            adb.side_effect = [subprocess.CompletedProcess([], 0, b"failed to connect", b""),
                               subprocess.CompletedProcess([], 1, b"", b"offline")]
            with self.assertRaises(tvbox.ToolError):
                self.app.connect("192.168.0.101:3222")

    def test_multiple_devices_are_not_selected_implicitly(self):
        self.app.device = None
        with patch.object(self.app, "devices", return_value=[{"serial": "a", "state": "device"},
                                                              {"serial": "b", "state": "device"}]):
            with self.assertRaisesRegex(tvbox.ToolError, "Selecciona"):
                self.app.ensure_device()

    def test_stop_recording_rejects_pid_injection(self):
        with patch.object(self.app, "run_adb") as adb:
            adb.return_value = subprocess.CompletedProcess([], 0, b"123;kill -1", b"")
            self.assertFalse(self.app.stop_recording("/tmp/ours.pid", "/tmp/ours.mp4"))
            self.assertEqual(adb.call_count, 1)

    def test_stop_recording_does_not_signal_reused_pid(self):
        with patch.object(self.app, "run_adb") as adb:
            adb.side_effect = [subprocess.CompletedProcess([], 0, b"123", b""),
                               subprocess.CompletedProcess([], 0, b"other\0/tmp/not-ours.mp4\0", b"")]
            with self.assertRaisesRegex(tvbox.ToolError, "identidad"):
                self.app.stop_recording("/tmp/ours.pid", "/tmp/ours.mp4")
            self.assertEqual(adb.call_count, 2)

    def test_stop_recording_signals_only_matching_process(self):
        with patch.object(self.app, "run_adb") as adb:
            adb.side_effect = [subprocess.CompletedProcess([], 0, b"123", b""),
                               subprocess.CompletedProcess([], 0, b"screenrecord\0/tmp/ours.mp4\0", b""),
                               subprocess.CompletedProcess([], 0, b"", b"")]
            self.assertTrue(self.app.stop_recording("/tmp/ours.pid", "/tmp/ours.mp4"))
            self.assertEqual(adb.call_args.args[0], ["shell", "kill", "-INT", "123"])

    def test_record_transfer_validation_and_scoped_cleanup(self):
        process = Mock(returncode=0)
        process.communicate.return_value = (b"", b"")
        process.poll.return_value = 0
        calls = []
        def adb(arguments, **kwargs):
            calls.append(arguments)
            if arguments[0] == "pull":
                Path(arguments[-1]).write_bytes(sample_mp4())
            return subprocess.CompletedProcess([], 0, b"", b"")
        args = argparse.Namespace(file=None, overwrite=False, no_metadata=False,
                                  duration=10, size=(1280, 720), bitrate=4_000_000)
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "run_adb", side_effect=adb), \
                patch.object(tvbox.subprocess, "Popen", return_value=process):
            result = self.app.record(args)
        self.assertEqual(result["duration_seconds"], 9.981)
        self.assertTrue(result["temporary_device_copy_removed"])
        self.assertTrue(Path(result["path"]).exists())
        cleanup = next(x for x in calls if x[:3] == ["shell", "rm", "-f"])
        self.assertEqual(len(cleanup), 5)
        self.assertTrue(all(x.startswith("/data/local/tmp/tvbox-tools-") for x in cleanup[3:]))
        self.assertEqual(list(self.app.output.glob("*.part")), [])

    def test_stream_quality_and_no_remote_control(self):
        args = argparse.Namespace(profile="equilibrado", max_size=None, fps=None, bitrate=None,
                                  title="TV-box; not a shell command", window_size=(1280, 720))
        command, profile = self.app.stream_command(args, "/mock/scrcpy")
        self.assertEqual(profile["bitrate"], 6_000_000)
        self.assertIn("--max-size=1920", command)
        self.assertIn("--no-control", command)
        self.assertIn("--no-audio", command)
        self.assertIn("--window-title=TV-box; not a shell command", command)
        self.assertFalse(any(x.startswith("--record") for x in command))

    def test_failed_pull_preserves_remote_video_and_removes_local_partial(self):
        process = Mock(returncode=0)
        process.communicate.return_value = (b"", b"")
        process.poll.return_value = 0
        calls = []
        def adb(arguments, **kwargs):
            calls.append(arguments)
            if arguments[0] == "pull":
                raise tvbox.ToolError("transferencia interrumpida")
            return subprocess.CompletedProcess([], 0, b"", b"")
        args = argparse.Namespace(file=None, overwrite=False, no_metadata=False,
                                  duration=10, size=(1280, 720), bitrate=4_000_000)
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "run_adb", side_effect=adb), \
                patch.object(tvbox.subprocess, "Popen", return_value=process):
            with self.assertRaisesRegex(tvbox.ToolError, "transferencia"):
                self.app.record(args)
        cleanup = next(x for x in calls if x[:3] == ["shell", "rm", "-f"])
        self.assertEqual(len(cleanup), 4)
        self.assertTrue(cleanup[3].endswith(".pid"))
        self.assertEqual(list(self.app.output.glob("*.part")), [])

    def test_cancel_recording_stops_owned_encoder_and_returns_130(self):
        process = Mock(returncode=0)
        process.communicate.side_effect = [KeyboardInterrupt(), (b"", b"")]
        process.poll.return_value = 0
        args = argparse.Namespace(file=None, overwrite=False, no_metadata=False,
                                  duration=10, size=(1280, 720), bitrate=4_000_000)
        with patch.object(self.app, "ensure_device"), patch.object(self.app, "run_adb") as adb, \
                patch.object(self.app, "stop_recording", return_value=True) as stop, \
                patch.object(tvbox.subprocess, "Popen", return_value=process):
            with self.assertRaises(tvbox.ToolError) as error:
                self.app.record(args)
            self.assertEqual(error.exception.code, 130)
            stop.assert_called_once()
        cleanup = adb.call_args.args[0]
        self.assertEqual(cleanup[:3], ["shell", "rm", "-f"])
        self.assertEqual(len(cleanup), 5)
        self.assertEqual(list(self.app.output.glob("*.mp4")), [])

    def stream_record(self, session_id="a" * 32, device=None):
        serial = device or self.app.device
        argv = ["/mock/scrcpy", "--serial=" + serial, "--window-title=TV-box [TVBOX:" + session_id + "]"]
        identity = {"start_ticks": "123456", "command_sha256": "1" * 64,
                    "owner_uid": os.getuid(), "argv": argv}
        return {"session_id": session_id, "device": serial, "pid": 987654,
                "identity": identity, "state": "running"}

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux identity checks")
    def test_stream_identity_checks_birth_command_owner_and_marker(self):
        record = self.stream_record()
        self.assertTrue(tvbox.session_matches(record, record["identity"]))
        for key, value in [("start_ticks", "other"), ("command_sha256", "other"),
                           ("owner_uid", os.getuid() + 1), ("argv", ["/mock/other"])]:
            identity = {**record["identity"], key: value}
            with self.subTest(key=key):
                self.assertFalse(tvbox.session_matches(record, identity))

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux identity checks")
    def test_stale_stream_pid_is_not_signalled(self):
        record = self.stream_record()
        self.app._save_session(record)
        reused = {**record["identity"], "start_ticks": "999999"}
        with patch.object(tvbox, "process_identity", return_value=reused), patch.object(tvbox.os, "kill") as kill:
            result = self.app.stop_streams()
        kill.assert_not_called()
        self.assertEqual(len(result["stale_removed"]), 1)
        self.assertEqual(result["stopped"], [])
        self.assertFalse(self.app._session_path(record["session_id"]).exists())

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux identity checks")
    def test_stop_stream_signals_verified_identity_only(self):
        record = self.stream_record()
        self.app._save_session(record)
        with patch.object(tvbox, "process_identity", side_effect=[record["identity"], None]), \
                patch.object(tvbox.os, "kill") as kill:
            result = self.app.stop_streams()
        kill.assert_called_once_with(record["pid"], tvbox.signal.SIGINT)
        self.assertEqual(len(result["stopped"]), 1)
        self.assertEqual(result["errors"], [])

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux identity checks")
    def test_stream_identity_rechecked_before_escalating_signals(self):
        record = self.stream_record()
        reused = {**record["identity"], "command_sha256": "2" * 64}
        with patch.object(tvbox, "process_identity", side_effect=[record["identity"], reused]), \
                patch.object(tvbox.os, "kill") as kill:
            self.assertTrue(self.app._stop_session(record))
        kill.assert_called_once_with(record["pid"], tvbox.signal.SIGINT)

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux identity checks")
    def test_stream_stop_defaults_to_selected_device(self):
        record = self.stream_record()
        other = self.stream_record("b" * 32, "192.168.0.200:5555")
        self.app._save_session(record)
        self.app._save_session(other)
        with patch.object(self.app, "_stop_session", return_value=True) as stop:
            result = self.app.stop_streams()
        stop.assert_called_once_with(record)
        self.assertEqual(len(result["stopped"]), 1)
        self.assertTrue(self.app._session_path(other["session_id"]).exists())

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux identity checks")
    def test_stream_stop_does_not_need_adb(self):
        self.app.adb = None
        with patch.object(self.app, "run_adb") as adb:
            result = self.app.stop_streams()
        adb.assert_not_called()
        self.assertEqual(result["stopped"], [])

    def test_stream_session_path_rejects_traversal(self):
        with self.assertRaises(tvbox.ToolError):
            self.app._session_path("../../unrelated")

    @unittest.skipUnless(sys.platform.startswith("linux"), "Linux identity checks")
    def test_background_stream_returns_without_waiting_and_is_registered(self):
        record = self.stream_record()
        process = Mock(pid=record["pid"], returncode=None)
        process.poll.return_value = None
        args = argparse.Namespace(profile="equilibrado", max_size=None, fps=None, bitrate=None,
                                  title="TV-box", window_size=(1280, 720), background=True)
        with patch.object(self.app, "ensure_device"), \
                patch.object(self.app, "scrcpy_setup", return_value=("/mock/scrcpy", {})), \
                patch.object(tvbox.subprocess, "Popen", return_value=process), \
                patch.object(tvbox, "process_identity", return_value=record["identity"]), \
                patch.object(tvbox.uuid, "uuid4", return_value=Mock(hex=record["session_id"])):
            result = self.app.stream(args)
        process.wait.assert_not_called()
        self.assertEqual(result["state"], "running")
        self.assertTrue(self.app._session_path(record["session_id"]).exists())


    def test_port_scan_uses_selected_ip_without_adb_and_saves_report(self):
        with patch.object(tvbox, "tcp_probe", return_value={"port": 3222, "state": "open"}) as probe, \
                patch.object(self.app, "run_adb") as adb:
            result = self.app.scan_ports([3222], 0.5)
        probe.assert_called_once_with("192.168.0.101", 3222, 0.5)
        adb.assert_not_called()
        self.assertEqual(result["summary"]["open"], 1)
        self.assertEqual(json.loads(Path(result["report_path"]).read_text()), result)

    def test_port_scan_rejects_usb_and_absent_selection(self):
        for device in (None, "USB123", "--help"):
            self.app.device = device
            with self.subTest(device=device), patch.object(tvbox, "tcp_probe") as probe:
                with self.assertRaises(tvbox.ToolError):
                    self.app.scan_ports([80])
                probe.assert_not_called()


    def test_appearance_save_reload_preserves_device_and_output(self):
        result = self.app.appearance(theme="fuego", assignments=["title=#FF8800", "progress=rosa"], mode="always")
        saved = tvbox.load_config(self.config)
        self.assertEqual(saved["device"], "192.168.0.101:3222")
        self.assertEqual(saved["output_dir"], "salidas")
        self.assertEqual(saved["appearance"]["colors"]["title"], "#FF8800")
        fresh = tvbox.App(self.args)
        self.assertEqual(tvbox.UI.theme, "fuego")
        self.assertIn("38;2;255;136;0", tvbox.UI.palette["title"])
        self.assertTrue(result["saved"])

    def test_invalid_appearance_never_changes_config(self):
        original = self.config.read_bytes()
        for assignment in ("title=\x1b[31m", "unknown=rojo", "title=#GGGGGG"):
            with self.subTest(assignment=assignment), self.assertRaises(tvbox.ToolError):
                self.app.appearance(assignments=[assignment])
        self.assertEqual(self.config.read_bytes(), original)

    def test_appearance_reset_removes_custom_colors(self):
        self.app.appearance(theme="fuego", assignments=["title=azul"], mode="always")
        result = self.app.appearance(reset=True)
        self.assertEqual(result["settings"], {"theme": "dogo", "mode": "auto", "colors": {}})


    def mac_discovery(self, *hosts):
        return {"network": "192.168.0.0/24", "interface": "eth0", "hosts": list(hosts), "warnings": []}

    def test_find_mac_locates_new_ip_and_preserves_adb_port(self):
        target = "2C:73:60:F1:78:D0"
        self.app.config["selected_target"] = {"mac": target, "port": 3222}
        host = {"ip": "192.168.0.120", "mac": target, "evidence": "icmp_reply", "is_local": False}
        with patch.object(self.app, "discover", return_value=self.mac_discovery(host)), \
                patch.object(self.app, "select_target", return_value={"device": "192.168.0.120:3222"}) as selection:
            result = self.app.find_mac(select=True)
        selection.assert_called_once_with("192.168.0.120", 3222, connect=False, mac=target)
        self.assertEqual(result["status"], "found")
        self.assertTrue(result["selected"])

    def test_find_mac_stale_missing_and_duplicate_never_select(self):
        mac = "2C:73:60:F1:78:D0"
        host = {"ip": "192.168.0.120", "mac": mac, "evidence": "neighbor_cache", "is_local": False}
        for hosts in ([], [host], [dict(host, evidence="icmp_reply"), dict(host, ip="192.168.0.121", evidence="icmp_reply")]):
            with self.subTest(hosts=hosts), patch.object(self.app, "discover", return_value=self.mac_discovery(*hosts)), \
                    patch.object(self.app, "select_target") as selection:
                with self.assertRaises(tvbox.ToolError):
                    self.app.find_mac(mac, select=True)
                selection.assert_not_called()

    def test_find_mac_filters_exact_address_and_does_not_change_config(self):
        original = self.config.read_bytes()
        hosts = [{"ip": "192.168.0.120", "mac": "2C:73:60:F1:78:D1", "evidence": "icmp_reply", "is_local": False}]
        with patch.object(self.app, "discover", return_value=self.mac_discovery(*hosts)):
            result = self.app.find_mac("2c-73-60-f1-78-d0")
        self.assertEqual(result["status"], "not_found")
        self.assertEqual(result["matches"], [])
        self.assertEqual(self.config.read_bytes(), original)

    def test_find_mac_invalid_request_never_scans(self):
        with patch.object(self.app, "discover") as discovery:
            for mac, connect in (("bad", False), ("2C:73:60:F1:78:D0", True)):
                with self.assertRaises(tvbox.ToolError):
                    self.app.find_mac(mac, connect=connect)
            discovery.assert_not_called()

    def test_find_mac_refuses_selecting_local_interface(self):
        mac = "2C:73:60:F1:78:D0"
        host = {"ip": "192.168.0.112", "mac": mac, "evidence": "local_interface", "is_local": True}
        with patch.object(self.app, "discover", return_value=self.mac_discovery(host)):
            with self.assertRaises(tvbox.ToolError):
                self.app.find_mac(mac, select=True)


class PortTests(unittest.TestCase):
    def test_port_lists_and_boundaries(self):
        self.assertEqual(tvbox.port_list("443, 22,80-82,80,65535"), [22, 80, 81, 82, 443, 65535])
        for value in ("", "0", "65536", "80,", "90-80", "1-65535", "80;id", "-1"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                tvbox.port_list(value)

    def test_timeout_rejects_nonfinite_and_out_of_range(self):
        self.assertEqual(tvbox.scan_timeout("0.5"), 0.5)
        for value in ("nan", "inf", "-1", "0", "11", "bad"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                tvbox.scan_timeout(value)

    def test_tcp_states_and_socket_cleanup(self):
        for code, state in ((0, "open"), (errno.ECONNREFUSED, "closed"),
                            (errno.ETIMEDOUT, "no_response"), (errno.EHOSTUNREACH, "unreachable"),
                            (errno.EACCES, "error")):
            with self.subTest(code=code), patch.object(tvbox.socket, "socket") as factory:
                connection = factory.return_value.__enter__.return_value
                connection.connect_ex.return_value = code
                result = tvbox.tcp_probe("192.168.0.101", 80, 0.5)
                self.assertEqual(result["state"], state)
                connection.connect_ex.assert_called_once_with(("192.168.0.101", 80))
                factory.return_value.__exit__.assert_called_once()

    def test_real_loopback_open_and_closed(self):
        with socket.socket() as opened, socket.socket() as closed:
            opened.bind(("127.0.0.1", 0))
            opened.listen(1)
            closed.bind(("127.0.0.1", 0))
            self.assertEqual(tvbox.tcp_probe("127.0.0.1", opened.getsockname()[1], 0.5)["state"], "open")
            self.assertEqual(tvbox.tcp_probe("127.0.0.1", closed.getsockname()[1], 0.5)["state"], "closed")


class NetworkTests(unittest.TestCase):
    networks = [{"interface": "eth0", "ip": "192.168.0.100", "network": "192.168.0.0/24",
                 "mac": "02:11:22:33:44:55", "default": True}]

    def test_mac_normalization(self):
        self.assertEqual(tvbox.normalize_mac("2c-73-60-f1-78-d0"), "2C:73:60:F1:78:D0")
        for bad in ("bad", "FF:FF:FF:FF:FF:FF", "00:00:00:00:00:00"):
            self.assertIsNone(tvbox.normalize_mac(bad))

    def test_scope_rejects_offlink_and_oversized_networks(self):
        for subnet in ("10.0.0.0/24", "0.0.0.0/0", "::1/128", "bad"):
            with self.subTest(subnet=subnet), self.assertRaises(tvbox.ToolError):
                tvbox.network_scope(self.networks, subnet, None)
        broad = [dict(self.networks[0], network="192.168.0.0/16")]
        with self.assertRaises(tvbox.ToolError):
            tvbox.network_scope(broad, None, None)

    def test_scope_default_and_explicit_subset(self):
        _, subnet = tvbox.network_scope(self.networks, None, None)
        self.assertEqual(str(subnet), "192.168.0.0/24")
        _, subnet = tvbox.network_scope(self.networks, "192.168.0.101/30", "eth0")
        self.assertEqual(str(subnet), "192.168.0.100/30")

    def test_ambiguous_default_requires_selection(self):
        with self.assertRaises(tvbox.ToolError):
            tvbox.network_scope(self.networks * 2, None, None)

    def make_app(self, folder):
        config = Path(folder) / "config.json"
        config.write_text(json.dumps({"device": "old:3222", "output_dir": "salidas", "stream_profile": "fluido"}))
        return tvbox.App(tvbox.parser().parse_args(["--config", str(config), "--json", "networks"]))

    def tearDown(self):
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)

    def test_select_persists_without_adb_and_preserves_options(self):
        with tempfile.TemporaryDirectory() as folder:
            app = self.make_app(folder)
            with patch.object(app, "connect") as connect:
                result = app.select_target("192.168.0.101", 3222, connect=False)
            connect.assert_not_called()
            saved = tvbox.load_config(app.config_path)
            self.assertEqual(saved["device"], "192.168.0.101:3222")
            self.assertEqual(saved["stream_profile"], "fluido")
            self.assertFalse(result["connected"])

    def test_failed_connection_does_not_save_selection(self):
        with tempfile.TemporaryDirectory() as folder:
            app = self.make_app(folder)
            original = app.config_path.read_bytes()
            with patch.object(app, "connect", side_effect=tvbox.ToolError("offline")):
                with self.assertRaises(tvbox.ToolError):
                    app.select_target("192.168.0.101")
            self.assertEqual(app.config_path.read_bytes(), original)

    def test_invalid_selection_never_connects(self):
        with tempfile.TemporaryDirectory() as folder:
            app = self.make_app(folder)
            with patch.object(app, "connect") as connect:
                for host, port in (("--help", 5555), ("fe80::1", 5555), ("192.168.0.1", 0)):
                    with self.assertRaises(tvbox.ToolError):
                        app.select_target(host, port)
            connect.assert_not_called()

    def test_passive_discovery_filters_failed_and_offlink_neighbors(self):
        neighbors = [{"dst": "192.168.0.101", "lladdr": "2c:73:60:f1:78:d0", "state": ["STALE"]},
                     {"dst": "192.168.0.102", "state": ["FAILED"]},
                     {"dst": "10.0.0.1", "lladdr": "2c:73:60:f1:78:d0", "state": ["REACHABLE"]}]
        with tempfile.TemporaryDirectory() as folder:
            app = self.make_app(folder)
            with patch.object(tvbox, "local_networks", return_value=self.networks), \
                    patch.object(tvbox.shutil, "which", return_value="/mock/ip"), \
                    patch.object(tvbox, "mac_vendors", return_value={"2C7360": "Earda"}), \
                    patch.object(tvbox.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, json.dumps(neighbors).encode())) as run:
                result = app.discover(passive=True)
            self.assertEqual(run.call_count, 1)
            self.assertEqual(len(result["hosts"]), 2)
            host = result["hosts"][1]
            self.assertEqual(host["vendor"], "Earda")
            self.assertEqual(host["evidence"], "neighbor_cache")


class InterfaceTests(unittest.TestCase):
    def setUp(self):
        self.original = tvbox.UI.mode, tvbox.UI.machine
        tvbox.UI.mode, tvbox.UI.machine = "auto", False

    def tearDown(self):
        tvbox.UI.mode, tvbox.UI.machine = self.original

    def test_color_respects_redirect_and_no_color(self):
        with patch.object(sys.stdout, "isatty", return_value=False):
            self.assertNotIn("\x1b", tvbox.UI.paint("texto"))
        with patch.object(sys.stdout, "isatty", return_value=True), patch.dict(os.environ, {"NO_COLOR": "1"}):
            self.assertNotIn("\x1b", tvbox.UI.paint("texto"))
        tvbox.UI.mode = "always"
        self.assertIn("\x1b", tvbox.UI.paint("texto"))
        tvbox.UI.mode = "never"
        self.assertNotIn("\x1b", tvbox.UI.paint("texto"))

    def test_machine_mode_never_colors_or_prints_progress(self):
        tvbox.UI.mode, tvbox.UI.machine = "always", True
        output = io.StringIO()
        with redirect_stdout(output), patch.object(output, "isatty", return_value=True):
            self.assertEqual(tvbox.parallel_tasks([1, 2], lambda value: value * 2), [2, 4])
            self.assertEqual(tvbox.UI.paint("texto"), "texto")
        self.assertEqual(output.getvalue(), "")

    def test_external_control_characters_are_removed(self):
        tvbox.UI.mode = "never"
        self.assertNotIn("\x1b", tvbox.UI.paint("TV\x1b[2J\x00"))
        self.assertNotIn("\x00", tvbox.UI.paint("TV\x00"))

    def test_parallel_results_are_ordered_and_concurrency_bounded(self):
        lock = threading.Lock()
        active = maximum = 0
        def work(value):
            nonlocal active, maximum
            with lock:
                active += 1
                maximum = max(maximum, active)
            time.sleep(0.005)
            with lock:
                active -= 1
            return value * 2
        self.assertEqual(tvbox.parallel_tasks(range(8), work, workers=2), list(range(0, 16, 2)))
        self.assertLessEqual(maximum, 2)
        self.assertEqual(active, 0)

    def test_interrupt_cancels_queued_work_and_shuts_down_pool(self):
        interrupted, pending = Future(), Future()
        interrupted.set_exception(KeyboardInterrupt())
        executor = Mock()
        executor.submit.side_effect = [interrupted, pending]
        with patch.object(tvbox, "ThreadPoolExecutor", return_value=executor), \
                patch.object(tvbox, "as_completed", return_value=iter([interrupted])):
            with self.assertRaises(KeyboardInterrupt):
                tvbox.parallel_tasks([1, 2], lambda value: value)
        self.assertTrue(pending.cancelled())
        executor.shutdown.assert_called_once_with(wait=True, cancel_futures=True)

    def test_menu_recovers_after_interrupt_and_operating_system_error(self):
        app = Mock(device="192.168.0.101:3222", output="salidas", log_path="test.log")
        app.status.side_effect = OSError("sin conexión")
        output = io.StringIO()
        with patch.object(sys.stdin, "isatty", return_value=True), redirect_stdout(output), \
                patch.object(tvbox.LOG, "exception"), \
                patch("builtins.input", side_effect=[KeyboardInterrupt(), "2", "0"]):
            tvbox.menu(app)
        self.assertIn("Operación cancelada", output.getvalue())
        self.assertIn("sin conexión", output.getvalue())
        self.assertEqual(output.getvalue().count("Destino activo:"), 3)

    def test_menu_prevents_duplicate_stream_for_selected_device(self):
        app = Mock(device="192.168.0.101:3222", output="salidas")
        app.list_streams.return_value = [{"device": app.device}]
        with patch.object(sys.stdin, "isatty", return_value=True), \
                patch.object(tvbox.sys, "platform", "linux"), redirect_stdout(io.StringIO()), \
                patch("builtins.input", side_effect=["5", "0"]):
            tvbox.menu(app)
        app.stream.assert_not_called()

    def test_appearance_cancel_restores_console_and_does_not_save(self):
        app = Mock(config={})
        original = tvbox.UI.mode, tvbox.UI.theme, dict(tvbox.UI.palette)
        with redirect_stdout(io.StringIO()), patch("builtins.input", side_effect=["1", "3", "0"]):
            tvbox.appearance_menu(app)
        self.assertEqual((tvbox.UI.mode, tvbox.UI.theme, tvbox.UI.palette), original)
        app.appearance.assert_not_called()

    def test_appearance_interrupt_restores_console(self):
        app = Mock(config={})
        original = tvbox.UI.mode, tvbox.UI.theme, dict(tvbox.UI.palette)
        with redirect_stdout(io.StringIO()), patch("builtins.input", side_effect=["1", "3", KeyboardInterrupt()]):
            with self.assertRaises(KeyboardInterrupt):
                tvbox.appearance_menu(app)
        self.assertEqual((tvbox.UI.mode, tvbox.UI.theme, tvbox.UI.palette), original)

    def test_appearance_rejects_malformed_config(self):
        for value in (None, [], {"theme": "unknown"}, {"colors": {"title": "bad"}}, {"mode": "rainbow"}):
            with self.subTest(value=value), self.assertRaises(tvbox.ToolError):
                tvbox.appearance_settings(value)


if __name__ == "__main__":
    unittest.main(verbosity=2)
