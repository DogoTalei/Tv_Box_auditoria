from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox


class IPv6Tests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.config = Path(self.folder.name) / "config.json"
        self.config.write_text(json.dumps({"device": "192.168.0.101:3222", "output_dir": "salidas"}))
        self.original_config = self.config.read_bytes()
        self.original_ui = tvbox.UI.mode, tvbox.UI.machine
        args = tvbox.parser().parse_args(["--config", str(self.config), "--json", "networks"])
        self.app = tvbox.App(args)
        self.network = {"interface": "wlan-test", "ip": "fe80::10", "addresses": ["fe80::10"],
                        "network": "fe80::/64", "mac": "02:11:22:33:44:55", "default": True}

    def tearDown(self):
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)
        tvbox.UI.mode, tvbox.UI.machine = self.original_ui
        self.folder.cleanup()

    def test_scoped_ipv6_connect_uses_scope_id(self):
        with patch.object(tvbox.socket, "if_nametoindex", return_value=37), \
                patch.object(tvbox.socket, "socket") as factory:
            connection = factory.return_value.__enter__.return_value
            connection.connect_ex.return_value = 0
            result = tvbox.tcp_probe("fe80::20%wlan-test", 3222, 0.5)
        factory.assert_called_once_with(socket.AF_INET6, socket.SOCK_STREAM)
        connection.connect_ex.assert_called_once_with(("fe80::20", 3222, 0, 37))
        self.assertEqual(result["state"], "open")
        factory.return_value.__exit__.assert_called_once()

    def test_link_local_requires_valid_scope_and_rejects_conflicting_interface(self):
        with self.assertRaisesRegex(tvbox.ToolError, "necesita %interfaz"):
            tvbox.ip_host("fe80::20")
        with patch.object(tvbox.socket, "if_nametoindex", side_effect=lambda name: 6 if name == "wlan-test" else 7), \
                patch.object(tvbox.socket, "if_indextoname", return_value="wlan-test"):
            self.assertEqual(tvbox.ip_host("fe80::20", "wlan-test"), "fe80::20%wlan-test")
            self.assertEqual(tvbox.device_ip("[fe80::20%wlan-test]:3222"), "fe80::20%wlan-test")
            with self.assertRaisesRegex(tvbox.ToolError, "no coincide"):
                tvbox.ip_host("fe80::20%wlan-test", "other")
        for address in ("192.168.0.1%wlan-test", "ff02::1%wlan-test", "::", "--help"):
            with self.subTest(address=address), self.assertRaises(tvbox.ToolError):
                tvbox.ip_host(address)

    @unittest.skipUnless(socket.has_ipv6, "IPv6 not available")
    def test_real_ipv6_ports_and_explicit_host_preserve_adb_selection(self):
        opened = closed = None
        try:
            opened = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
            closed = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
            opened.bind(("::1", 0))
            closed.bind(("::1", 0))
        except OSError as error:
            for connection in (opened, closed):
                if connection is not None:
                    connection.close()
            self.skipTest(str(error))
        with opened, closed:
            opened.listen(1)
            open_port, closed_port = opened.getsockname()[1], closed.getsockname()[1]
            result = self.app.scan_ports([closed_port, open_port], 0.5, host="::1")
        states = {item["port"]: item["state"] for item in result["ports"]}
        self.assertEqual(states, {open_port: "open", closed_port: "closed"})
        self.assertEqual(result["family"], "IPv6")
        self.assertEqual(result["ip"], "::1")
        self.assertEqual(json.loads(Path(result["report_path"]).read_text()), result)
        self.assertEqual(self.app.device, "192.168.0.101:3222")
        self.assertEqual(self.config.read_bytes(), self.original_config)

    def test_ipv6_only_interface_gets_mac_from_link_metadata(self):
        addresses = [
            {"ifname": "wlan-test", "flags": ["UP", "LOWER_UP"], "addr_info": [
                {"family": "inet6", "local": "2001:db8::10", "prefixlen": 64},
                {"family": "inet6", "local": "fe80::10", "prefixlen": 64}]},
            {"ifname": "docker0", "flags": ["UP", "NO-CARRIER"], "addr_info": [
                {"family": "inet6", "local": "fe80::dead", "prefixlen": 64}]}]
        def run(command, **kwargs):
            if "address" in command:
                data = addresses
            elif "link" in command:
                data = [{"ifname": "wlan-test", "address": "02:11:22:33:44:55"}]
            else:
                data = [{"dev": "wlan-test"}] if "-6" in command else []
            return subprocess.CompletedProcess(command, 0, json.dumps(data).encode())
        with patch.object(tvbox.shutil, "which", return_value="/mock/ip"), \
                patch.object(tvbox.sys, "platform", "linux"), \
                patch.object(tvbox.subprocess, "run", side_effect=run):
            networks = tvbox.local_ipv6_networks()
        self.assertEqual(len(networks), 1)
        self.assertTrue(networks[0]["default"])
        self.assertEqual(networks[0]["mac"], "02:11:22:33:44:55")
        self.assertEqual(networks[0]["ip"], "fe80::10")
        self.assertEqual(set(networks[0]["addresses"]), {"fe80::10", "2001:db8::10"})

    def test_discovery_deduplicates_current_replies_and_labels_cache_honestly(self):
        neighbors = [
            {"dst": "fe80::20", "lladdr": "2c:73:60:f1:78:d0", "state": ["REACHABLE"]},
            {"dst": "fe80::30", "lladdr": "02:11:22:33:44:66", "state": ["STALE"]},
            {"dst": "fe80::40", "lladdr": "02:11:22:33:44:77", "state": ["FAILED"]},
        ]
        output = ("64 bytes from fe80::20%wlan-test: icmp_seq=1 ttl=64\n"
                  "64 bytes from fe80::10%wlan-test: icmp_seq=1 ttl=64\n"
                  "64 bytes from fe80::20%wlan-test: icmp_seq=2 ttl=64 (DUP!)\n")
        def run(command, **kwargs):
            if "ff02::1%wlan-test" in command:
                return subprocess.CompletedProcess(command, 0, output, "")
            if "neigh" in command:
                return subprocess.CompletedProcess(command, 0, json.dumps(neighbors).encode(), b"")
            return subprocess.CompletedProcess(command, 1, b"", b"")
        with patch.object(tvbox, "local_ipv6_networks", return_value=[self.network]), \
                patch.object(tvbox.shutil, "which", side_effect=lambda name: "/mock/" + name), \
                patch.object(tvbox, "mac_vendors", return_value={"2C7360": "Earda"}), \
                patch.object(tvbox.subprocess, "run", side_effect=run):
            result = self.app.discover_ipv6()
        hosts = result["hosts"]
        self.assertEqual([host["ip"] for host in hosts],
                         ["fe80::10%wlan-test", "fe80::20%wlan-test", "fe80::30%wlan-test"])
        self.assertEqual([host["evidence"] for host in hosts], ["local_interface", "icmp_reply", "neighbor_cache"])
        self.assertEqual(hosts[1]["vendor"], "Earda")
        self.assertIsNone(hosts[2]["vendor"])
        self.assertEqual(self.app.discovered_hosts, hosts)
        self.assertEqual(self.config.read_bytes(), self.original_config)

    def test_passive_discovery_does_not_probe_and_ping_errors_are_visible(self):
        with patch.object(tvbox, "local_ipv6_networks", return_value=[self.network]), \
                patch.object(tvbox.shutil, "which", side_effect=lambda name: "/mock/" + name), \
                patch.object(tvbox, "mac_vendors", return_value={}), \
                patch.object(tvbox.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, b"[]")) as run:
            result = self.app.discover_ipv6(passive=True)
        self.assertEqual(run.call_count, 1)
        self.assertIn("neigh", run.call_args.args[0])
        self.assertEqual(result["hosts"][0]["evidence"], "local_interface")
        with patch.object(tvbox, "local_ipv6_networks", return_value=[self.network]), \
                patch.object(tvbox.shutil, "which", return_value="/mock/ping"), \
                patch.object(tvbox.subprocess, "run", return_value=subprocess.CompletedProcess([], 2, "", "Network unreachable")):
            with self.assertRaisesRegex(tvbox.ToolError, "Network unreachable"):
                self.app.discover_ipv6()

    def test_menu_discovers_rows_then_scans_chosen_ipv6_without_saving_target(self):
        result = {"operation": "discover", "family": "IPv6", "network": "fe80::/64",
                  "interface": "wlan-test", "warnings": [], "hosts": [
                      {"ip": "fe80::10%wlan-test", "mac": self.network["mac"], "is_local": True,
                       "evidence": "local_interface"},
                      {"ip": "fe80::20%wlan-test", "mac": "2C:73:60:F1:78:D0", "is_local": False,
                       "evidence": "icmp_reply"}]}
        def discover(interface):
            self.app.discovered_hosts = result["hosts"]
            return result
        def probe(host, port, timeout):
            return {"port": port, "state": "open" if port == 3222 else "closed", "elapsed_ms": 0.1}
        output = io.StringIO()
        with patch.object(sys.stdin, "isatty", return_value=True), redirect_stdout(output), \
                patch.object(tvbox, "local_ipv6_networks", return_value=[self.network]), \
                patch.object(self.app, "discover_ipv6", side_effect=discover), \
                patch.object(tvbox.socket, "if_nametoindex", return_value=6), \
                patch.object(tvbox.socket, "if_indextoname", return_value="wlan-test"), \
                patch.object(tvbox, "tcp_probe", side_effect=probe) as tcp, \
                patch("builtins.input", side_effect=["15", "1", "0", "11", "2", "443,3222", "0.5", "0"]):
            tvbox.menu(self.app)
        self.assertEqual({call.args[0] for call in tcp.call_args_list}, {"fe80::20%wlan-test"})
        self.assertIn("Puertos TCP abiertos: 3222", output.getvalue())
        self.assertIn("fe80::20%wlan-test", output.getvalue())
        self.assertEqual(self.config.read_bytes(), self.original_config)
        self.assertEqual(self.app.device, "192.168.0.101:3222")

    def test_scan_menu_accepts_manual_ip_and_cancellation(self):
        with patch("builtins.input", return_value="::1"):
            self.assertEqual(tvbox.choose_scan_host(self.app), "::1")
        with patch("builtins.input", return_value="0"):
            self.assertIsNone(tvbox.choose_scan_host(self.app))

    def test_direct_ipv6_prompt_adds_discovered_scope_and_checks_selected_ports(self):
        output = io.StringIO()
        result = {"operation": "port-scan", "ip": "fe80::20%wlan-test", "elapsed_seconds": 0.1,
                  "ports": [{"port": 3222, "state": "open", "elapsed_ms": 0.1}],
                  "summary": {"open": 1, "closed": 0, "no_response": 0, "unreachable": 0, "error": 0},
                  "warnings": []}
        with patch.object(tvbox.socket, "if_nametoindex", return_value=6), \
                patch.object(tvbox.socket, "if_indextoname", return_value="wlan-test"), \
                patch.object(self.app, "scan_ports", return_value=result) as scan, redirect_stdout(output), \
                patch("builtins.input", side_effect=["192.168.0.101", "fe80::20", "3222", "0.5"]):
            tvbox.scan_ports_menu(self.app, "wlan-test", ipv6_only=True)
        scan.assert_called_once_with([3222], 0.5, host="fe80::20%wlan-test")
        self.assertIn("Elige una IPv6", output.getvalue())
        self.assertEqual(self.config.read_bytes(), self.original_config)


if __name__ == "__main__":
    unittest.main()
