from contextlib import redirect_stdout
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import io
import json
from pathlib import Path
import shutil
import socket
import ssl
import struct
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
import urllib.error

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox
import tvbox_vuln as vuln


def adb_packet(command, body, arg0):
    code = int.from_bytes(command, "little")
    return struct.pack("<6I", code, arg0, 4096 if command == b"CNXN" else 0,
                       len(body), sum(body), code ^ 0xffffffff) + body


class Stream:
    def __init__(self, response):
        self.response = io.BytesIO(response)
        self.sent = []
        self.closed = False

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.closed = True

    def sendall(self, data):
        self.sent.append(data)

    def recv(self, size):
        return self.response.read(min(size, 3))

    def settimeout(self, timeout):
        pass


class VulnerabilityTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.config = Path(self.folder.name) / "config.json"
        self.config.write_text(json.dumps({"device": "192.168.0.101:3222", "output_dir": "salidas"}))
        self.original = self.config.read_bytes()
        self.ui = tvbox.UI.machine, tvbox.UI.mode
        args = tvbox.parser().parse_args(["--config", str(self.config), "--json", "networks"])
        self.app = tvbox.App(args)

    def tearDown(self):
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)
        tvbox.UI.machine, tvbox.UI.mode = self.ui
        self.folder.cleanup()

    def scan(self):
        return {"family": "IPv6", "ip": "::1", "ports": [{"port": 2222, "state": "open"}]}

    def test_adb_auth_challenge_is_not_a_vulnerability_and_no_key_is_sent(self):
        stream = Stream(adb_packet(b"AUTH", bytes(range(20)), 1))
        with patch.object(vuln, "dial", return_value=stream):
            result = vuln.inspect_service("::1", 3222, 1, {3222})
        self.assertEqual(result["findings"], [])
        self.assertEqual(result["checks"][0]["status"], "authentication_required")
        self.assertEqual(len(stream.sent), 1)
        self.assertEqual(stream.sent[0][:4], b"CNXN")
        self.assertTrue(stream.closed)
        self.assertNotIn("token", json.dumps(result).lower())

    def test_adb_acceptance_requires_valid_complete_protocol_response(self):
        packet = adb_packet(b"CNXN", b"device::features=shell_v2;\0", 0x01000000)
        with patch.object(vuln, "dial", return_value=Stream(packet)):
            result = vuln.inspect_service("::1", 3222, 1, {3222})
        self.assertEqual(result["findings"][0]["id"], "ADB-NO-AUTH")
        self.assertEqual(result["findings"][0]["status"], "confirmed")
        with patch.object(vuln, "dial", return_value=Stream(adb_packet(b"CNXN", b"device:serial:features=\0", 0x01000000))):
            self.assertEqual(vuln.adb_check("::1", 3222, 1)["status"], "accepted_without_auth")
        for invalid in (packet[:-1], packet[:20] + b"\0\0\0\0" + packet[24:],
                        adb_packet(b"CNXN", b"arbitrary text", 0x01000000)):
            with self.subTest(invalid=invalid[:24]), patch.object(vuln, "dial", return_value=Stream(invalid)):
                result = vuln.inspect_service("::1", 3222, 1, {3222})
            self.assertEqual(result["findings"], [])
            self.assertEqual(result["checks"][0]["status"], "inconclusive")

    def test_real_http_basic_check_never_sends_credentials_or_saves_cookies(self):
        requests = []
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                requests.append((self.path, self.headers.get("Authorization")))
                self.send_response(401)
                self.send_header("WWW-Authenticate", 'Basic realm="local"')
                self.send_header("Set-Cookie", "session=private-value")
                self.end_headers()

            def log_message(self, *args):
                pass
        server = HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        port = server.server_port
        try:
            with patch.object(vuln, "HTTP_PORTS", {port}):
                result = vuln.run_vulnerability_scan(self.app, "127.0.0.1", [port], 1)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(2)
        self.assertEqual(requests, [("/", None)])
        self.assertEqual(result["findings"][0]["id"], "HTTP-BASIC-CLEARTEXT")
        self.assertNotIn("private-value", json.dumps(result))
        self.assertEqual(self.config.read_bytes(), self.original)
        directory = Path(result["report_path"]).parent
        for line in (directory / "SHA256SUMS.txt").read_text().splitlines():
            digest, filename = line.split("  ", 1)
            self.assertEqual(hashlib.sha256((directory / filename).read_bytes()).hexdigest(), digest)
        if sys.platform.startswith("linux"):
            self.assertEqual(directory.stat().st_mode & 0o777, 0o700)
            self.assertEqual(Path(result["evidence_path"]).stat().st_mode & 0o777, 0o600)

    def test_tls_finding_requires_actual_negotiation_of_that_version(self):
        def tls(host, port, timeout, legacy=None):
            if legacy == ssl.TLSVersion.TLSv1:
                raise ssl.SSLError("protocol rejected")
            return {"service": "tls", "status": "identified", "version": "TLSv1.1" if legacy else "TLSv1.3"}
        with patch.object(vuln, "tls_check", side_effect=tls):
            result = vuln.inspect_service("::1", 443, 1, {3222})
        self.assertEqual([entry["id"] for entry in result["findings"]], ["LEGACY-TLSv1.1"])
        self.assertEqual(result["findings"][0]["status"], "confirmed")

    @unittest.skipUnless(socket.has_ipv6 and shutil.which("openssl"), "IPv6 and openssl required")
    def test_real_tls_over_ipv6_records_negotiation_without_claiming_certificate_trust(self):
        root = Path(self.folder.name)
        cert, key = root / "cert.pem", root / "key.pem"
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
                        "-subj", "/CN=localhost", "-keyout", str(key), "-out", str(cert)],
                       capture_output=True, check=True, timeout=10)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(cert, key)
        errors = []
        with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as listener:
            listener.bind(("::1", 0))
            listener.listen(1)
            listener.settimeout(3)
            port = listener.getsockname()[1]
            def serve():
                try:
                    connection, _ = listener.accept()
                    with connection, context.wrap_socket(connection, server_side=True):
                        pass
                except Exception as error:
                    errors.append(error)
            thread = threading.Thread(target=serve, daemon=True)
            thread.start()
            result = vuln.tls_check("::1", port, 2)
            thread.join(3)
        self.assertFalse(errors)
        self.assertFalse(thread.is_alive())
        self.assertEqual(result["version"], "TLSv1.2")
        self.assertFalse(result["certificate_trust_checked"])
        self.assertEqual(result["certificate_sha256"], hashlib.sha256(ssl.PEM_cert_to_DER_cert(cert.read_text())).hexdigest())

    def test_nvd_keyword_matches_stay_unverified_and_network_errors_are_explicit(self):
        payload = {"totalResults": 1, "vulnerabilities": [{"cve": {"id": "CVE-2025-12345",
                    "descriptions": [{"lang": "en", "value": "Requires configuration not observed here."}]}}]}
        with patch.object(vuln.urllib.request, "urlopen", return_value=io.BytesIO(json.dumps(payload).encode())) as request:
            result = vuln.lookup_nvd("OpenSSH", "8.2p1")
        self.assertEqual(result["matching"], "keyword_only")
        self.assertEqual(result["candidates"][0]["status"], "unverified")
        self.assertIn("keywordSearch=OpenSSH+8.2p1", request.call_args.args[0].full_url)
        with patch.object(vuln.urllib.request, "urlopen", side_effect=urllib.error.URLError("offline")):
            result = vuln.lookup_nvd("OpenSSH", "8.2p1")
        self.assertEqual(result["status"], "error")

    def test_cve_candidates_never_become_confirmed_findings(self):
        service = {"port": 2222, "checks": [], "findings": [],
                   "software": [{"product": "OpenSSH", "version": "8.2p1"}]}
        lookup = {"query": "OpenSSH 8.2p1", "status": "completed", "candidates": [
            {"id": "CVE-2025-12345", "url": "https://nvd.nist.gov/vuln/detail/CVE-2025-12345", "status": "unverified"}]}
        with patch.object(self.app, "scan_ports", return_value=self.scan()), \
                patch.object(vuln, "inspect_service", return_value=service), \
                patch.object(vuln, "lookup_nvd", return_value=lookup):
            result = vuln.run_vulnerability_scan(self.app, "::1", [2222], cves=True)
        self.assertEqual(result["summary"], {"confirmed": 0, "observations": 0, "cve_candidates": 1})
        self.assertEqual(result["findings"], [])
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_cancellation_preserves_port_evidence_in_private_report(self):
        with patch.object(self.app, "scan_ports", return_value=self.scan()), \
                patch.object(tvbox, "parallel_tasks", side_effect=KeyboardInterrupt):
            result = vuln.run_vulnerability_scan(self.app, "::1", [2222])
        saved = json.loads(Path(result["evidence_path"]).read_text())
        self.assertEqual(saved["status"], "cancelled")
        self.assertEqual(saved["port_scan"]["ports"], self.scan()["ports"])

    def test_unreachable_services_are_inconclusive_not_completed_with_zero_findings(self):
        scan = {"family": "IPv6", "ip": "::1", "ports": [{"port": 3222, "state": "no_response"}]}
        with patch.object(self.app, "scan_ports", return_value=scan), patch.object(vuln, "inspect_service") as inspect:
            result = vuln.run_vulnerability_scan(self.app, "::1", [3222])
        inspect.assert_not_called()
        self.assertEqual(result["status"], "inconclusive")
        self.assertEqual(json.loads(Path(result["evidence_path"]).read_text())["status"], "inconclusive")
        self.assertIn("inconcluso", Path(result["report_path"]).read_text())

    def test_last_scanned_ipv6_is_default_for_vulnerability_menu(self):
        self.app.last_port_scan = self.scan()
        result = {"operation": "vulnerability-scan", "ip": "::1", "status": "completed", "services": [],
                  "findings": [], "cve_lookups": [], "summary": {"confirmed": 0, "observations": 0, "cve_candidates": 0},
                  "report_path": "report.md", "evidence_path": "evidence.json"}
        with patch("builtins.input", side_effect=["", "", "", "0"]), \
                patch.object(vuln, "run_vulnerability_scan", return_value=result) as scan, redirect_stdout(io.StringIO()):
            tvbox.vulnerability_menu(self.app)
        scan.assert_called_once_with(self.app, "::1", [2222], 2.0, False)
        self.assertEqual(self.config.read_bytes(), self.original)


if __name__ == "__main__":
    unittest.main()
