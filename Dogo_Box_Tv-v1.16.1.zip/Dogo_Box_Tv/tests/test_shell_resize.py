"""Real local PTY regression: resizing must preserve the interactive shell."""
import os
from pathlib import Path
import select
import shutil
import signal
import sys
import tempfile
import time
import unittest


@unittest.skipUnless(os.name == 'posix' and shutil.which('tmux') and shutil.which('stty'), 'requires POSIX PTY, tmux and stty')
class ShellResizeTests(unittest.TestCase):
    def test_android_prefix_resize_in_both_directions_preserves_shell_and_exit_status(self):
        import fcntl
        import pty
        import struct
        import termios
        root = str(Path(__file__).resolve().parents[1])
        with tempfile.TemporaryDirectory(prefix='dogo android ') as folder:
            prefix = Path(folder)/'fork/files/usr'
            (prefix/'bin').mkdir(parents=True)
            (prefix/'bin/sh').symlink_to(shutil.which('sh'))
            (prefix/'bin/pkg').write_text('')
            environment = {**os.environ, 'HOME': folder, 'PREFIX': str(prefix), 'TERMUX_VERSION': 'simulated',
                           'PATH': str(prefix/'bin')+os.pathsep+os.environ['PATH'], 'TERM': 'xterm-256color',
                           'PS1': 'DOGO_PROMPT>'}
            command = ('import shell_frame; print("EXIT_CODE", shell_frame.framed_shell(['
                       + repr(str(prefix/'bin/sh')) + '], "Dogo_Box_Tv · Android"))')
            pid, descriptor = pty.fork()
            if pid == 0:
                try:
                    os.chdir(root)
                    os.execve(sys.executable, [sys.executable, '-c', command], environment)
                finally:
                    os._exit(127)
            buffered = bytearray()
            def resize(rows, columns):
                fcntl.ioctl(descriptor, termios.TIOCSWINSZ, struct.pack('HHHH', rows, columns, 0, 0))
            def until(value):
                expected = value.encode()
                deadline = time.monotonic()+7
                while expected not in buffered:
                    remaining = deadline-time.monotonic()
                    if remaining <= 0:
                        self.fail('Missing terminal output: '+repr(value)+'; tail='+repr(bytes(buffered[-500:])))
                    ready, _, _ = select.select([descriptor], [], [], remaining)
                    if ready:
                        try:
                            chunk = os.read(descriptor, 65536)
                        except OSError:
                            chunk = b''
                        if not chunk:
                            self.fail('PTY closed before '+repr(value))
                        buffered.extend(chunk)
                del buffered[:buffered.index(expected)+len(expected)]
            def send(command):
                os.write(descriptor, command.encode()+b'\r')
            try:
                resize(18, 36)
                until('DOGO_PROMPT>')
                send("DOGO_TEST_VALUE=preserved; printf '\\nSIZE_A:'; stty size")
                until('SIZE_A:16 34')
                resize(20, 48)
                until('╰'+'─'*46+'╯')
                until('DOGO_PROMPT>')
                send("printf '\\nSIZE_B:'; stty size")
                until('SIZE_B:18 46')
                resize(18, 32)
                until('╰'+'─'*30+'╯')
                until('DOGO_PROMPT>')
                send("printf '\\nSIZE_C:'; stty size")
                until('SIZE_C:16 30')
                send("printf '\\nVALUE:%s\\n' \"$DOGO_TEST_VALUE\"")
                until('VALUE:preserved')
                send('exit 7')
                until('EXIT_CODE 7')
                os.waitpid(pid, 0)
                pid = None
            finally:
                os.close(descriptor)
                if pid is not None:
                    try:
                        os.kill(pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    os.waitpid(pid, 0)


if __name__ == '__main__':
    unittest.main()
