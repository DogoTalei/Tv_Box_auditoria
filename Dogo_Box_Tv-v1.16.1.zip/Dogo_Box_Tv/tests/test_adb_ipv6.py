from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox


class AdbIPv6Tests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.config = Path(self.folder.name) / "config.json"
        self.config.write_text(json.dumps({"device": "192.168.0.101:3222", "output_dir": "salidas", "stream_profile": "fluido"}))
        self.original = self.config.read_bytes()
        self.ui = tvbox.UI.machine, tvbox.UI.mode
        args = tvbox.parser().parse_args(["--config", str(self.config), "--json", "devices"])
        self.app = tvbox.App(args)
        self.target = "[fe80::20%wlan-test]:3222"
        self.interface_patch = patch.object(tvbox.socket, "if_nametoindex", return_value=6)
        self.name_patch = patch.object(tvbox.socket, "if_indextoname", return_value="wlan-test")
        self.interface_patch.start()
        self.name_patch.start()

    def tearDown(self):
        self.interface_patch.stop()
        self.name_patch.stop()
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)
        tvbox.UI.machine, tvbox.UI.mode = self.ui
        self.folder.cleanup()

    def connected_responses(self):
        return [subprocess.CompletedProcess([], 0, b"connected", b""),
                subprocess.CompletedProcess([], 0, b"device\n", b"")]

    def test_connect_scoped_ipv6_verifies_exact_serial_and_selects_temporarily(self):
        with patch.object(self.app, "run_adb", side_effect=self.connected_responses()) as adb:
            result = self.app.connect(self.target)
        self.assertEqual(adb.call_args_list[0].args[0], ["connect", self.target])
        self.assertEqual(adb.call_args_list[1].args[0], ["-s", self.target, "get-state"])
        self.assertEqual(result["state"], "device")
        self.assertEqual(self.app.device, self.target)
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_selection_with_interface_persists_ipv6_only_after_verified_connection(self):
        with patch.object(self.app, "run_adb", side_effect=self.connected_responses()):
            self.app.select_target("fe80::20", 3222, interface="wlan-test", mac="2c:73:60:f1:78:d0")
        saved = json.loads(self.config.read_text())
        self.assertEqual(saved["device"], self.target)
        self.assertEqual(saved["selected_target"]["ip"], "fe80::20%wlan-test")
        self.assertEqual(saved["selected_target"]["family"], "IPv6")
        self.assertEqual(saved["selected_target"]["mac"], "2C:73:60:F1:78:D0")
        self.assertEqual(saved["stream_profile"], "fluido")

    def test_unauthorized_and_offline_never_replace_saved_selection(self):
        for state, stderr in ((b"unauthorized", b""), (b"", b"error: device unauthorized"), (b"offline", b"")):
            responses = [subprocess.CompletedProcess([], 0, b"connected", b""),
                         subprocess.CompletedProcess([], 1, state, stderr)]
            with self.subTest(state=state, stderr=stderr), patch.object(self.app, "run_adb", side_effect=responses):
                with self.assertRaises(tvbox.ToolError) as caught:
                    self.app.select_target("fe80::20%wlan-test", 3222)
            if b"unauthorized" in state + stderr:
                self.assertIn("requiere autorización", str(caught.exception))
            self.assertEqual(self.config.read_bytes(), self.original)
            self.assertEqual(self.app.device, "192.168.0.101:3222")

    def test_invalid_addresses_never_invoke_adb(self):
        for address in ("fe80::20:3222", "[fe80::20]:3222", "[fe80::20%wlan-test]:0",
                        "[fe80::20%wlan-test]:65536", "[192.168.0.101]:3222", "--help:5555",
                        "[fe80::20%wlan-test]:3222;id"):
            with self.subTest(address=address), patch.object(self.app, "run_adb") as adb:
                with self.assertRaises(tvbox.ToolError):
                    self.app.connect(address)
                adb.assert_not_called()

    def test_dns_and_global_ipv6_connections_remain_supported(self):
        for address in ("android.local:5555", "[2001:db8::20]:5555"):
            with self.subTest(address=address), patch.object(self.app, "run_adb", side_effect=self.connected_responses()):
                self.assertEqual(self.app.connect(address)["device"], address)

    def test_failed_save_restores_in_memory_selection_after_successful_connection(self):
        def connect(target):
            self.app.device = target
        with patch.object(self.app, "connect", side_effect=connect), \
                patch.object(tvbox, "publish", side_effect=OSError("disk full")):
            with self.assertRaises(OSError):
                self.app.select_target("fe80::20%wlan-test", 3222)
        self.assertEqual(self.app.device, "192.168.0.101:3222")
        self.assertEqual(self.config.read_bytes(), self.original)
        self.assertEqual(list(self.config.parent.glob("*.part")), [])

    def test_ensure_device_reconnects_saved_scoped_ipv6(self):
        self.app.device = self.target
        responses = [subprocess.CompletedProcess([], 1, b"", b"offline"), *self.connected_responses()]
        with patch.object(self.app, "run_adb", side_effect=responses) as adb:
            self.app.ensure_device()
        self.assertEqual(adb.call_args_list[1].args[0], ["connect", self.target])
        self.assertEqual(adb.call_args_list[2].args[0], ["-s", self.target, "get-state"])

    def test_programmatic_adb_keeps_ipv6_serial_and_does_not_consume_menu_input(self):
        self.app.device = self.target
        self.app.adb = "/mock/adb"
        with patch.object(tvbox.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, b"AndroidTV", b"")) as run:
            self.app.run_adb(["shell", "getprop", "ro.product.model"])
        self.assertEqual(run.call_args.args[0], ["/mock/adb", "-s", self.target, "shell", "getprop", "ro.product.model"])
        self.assertEqual(run.call_args.kwargs["stdin"], subprocess.DEVNULL)

    def test_menu_connects_last_ipv6_with_selected_port_and_persists(self):
        self.app.last_port_scan = {"ip": "fe80::20%wlan-test", "ports": [{"port": 3222, "state": "open"}]}
        self.app.discovered_hosts = [{"ip": "fe80::20%wlan-test", "mac": "2C:73:60:F1:78:D0",
                                      "is_local": False, "evidence": "icmp_reply"}]
        output = io.StringIO()
        with patch.object(sys.stdin, "isatty", return_value=True), redirect_stdout(output), \
                patch.object(self.app, "run_adb", side_effect=self.connected_responses()), \
                patch("builtins.input", side_effect=["17", "", "", "1", "0"]):
            tvbox.menu(self.app)
        self.assertEqual(json.loads(self.config.read_text())["device"], self.target)
        self.assertIn("ADB verificado", output.getvalue())


if __name__ == "__main__":
    unittest.main()
