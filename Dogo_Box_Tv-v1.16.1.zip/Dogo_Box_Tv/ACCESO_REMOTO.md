# Acceso al TV-box desde fuera de la red local

Firma: Dogo. Diagnóstico: 2026-11-11 09:43:07 CST.

## Objetivo y estado

El propietario quiere acceder a su propio TV-box desde Internet para utilizar la conexión ADB y las funciones de Dogo_Box_Tv. El acceso externo todavía **no está configurado ni comprobado**.

Diagnóstico de solo lectura realizado en el equipo seleccionado:

- ADB local operativo en `[fe80::2e73:60ff:fef1:78d0%wlan0]:3222`.
- Puerto ADB configurado: `3222`; `ss -lnt` confirma escucha TCP en `*:3222`.
- API declarada por el sistema: `28`; arquitecturas `armeabi-v7a,armeabi`.
- La propiedad de versión Android muestra `16`, pero ese texto no sustituye la API para evaluar compatibilidad.
- Características `android.hardware.type.television` y `android.software.leanback` presentes.
- Play Store instalada. No se encontró Tailscale ni WireGuard; la opción Android de VPN siempre activa devuelve `null`.
- La identidad actual de ADB es `uid=2000(shell)`, contexto `shell`. El root observado en la sesión anterior no se mantiene en esta conexión.
- La PC no tiene los comandos `tailscale` ni `wg` disponibles en PATH.

Escuchar en TCP en la red local no crea automáticamente acceso desde Internet. No se modificaron el router, el firewall, el puerto ADB, la configuración guardada ni los privilegios.

## Vía propuesta: red privada con Tailscale

Tailscale documenta compatibilidad con Android 8 o posterior y Android TV. Permite conectar equipos autorizados usando direcciones de su red privada; normalmente no requiere abrir puertos entrantes en el router y puede utilizar relés cuando no hay conexión directa.

Se necesita registrar el TV-box y el equipo desde el que se administrará en la misma red Tailscale, con una política que permita al administrador acceder al TCP 3222 del TV-box. El inicio de sesión pertenece al usuario. No se necesitan compartir contraseñas o claves de autenticación en el chat.

Pasos pendientes si se elige esta vía:

1. Instalar la aplicación oficial Tailscale en el TV-box y el cliente en el equipo que se usará desde fuera.
2. Abrir Tailscale en el TV-box, registrar el dispositivo mediante el código/QR o el flujo de inicio de sesión correspondiente y aceptar la configuración VPN de Android.
3. Registrar el equipo administrador en la misma red privada. Revisar que las reglas de acceso permiten TCP 3222 solo a los dispositivos/usuarios previstos.
4. Obtener la dirección privada Tailscale del TV-box y verificar que ADB recibe conexiones en ella. No se puede presuponer este resultado solo por instalar la aplicación.
5. En Dogo_Box_Tv, usar la opción 17 con esa dirección y puerto 3222. La opción guarda el destino únicamente después de verificar la conexión.
6. Comprobar desde una conexión ajena a la LAN, por ejemplo compartiendo datos móviles, que la opción 2 y la shell funcionan. Una prueba desde la LAN no demuestra por sí sola acceso externo.
7. Comprobar el comportamiento tras reiniciar el TV-box y las opciones de VPN siempre activa/ahorro de energía que admita su firmware. No se cambió ninguna de ellas en este diagnóstico.

La red privada transporta el TCP de ADB. Las funciones de shell, capturas e imágenes deberían poder usar esa misma conexión una vez validada; el rendimiento del directo dependerá de la ruta y el ancho de banda, en especial si se usa un relé.

## Alternativa si ya existe infraestructura propia

Puede utilizarse una VPN existente del propietario o un acceso autenticado mediante su servidor. Faltan los datos de esa infraestructura para concretar una configuración. No se abrió un puerto ADB público ni se instaló un mecanismo de acceso persistente.

## Fuentes oficiales consultadas

- Android y Android TV: https://tailscale.com/docs/install/android
- Conectar equipos y servicios: https://tailscale.com/docs/how-to/connect-to-devices
- Puertos y relés: https://tailscale.com/docs/reference/faq/firewall-ports
- Paquetes oficiales: https://pkgs.tailscale.com/stable/

## Siguiente dato necesario

Está pendiente la elección del propietario entre configurar Tailscale, usar su Tailscale existente o aprovechar otra VPN/servidor propio. También quedará pendiente su inicio de sesión y aceptación de la VPN en Android si se utiliza Tailscale.


## 2026-11-11 13:39:48 CST — Objetivo precisado: la TV-box aloja los servicios

El propietario desea usar la TV-box como servidor propio, con acceso desde Internet, sin depender de otro VPS para alojar los servicios. Una VPN sería únicamente un medio posible de acceso; no sustituye al servidor que quiere alojar en el TV-box.

Capacidad observada: ARMv7 de 32 bits, kernel 4.9.118_D9, 1 GiB de RAM total, unos 247 MiB de memoria disponible durante la consulta y 346 MB libres en /data. Ese espacio libre limita las instalaciones. Una primera etapa razonable es un servidor SSH ligero con autenticación por clave; Termux/OpenSSH es una opción de código abierto compatible con la API observada. No se instalaron paquetes ni se activó SSH en esta revisión.

Red observada: la TV-box tiene 192.168.0.101/24, sin IPv6 global en las interfaces consultadas. Mediante descubrimiento UPnP del router 192.168.0.1 y una consulta de solo lectura GetExternalIPAddress se obtuvo WAN **192.168.9.102**, que es una dirección privada. Esto demuestra una capa previa de enrutamiento/NAT, pero no permite distinguir un módem/router del propietario de una traducción del proveedor; **no confirma CGNAT por sí solo**.

Para ofrecer conexiones entrantes directas hay que conocer y configurar, si corresponde, el módem/router anterior o solicitar al proveedor una dirección pública alcanzable. Una redirección en el TP-Link por sí sola no garantiza acceso desde fuera. No se crearon redirecciones, no se abrió ADB a Internet y no se cambiaron privilegios o configuración del dispositivo.

Siguiente dato necesario: si el propietario controla otro módem/router antes del TP-Link y puede consultar su dirección WAN y configuración. El acceso externo continúa pendiente y no se ha probado desde otra red.

Evidencia local: /home/dogo/tvbox-tools/salidas/diagnostico-servidor-tvbox-20261111-133948.json.


## 2026-11-11 13:46:58 CST — Requisito de dirección fija

El propietario requiere una dirección permanente para volver a conectarse desde otra red. Si se elige un servicio onion v3, su identidad y dirección deben conservarse en un directorio persistente; no se regenerarán las claves al reiniciar ni al iniciar el menú. Se necesita respaldo privado de esa identidad para conservar la dirección ante reinstalación o pérdida del almacenamiento. La dirección permanece independiente de los cambios de IP de la conexión; la disponibilidad sigue dependiendo de que la TV-box y Tor estén funcionando y tengan conectividad. El cliente remoto necesita acceso a Tor.

El propietario informa que solo tiene el router observado, sin un módem/router adicional bajo su control. La capa de NAT previa podría corresponder al proveedor; no se ha confirmado CGNAT. No se han instalado todavía Termux, SSH ni Tor, ni se ha generado una dirección .onion. La elección final del método de acceso sigue por concretar; se ha validado que onion v3 puede cumplir el requisito de dirección estable.

Referencia: https://community.torproject.org/onion-services/setup/ (directorio persistente del servicio, identidad privada, hostname y respaldo).
