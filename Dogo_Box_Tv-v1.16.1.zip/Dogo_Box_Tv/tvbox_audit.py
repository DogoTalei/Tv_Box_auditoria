"""Read-only audit orchestration. The app supplies TCP and ADB operations."""
from __future__ import annotations

import datetime as dt
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
from urllib.parse import urlencode
import uuid
import xml.etree.ElementTree as ET

from branding import APP_NAME, AUTHOR, SIGNATURE


def default_ports(device):
    ports = {22, 23, 53, 80, 139, 443, 445, 554, 1900, 3222, 5000, 5555, 8000, 8080, 8443, 9000, 40000}
    if device and ":" in device:
        port = device.rsplit(":", 1)[1]
        if port.isdecimal() and 1 <= int(port) <= 65535:
            ports.add(int(port))
    return sorted(ports)


def stamp():
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def write_json(path, value):
    temporary = path.with_name("." + path.name + "." + uuid.uuid4().hex)
    try:
        with temporary.open("x", encoding="utf-8") as handle:
            os.chmod(temporary, 0o600)
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def classify_rounds(rounds, expected_rounds=None):
    """Report inconsistent observations rather than guessing firewall behavior."""
    observations = {}
    for result in rounds:
        for item in result["ports"]:
            observations.setdefault(item["port"], []).append(item)
    ports = []
    for port, samples in sorted(observations.items()):
        states = [sample["state"] for sample in samples]
        if len(set(states)) == 1 and len(states) >= 2 and len(states) == (expected_rounds or len(rounds)):
            state = {"open": "confirmed_open", "closed": "confirmed_closed",
                     "no_response": "no_response", "unreachable": "unreachable", "error": "error"}[states[0]]
        else:
            state = "inconsistent"
        ports.append({"port": port, "protocol": "tcp", "classification": state,
                      "open_observations": states.count("open"), "observations": samples})
    return ports


def recognition(host):
    result = {"ip": host, "mac": None, "mac_evidence": "not_observed"}
    binary = shutil.which("ip")
    if not binary:
        result["limitation"] = "iproute2 no disponible; reconocimiento de ruta/MAC omitido."
        return result
    route = subprocess.run([binary, "-j", "-4", "route", "get", host], capture_output=True, timeout=5)
    if route.returncode:
        result["limitation"] = "No se pudo consultar la ruta al destino."
        return result
    routes = json.loads(route.stdout)
    result["routes"] = routes
    if not routes:
        return result
    interface = routes[0].get("dev")
    result["interface"] = interface
    if interface:
        neighbor = subprocess.run([binary, "-j", "-4", "neigh", "show", "to", host, "dev", interface],
                                  capture_output=True, timeout=5)
        if neighbor.returncode == 0:
            for entry in json.loads(neighbor.stdout):
                mac = entry.get("lladdr", "").upper()
                if (entry.get("dst") == host and re.fullmatch(r"(?:[0-9A-F]{2}:){5}[0-9A-F]{2}", mac)
                        and not any(state in entry.get("state", []) for state in ("FAILED", "INCOMPLETE"))):
                    result.update(mac=mac, mac_evidence="neighbor_cache", neighbor_state=entry.get("state"))
    return result


def service_scan(host, ports, directory):
    binary = shutil.which("nmap")
    if not binary:
        raise ValueError("Nmap no está instalado. La confirmación TCP sigue disponible sin él.")
    command = [binary, "-sT", "-sV", "--version-light", "-Pn", "-n", "--reason", "--max-retries", "1",
               "--host-timeout", "60s", "-p", ",".join(map(str, ports)), "-oX", "-", host]
    process = subprocess.run(command, capture_output=True, timeout=75)
    raw = process.stdout
    (directory / "nmap.xml").write_bytes(raw)
    os.chmod(directory / "nmap.xml", 0o600)
    if process.returncode:
        raise ValueError("Nmap no terminó correctamente: " + process.stderr.decode(errors="replace")[-1000:])
    document = ET.fromstring(raw)
    completed = document.find("runstats/finished")
    if completed is None or completed.get("exit") != "success":
        raise ValueError("Nmap no confirmó la finalización del análisis; consulta nmap.xml.")
    hosts = [node for node in document.findall("host")
             if any(address.get("addr") == host for address in node.findall("address"))]
    if not hosts or any(node.get("timedout") == "true" for node in hosts):
        raise ValueError("Nmap no completó el destino dentro del plazo; consulta nmap.xml.")
    services = []
    for node in hosts:
        for port in node.findall("ports/port"):
            number = int(port.get("portid"))
            if number not in ports:
                continue
            state, service = port.find("state"), port.find("service")
            item = {"port": number, "state": state.get("state") if state is not None else "unknown",
                    "evidence": "active_nmap_probes"}
            if service is not None:
                item["service"] = dict(service.attrib)
                item["identification"] = "active_probe_match" if service.get("method") == "probed" else "port_table_hint_unverified"
                item["cpe"] = [cpe.text for cpe in service.findall("cpe") if cpe.text]
                query = " ".join(service.get(field, "") for field in ("product", "version")).strip()
                if query:
                    item["advisory_search"] = "https://nvd.nist.gov/vuln/search/results?" + urlencode({"query": query, "search_type": "all"})
            services.append(item)
    return {"method": "nmap_version_light", "command": command, "services": services,
            "raw_evidence": "nmap.xml", "cve_status": "not_verified"}


PROPERTIES = {"ro.product.manufacturer", "ro.product.model", "ro.product.device", "ro.build.fingerprint",
              "ro.build.version.release", "ro.build.version.sdk", "ro.build.version.security_patch",
              "ro.build.date.utc", "ro.secure", "ro.adb.secure", "ro.debuggable", "service.adb.tcp.port",
              "persist.adb.tcp.port"}


def android_inventory(app, inventory=None):
    app.ensure_device()
    commands = {"properties": ["getprop"], "identity": ["id"], "selinux": ["getenforce"],
                "system_packages": ["pm", "list", "packages", "-s"], "processes": ["ps", "-A"],
                "listeners": ["ss", "-lntu"], "connections": ["ss", "-ntu"]}
    if inventory is None:
        inventory = {"device": app.device, "queries": {}, "errors": []}
    inventory["connection_verified"] = True
    for label, command in commands.items():
        app.note("Android: consultando " + label + "…")
        try:
            response = app.run_adb(["shell", *command], check=False, timeout=15)
            if response.returncode and label in ("listeners", "connections"):
                response = app.run_adb(["shell", "netstat", "-lntu" if label == "listeners" else "-ntu"],
                                       check=False, timeout=15)
            if response.returncode:
                inventory["errors"].append({"query": label, "error": response.stderr.decode(errors="replace")[-1000:]})
                continue
            output = response.stdout.decode(errors="replace")
            if label == "properties":
                inventory["properties"] = {key: value for key, value in re.findall(r"^\[([^]]+)\]: \[(.*)\]$", output, re.M)
                                           if key in PROPERTIES}
            else:
                inventory["queries"][label] = {"output": output[:200_000], "truncated": len(output) > 200_000}
        except Exception as error:
            inventory["errors"].append({"query": label, "error": str(error)})
    return inventory


def assess(result):
    findings = []
    def add(title, priority, evidence, recommendation):
        findings.append(dict(title=title, priority=priority, evidence=evidence, recommendation=recommendation))
    confirmed = [item["port"] for item in result.get("ports", []) if item["classification"] == "confirmed_open"]
    if confirmed:
        add("Servicios TCP accesibles en la red", "revisar", str(confirmed),
            "Identificar cada servicio y restringir los que no sean necesarios. Un puerto abierto por sí solo no confirma una vulnerabilidad.")
    inventory = result.get("android") or {}
    properties = inventory.get("properties", {})
    for key, bad, title in (("ro.adb.secure", "0", "Android declara ADB seguro deshabilitado"),
                            ("ro.secure", "0", "Android declara ro.secure=0"),
                            ("ro.debuggable", "1", "Compilación de Android depurable")):
        if properties.get(key) == bad:
            add(title, "prioritario", f"{key}={bad}",
                "Revisar autenticación efectiva de ADB y usar firmware mantenido. Esta propiedad aislada no demuestra un acceso sin autorización.")
    queries = inventory.get("queries", {})
    if queries.get("selinux", {}).get("output", "").strip().lower() == "permissive":
        add("SELinux en modo permisivo", "prioritario", "getenforce: Permissive",
            "Evaluar firmware con SELinux enforcing y soporte del fabricante.")
    if re.search(r"\buid=0\b", queries.get("identity", {}).get("output", "")):
        add("La sesión ADB actual tiene privilegios root", "prioritario", queries["identity"]["output"],
            "Limitar el acceso de depuración y revisar la configuración de fábrica. No se intentó elevar privilegios.")
    patch = properties.get("ro.build.version.security_patch", "")
    try:
        age = (dt.date.today() - dt.date.fromisoformat(patch)).days
        if age > 365:
            add("Parche declarado de seguridad de más de un año", "revisar", patch,
                "Confirmar con el fabricante la fecha real del firmware y sus actualizaciones; la propiedad puede ser incorrecta.")
    except ValueError:
        pass
    return findings


def markdown(result):
    def clean(value):
        return re.sub(r"[\x00-\x1f\x7f]", " ", str(value)).replace("|", "\\|").replace("`", "'").replace("<", "&lt;")
    lines = [f"# {APP_NAME} · Auditoría", "", SIGNATURE, "", f"Destino: {clean(result['device'])}",
             f"Fecha: {result['started_at']} · Estado: {result['status']}", "", "## Etapas", ""]
    lines += [f"- {clean(stage['name'])}: {stage['status']}" + (f" — {clean(stage.get('error') or stage.get('reason'))}" if stage.get('error') or stage.get('reason') else "") for stage in result["stages"]]
    lines += ["", "## Puertos TCP", "", "| Puerto | Clasificación | Respuestas abiertas |", "|---|---|---|"]
    lines += [f"| {item['port']} | {item['classification']} | {item['open_observations']}/{len(item['observations'])} |" for item in result.get("ports", [])]
    lines += ["", "## Observaciones y medidas", ""]
    for finding in result["findings"]:
        lines += [f"### {clean(finding['title'])}", "", "Prioridad de revisión: " + finding["priority"],
                  "", "Evidencia: " + clean(finding["evidence"]), "", clean(finding["recommendation"]), ""]
    if not result["findings"]:
        lines += ["No se generaron observaciones automáticas; esto no demuestra ausencia de riesgos."]
    lines += ["", "## Versiones y CVE", "", "Las versiones y CPE son identificaciones observadas, no vulnerabilidades confirmadas. No se verificaron CVE, parches retroportados ni explotación.",
              "Las etiquetas de una tabla de puertos son hipótesis; solo una coincidencia de sondas aporta identificación activa.", ""]
    for service in (result.get("services") or {}).get("services", []):
        lines.append(f"- Puerto {service['port']}: {clean(service.get('service', {}))} · Evidencia: {service.get('identification', 'unknown')}")
        if service.get("advisory_search"):
            lines.append("  Investigación manual: " + service["advisory_search"])
    if (result.get("android") or {}).get("connection_verified"):
        lines += ["", f"La conexión ADB seleccionada ({clean(result['device'])}) fue verificada mediante ADB. Esto no demuestra que se acepten clientes sin autorizar; la clave de este ordenador puede estar autorizada."]
    lines += ["", "## Límites", ""] + ["- " + value for value in result["limitations"]]
    lines += ["", "Los inventarios y direcciones pueden ser privados. Revisa y redacta los datos antes de publicar.",
              "", "Evidencias detalladas en auditoria.json; integridad en SHA256SUMS.txt."]
    return "\n".join(lines) + "\n"


def run_audit(app, args):
    if not app.device:
        raise ValueError("Selecciona primero la IP del TV-box con select o la opción 10.")
    if app.device.startswith("["):
        raise ValueError("La auditoría de la opción 13 requiere IPv4. Para revisar una IPv6 utiliza la opción 16; la conexión ADB IPv6 está disponible en 17.")
    host = str(ipaddress.IPv4Address(app.device.split(":", 1)[0]))
    ports = args.ports if args.ports is not None else default_ports(app.device)
    if (args.rounds not in (2, 3) or not ports or len(ports) > 4096
            or any(type(port) is not int or not 1 <= port <= 65535 for port in ports)
            or not 0.1 <= args.timeout <= 10):
        raise ValueError("La auditoría requiere 2 o 3 rondas y entre 1 y 4096 puertos.")
    run_id = dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]
    directory = app.output / ("auditoria-" + run_id)
    directory.mkdir(mode=0o700)
    result = {"operation": "audit", "tool_name": APP_NAME, "author": AUTHOR,
              "tool_version": app.version, "run_id": run_id, "device": app.device, "ip": host,
              "started_at": stamp(), "status": "running", "stages": [], "findings": [],
              "scope": {"ports": ports, "rounds": args.rounds, "timeout": args.timeout,
                        "services": args.services, "adb_inventory": args.adb_inventory},
              "report_path": str(directory / "reporte.md"), "evidence_path": str(directory / "auditoria.json"),
              "limitations": ["El alcance incluye solo la IP seleccionada y los puertos TCP indicados; no toda la red ni UDP.",
                               "Sin respuesta no confirma filtrado ni un servicio oculto. Se conservan todas las observaciones.",
                               "Una conexión rechazada puede deberse al destino o a un filtro; no se atribuye automáticamente a un cortafuegos.",
                               "La MAC proviene de la tabla de vecinos y puede estar desactualizada o no estar disponible.",
                               "No se verificaron CVE. El inventario no demuestra malware, publicidad, ausencia de autenticación ni configuración de fábrica.",
                               "No se instalaron apps, elevaron privilegios, capturaron pantallas ni modificaron ajustes de Android."]}
    def checkpoint():
        write_json(directory / "auditoria.json", result)
        report = directory / "reporte.md"
        report.write_text(markdown(result), encoding="utf-8")
        os.chmod(report, 0o600)
        files = [path for path in directory.iterdir() if path.is_file() and path.name != "SHA256SUMS.txt"]
        (directory / "SHA256SUMS.txt").write_text("".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.name + "\n" for path in sorted(files)), encoding="utf-8")
        os.chmod(directory / "SHA256SUMS.txt", 0o600)
    def stage(name, action=None, reason=None):
        item = {"name": name, "status": "skipped" if reason else "running", "started_at": stamp()}
        result["stages"].append(item)
        app.note("Auditoría: " + name + (" (omitida: " + reason + ")" if reason else "…"))
        if reason:
            item["reason"] = reason
            checkpoint()
            return None
        checkpoint()
        try:
            value = action()
            item["status"] = "partial" if isinstance(value, dict) and (value.get("errors") or value.get("summary", {}).get("error")) else "completed"
            return value
        except KeyboardInterrupt:
            item["status"] = "cancelled"
            raise
        except Exception as error:
            item.update(status="error", error=str(error))
            return None
        finally:
            item["ended_at"] = stamp()
            checkpoint()
    app.note("Carpeta de auditoría: " + str(directory))
    try:
        result["recognition"] = stage("Reconocimiento del destino", lambda: recognition(host))
        rounds = []
        result["rounds"] = rounds
        for index in range(args.rounds):
            sample = stage(f"Comprobación TCP {index + 1}/{args.rounds}",
                           lambda: app.scan_ports(ports, args.timeout, save_report=False))
            if sample is not None:
                rounds.append(sample)
            if index < args.rounds - 1:
                time.sleep(0.25)
        result["ports"] = classify_rounds(rounds, args.rounds)
        opened = [item["port"] for item in result["ports"] if item["classification"] == "confirmed_open"]
        result["services"] = stage("Identificación de servicios", lambda: service_scan(host, opened, directory),
                                   reason="No solicitado (--services)" if not args.services else "Sin puertos confirmados abiertos" if not opened else None)
        result["android"] = {"device": app.device, "queries": {}, "errors": []} if args.adb_inventory else None
        stage("Inventario Android", lambda: android_inventory(app, result["android"]),
              reason=None if args.adb_inventory else "No solicitado (--adb-inventory)")
        result["status"] = "partial" if any(item["status"] in ("error", "partial") for item in result["stages"]) else "completed"
    except KeyboardInterrupt:
        result["status"] = "cancelled"
    finally:
        if "rounds" in result:
            result["ports"] = classify_rounds(result["rounds"], args.rounds)
        result["findings"] = assess(result)
        result["ended_at"] = stamp()
        checkpoint()
    return result
