"""Bounded service checks; no shell commands, credential attempts or exploits."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import ssl
import struct
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import warnings

from branding import APP_NAME, AUTHOR, SIGNATURE, VERSION


DEFAULT_PORTS = [21, 22, 23, 80, 443, 3222, 5555, 8000, 8008, 8080, 8443]
HTTP_PORTS = {80, 81, 3000, 8000, 8008, 8080, 8081, 8888}
TLS_PORTS = {443, 8443, 9443}
NVD_API = "https://services.nvd.nist.gov/rest/json/cves/2.0"
ADB_REFERENCE = "https://android.googlesource.com/platform/packages/modules/adb/+/refs/heads/android14-release/protocol.txt"


def clean(value, limit=500):
    return re.sub(r"[\x00-\x1f\x7f]", " ", str(value))[:limit]


def dial(host, port, timeout):
    if ":" in host:
        base, _, zone = host.partition("%")
        scope = (int(zone) if zone.isdecimal() else socket.if_nametoindex(zone)) if zone else 0
        family, endpoint = socket.AF_INET6, (base, port, 0, scope)
    else:
        family, endpoint = socket.AF_INET, (host, port)
    connection = socket.socket(family, socket.SOCK_STREAM)
    connection.settimeout(timeout)
    try:
        connection.connect(endpoint)
        return connection
    except BaseException:
        connection.close()
        raise


def receive_exact(connection, length, deadline):
    data = bytearray()
    while len(data) < length:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("Plazo de lectura agotado")
        connection.settimeout(remaining)
        chunk = connection.recv(length-len(data))
        if not chunk:
            raise ValueError("Respuesta de protocolo incompleta")
        data.extend(chunk)
    return bytes(data)


def adb_check(host, port, timeout):
    """Only CNXN -> AUTH/CNXN. Never send a key, OPEN or a shell command."""
    command = int.from_bytes(b"CNXN", "little")
    payload = b"host::\0"
    packet = struct.pack("<6I", command, 0x01000000, 4096, len(payload), sum(payload), command ^ 0xffffffff) + payload
    with dial(host, port, timeout) as connection:
        deadline = time.monotonic() + timeout
        connection.sendall(packet)
        header = receive_exact(connection, 24, deadline)
        code, arg0, arg1, length, checksum, magic = struct.unpack("<6I", header)
        if magic != code ^ 0xffffffff or length > 4096 or code not in (
                int.from_bytes(b"AUTH", "little"), command):
            raise ValueError("La respuesta no identifica un saludo ADB válido")
        body = receive_exact(connection, length, deadline)
        skipped_checksum = code == command and arg0 >= 0x01000001 and checksum == 0
        if not skipped_checksum and sum(body) & 0xffffffff != checksum:
            raise ValueError("Checksum ADB inválido")
        if code == command:
            identity = body.split(b":", 2)
            if arg0 < 0x01000000 or len(identity) != 3 or identity[0] not in (b"device", b"bootloader", b"recovery"):
                raise ValueError("La identidad recibida no confirma un dispositivo ADB")
            status = "accepted_without_auth"
        else:
            if arg0 != 1 or not body:
                raise ValueError("Reto de autenticación ADB no reconocido")
            status = "authentication_required"
        return {"service": "adb", "status": status, "first_command": header[:4].decode("ascii"),
                "payload_sha256": hashlib.sha256(body).hexdigest(), "reference": ADB_REFERENCE}


def http_check(host, port, timeout):
    base = host.split("%", 1)[0]
    authority = f"[{base}]:{port}" if ":" in base else f"{base}:{port}"
    request = f"GET / HTTP/1.0\r\nHost: {authority}\r\nConnection: close\r\nUser-Agent: {APP_NAME}/{VERSION}\r\n\r\n".encode("ascii")
    with dial(host, port, timeout) as connection:
        deadline = time.monotonic() + timeout
        connection.sendall(request)
        response = bytearray()
        while b"\r\n\r\n" not in response and len(response) < 16384:
            remaining = deadline-time.monotonic()
            if remaining <= 0:
                raise TimeoutError("Plazo HTTP agotado")
            connection.settimeout(remaining)
            chunk = connection.recv(min(2048, 16384-len(response)))
            if not chunk:
                break
            response.extend(chunk)
    lines = bytes(response).split(b"\r\n\r\n", 1)[0].decode("iso-8859-1").split("\r\n")
    if not lines or not re.match(r"^HTTP/1\.[01] [1-5][0-9]{2}(?: |$)", lines[0]):
        raise ValueError("No se identificó una respuesta HTTP válida")
    allowed = {"server", "x-powered-by", "location", "www-authenticate"}
    headers = {}
    for line in lines[1:]:
        key, separator, value = line.partition(":")
        if separator and key.lower() in allowed:
            headers[key.lower()] = clean(value.strip(), 250)
    return {"service": "http", "status": "identified", "status_code": int(lines[0].split()[1]),
            "headers": headers, "encrypted": False}


def banner_check(host, port, timeout):
    with dial(host, port, min(timeout, 1.0)) as connection:
        banner = connection.recv(1024)
    text = clean(banner.decode("utf-8", errors="replace"), 250)
    if banner.startswith(b"SSH-"):
        return {"service": "ssh", "status": "identified", "banner": text}
    if port == 23 and (banner.startswith(b"\xff") or re.search(r"login:|telnet", text, re.I)):
        return {"service": "telnet", "status": "identified", "banner": text, "encrypted": False}
    return {"service": "unknown", "status": "banner_only" if banner else "unidentified", "banner": text}


def tls_check(host, port, timeout, legacy=None):
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    if legacy is not None:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            context.minimum_version = legacy
            context.maximum_version = legacy
        context.set_ciphers("DEFAULT:@SECLEVEL=0")
    with dial(host, port, timeout) as connection:
        with context.wrap_socket(connection) as secure:
            return {"service": "tls", "status": "identified", "version": secure.version(),
                    "cipher": secure.cipher()[0],
                    "certificate_sha256": hashlib.sha256(secure.getpeercert(binary_form=True) or b"").hexdigest(),
                    "certificate_trust_checked": False}


def finding(port, identifier, title, severity, status, evidence, recommendation):
    return {"port": port, "id": identifier, "title": title, "severity": severity,
            "status": status, "evidence": evidence, "recommendation": recommendation}


def inspect_service(host, port, timeout, adb_ports):
    result = {"port": port, "checks": [], "findings": [], "software": []}
    check = None
    try:
        if port in adb_ports:
            check = adb_check(host, port, timeout)
            if check["status"] == "accepted_without_auth":
                result["findings"].append(finding(port, "ADB-NO-AUTH", "ADB acepta conexión sin autenticar al cliente", "alta", "confirmed",
                    "Un cliente nuevo envió CNXN y recibió CNXN sin enviar claves ni firmas.",
                    "Desactivar ADB por red o exigir autenticación y limitar el acceso a equipos de administración, tanto en IPv4 como en IPv6."))
        elif port in HTTP_PORTS:
            check = http_check(host, port, timeout)
            headers = check["headers"]
            if re.search(r"\bBasic\b", headers.get("www-authenticate", ""), re.I):
                result["findings"].append(finding(port, "HTTP-BASIC-CLEARTEXT", "HTTP ofrece autenticación Basic sin TLS", "media", "confirmed",
                    "La respuesta HTTP sin cifrar anuncia WWW-Authenticate: Basic; no se enviaron credenciales.",
                    "Servir la autenticación mediante HTTPS y retirar el acceso de autenticación por HTTP."))
            elif not (300 <= check["status_code"] < 400 and headers.get("location", "").lower().startswith("https://")):
                result["findings"].append(finding(port, "HTTP-CLEARTEXT", "Servicio HTTP sin cifrado accesible", "informativa", "observation",
                    f"GET / devolvió HTTP {check['status_code']} sin TLS.",
                    "Comprobar si transmite información sensible y habilitar HTTPS cuando corresponda."))
        elif port in TLS_PORTS:
            check = tls_check(host, port, timeout)
        else:
            check = banner_check(host, port, timeout)
            if check["service"] == "ssh" and check["banner"].startswith("SSH-1.") and not check["banner"].startswith("SSH-1.99-"):
                result["findings"].append(finding(port, "SSH1-ADVERTISED", "El servidor anuncia SSH versión 1", "media", "observation",
                    check["banner"], "Confirmar la negociación y actualizar para admitir únicamente SSH versión 2."))
            elif check["service"] == "telnet":
                result["findings"].append(finding(port, "TELNET-EXPOSED", "Servicio Telnet accesible", "media", "observation",
                    "Se recibió negociación o identificación Telnet; no se intentó iniciar sesión.",
                    "Sustituir la administración Telnet por SSH o restringir el acceso de red."))
        result["checks"].append(check)
    except (OSError, ValueError) as error:
        result["checks"].append({"status": "inconclusive", "error": clean(error)})
    if port in TLS_PORTS:
        for version, label in ((ssl.TLSVersion.TLSv1, "TLSv1"), (ssl.TLSVersion.TLSv1_1, "TLSv1.1")):
            try:
                legacy = tls_check(host, port, timeout, version)
                result["checks"].append(legacy)
                if legacy["version"] == label:
                    result["findings"].append(finding(port, "LEGACY-" + label, f"El servicio acepta {label}", "media", "confirmed",
                        f"Se completó una negociación limitada exclusivamente a {label}.",
                        "Deshabilitar TLS 1.0/1.1 y utilizar TLS 1.2 o superior."))
            except (OSError, ValueError) as error:
                result["checks"].append({"test": label, "status": "not_negotiated", "detail": clean(error)})
    if check:
        text = " ".join([check.get("banner", ""), *check.get("headers", {}).values()])
        for product, pattern in (("OpenSSH", r"OpenSSH[_/]([0-9][0-9A-Za-z.p_-]*)"),
                                 ("nginx", r"\bnginx/([0-9][0-9.]+)"),
                                 ("Apache HTTP Server", r"\bApache/([0-9][0-9.]+)"),
                                 ("PHP", r"\bPHP/([0-9][0-9.]+)")):
            match = re.search(pattern, text, re.I)
            if match:
                result["software"].append({"product": product, "version": match[1], "evidence": "service_banner"})
    return result


def lookup_nvd(product, version):
    query = product + " " + version
    url = NVD_API + "?" + urllib.parse.urlencode({"keywordSearch": query, "resultsPerPage": 10})
    request = urllib.request.Request(url, headers={"User-Agent": f"{APP_NAME}/{VERSION}", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            raw = response.read(2_000_001)
        if len(raw) > 2_000_000:
            raise ValueError("Respuesta NVD excesiva")
        data = json.loads(raw)
        if not isinstance(data, dict) or not isinstance(data.get("vulnerabilities"), list):
            raise ValueError("La respuesta no tiene el formato de la API NVD")
        candidates = []
        for item in data["vulnerabilities"][:10]:
            cve = item.get("cve", {})
            identifier = cve.get("id", "")
            if not re.fullmatch(r"CVE-[0-9]{4}-[0-9]{4,}", identifier) or cve.get("vulnStatus") == "Rejected":
                continue
            description = next((entry.get("value", "") for entry in cve.get("descriptions", []) if entry.get("lang") == "en"), "")
            candidates.append({"id": identifier, "status": "unverified", "description": clean(description, 300),
                               "url": "https://nvd.nist.gov/vuln/detail/" + identifier})
        return {"query": query, "status": "completed", "matching": "keyword_only", "url": url,
                "total_results": data.get("totalResults"), "candidates": candidates,
                "limitation": "Coincidencias de texto: no confirman versión afectada, configuración, parches ni explotación. Máximo 10 registros por consulta."}
    except (OSError, ValueError) as error:
        return {"query": query, "status": "error", "error": clean(error), "candidates": []}


def write_report(directory, result):
    def markdown_text(value):
        return re.sub(r"([\\`*_{}\[\]()#+!|>])", r"\\\1", clean(value).replace("<", "&lt;"))
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    json_path = directory / "vulnerabilidades.json"
    json_path.write_text(payload, encoding="utf-8")
    lines = [f"# {APP_NAME} · Revisión de vulnerabilidades", "", SIGNATURE, "", f"IP: {clean(result['ip'])}",
             f"Fecha: {result['created_at']} · Estado: {result['status']}", "", "## Resultados", ""]
    for item in result["findings"]:
        title = markdown_text(item["title"])
        lines += [f"### {title}", "", f"Puerto: {item['port']}/TCP · Severidad: {item['severity']} · Estado: {item['status']}",
                  "", markdown_text(item["evidence"]), "", item["recommendation"], ""]
    if not result["findings"]:
        lines.append("No hubo acceso suficiente para revisar servicios; el resultado es inconcluso." if result["status"] == "inconclusive" else
                     "No se comprobaron problemas con las pruebas realizadas; esto no demuestra ausencia de vulnerabilidades.")
    lines += ["", "## Consultas CVE", ""]
    for lookup in result["cve_lookups"]:
        lines += [f"- {clean(lookup['query'])}: {lookup['status']}"]
        for candidate in lookup["candidates"]:
            lines += [f"  - [{candidate['id']}]({candidate['url']}): por validar; coincidencia de texto."]
        if lookup.get("error"):
            lines.append("  - Error: " + clean(lookup["error"]))
    lines += ["", "## Límites", ""] + ["- " + value for value in result["limitations"]]
    (directory / "reporte.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    for path in (json_path, directory / "reporte.md"):
        os.chmod(path, 0o600)
    (directory / "SHA256SUMS.txt").write_text("".join(
        hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.name + "\n"
        for path in (json_path, directory / "reporte.md")), encoding="ascii")
    os.chmod(directory / "SHA256SUMS.txt", 0o600)


def run_vulnerability_scan(app, host, ports, timeout=1.0, cves=False):
    scan = app.scan_ports(ports, timeout, save_report=False, host=host)
    host = scan["ip"]
    directory = app.output / ("vulnerabilidades-" + dt.datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8])
    directory.mkdir(mode=0o700)
    opened = [item["port"] for item in scan["ports"] if item["state"] == "open"]
    adb_ports = {3222, 5555}
    if app.device and ":" in app.device and app.device.rsplit(":", 1)[1].isdecimal():
        adb_ports.add(int(app.device.rsplit(":", 1)[1]))
    result = {"operation": "vulnerability-scan", "tool_name": APP_NAME, "author": AUTHOR,
              "created_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
              "tool_version": app.version, "ip": host, "family": scan["family"], "port_scan": scan,
              "services": [], "findings": [], "cve_lookups": [], "status": "running",
              "report_path": str(directory / "reporte.md"), "evidence_path": str(directory / "vulnerabilidades.json"),
              "limitations": ["Se revisan los puertos elegidos y hasta 64 servicios abiertos por ejecución; no todos los protocolos ni todas las vulnerabilidades.",
                              "Un puerto abierto no confirma una vulnerabilidad. Los resultados inconclusos no se interpretan como seguros.",
                              "Las CVE por texto requieren validar producto, versión afectada, configuración y parches del fabricante.",
                              "No se prueban contraseñas ni se ejecutan comandos remotos ni se modifican los equipos. El saludo ADB no utiliza claves guardadas.",
                              "Las pruebas TLS comprueban negociación; no evalúan la confianza ni identidad del certificado."]}
    write_report(directory, result)
    try:
        app.note(f"Revisando {min(len(opened), 64)} servicios accesibles de {host}…")
        result["services"] = app.map_tasks(opened[:64], lambda port: inspect_service(host, port, min(timeout, 5.0), adb_ports),
                                           workers=8, label="Servicios revisados")
        result["findings"] = [item for service in result["services"] for item in service["findings"]]
        write_report(directory, result)
        software = sorted({(item["product"], item["version"]) for service in result["services"] for item in service["software"]})
        if cves:
            if not software:
                result["limitations"].append("No se observó producto con versión suficiente para consultar CVE; no se deduce la versión por el puerto.")
            for index, (product, version) in enumerate(software[:3]):
                if index:
                    time.sleep(6.2)
                app.note(f"Consultando CVE para {product} {version}…")
                result["cve_lookups"].append(lookup_nvd(product, version))
                write_report(directory, result)
            if len(software) > 3:
                result["limitations"].append("La consulta NVD se limitó a tres combinaciones de producto y versión.")
        else:
            result["limitations"].append("No se solicitó consulta de CVE a NVD.")
        result["status"] = "partial" if any(entry["status"] == "error" for entry in result["cve_lookups"]) else "completed"
        if not opened and any(item["state"] in ("no_response", "unreachable", "error") for item in scan["ports"]):
            result["status"] = "inconclusive"
            result["limitations"].append("Ningún puerto seleccionado aceptó conexión y hubo destinos sin respuesta o errores: no se pudieron revisar servicios.")
    except KeyboardInterrupt:
        result["status"] = "cancelled"
    except Exception as error:
        result["status"] = "partial"
        result["error"] = clean(error)
    finally:
        write_report(directory, result)
    result["summary"] = {"confirmed": sum(item["status"] == "confirmed" for item in result["findings"]),
                         "observations": sum(item["status"] == "observation" for item in result["findings"]),
                         "cve_candidates": sum(len(item["candidates"]) for item in result["cve_lookups"])}
    write_report(directory, result)
    return result
