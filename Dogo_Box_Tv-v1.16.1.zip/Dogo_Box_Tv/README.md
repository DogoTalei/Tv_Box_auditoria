# Dogo_Box_Tv

**Firma: Dogo**

Para continuar después de apagar la PC, consulta [RETOMAR.md](RETOMAR.md). El historial de trabajo está en [AVANCE.md](AVANCE.md) y las verificaciones en [VALIDACION.md](VALIDACION.md).

Herramienta en Python para **auditoría por etapas, capturas PNG, grabación MP4 y transmisión local** de un dispositivo Android por ADB. Incluye menú interactivo, comandos, temas, perfiles de calidad, evidencias y registros. No requiere root.

## Corrección del instalador Termux (1.16.1)

Se retiró `iputils` del instalador porque no está disponible en el repositorio actual de Termux. Se utiliza el ping del sistema Android cuando existe, y el descubrimiento IPv4 puede utilizar TCP sin ese programa. [Reparación de una copia 1.16.0 ya extraída](TERMUX.md#corrección-del-paquete-iputils-1161).

## Termux y terminales Android (1.16.0)

El paquete incluye `instalar-termux.sh`, detección de Android/Termux, configuración privada y shell sin depender de `/bin/sh`. Después de extraerlo dentro del HOME privado de la terminal:

```bash
bash instalar-termux.sh
bash iniciar.sh
```

Consulta [TERMUX.md](TERMUX.md) para instalación, ADB por Wi-Fi, diferencias de rutas, permisos de Android, búsqueda TCP con subred manual y directo mediante entorno gráfico. El instalador automático requiere un derivado con `pkg`; los demás entornos necesitan las dependencias equivalentes. La ejecución real en un teléfono Android sigue pendiente: se detallan las pruebas y límites en esa guía.

## Inicio rápido en esta computadora

```bash
/home/dogo/Dogo_Box_Tv/iniciar.sh
```

El archivo `config.json` conserva el destino seleccionado. La **opción 17** conecta ADB por IPv4/IPv6 y permite guardar la conexión verificada para las próximas sesiones. La **opción 10** conserva la búsqueda IPv4 y selección por número. La opción 1 permite una conexión temporal o USB.

## Cuadros y shell delimitada (1.15.0)

Los resultados, avisos, errores, progresos y listas quedan dentro de paneles que se ajustan al ancho actual de la terminal, hasta 100 columnas. Las IPv6, rutas y líneas largas continúan dentro del borde; las listas de equipos utilizan un formato compacto cuando no cabe la tabla. Se cuentan columnas visibles, incluidos caracteres anchos y acentos combinados. Las secuencias de control externas no pueden borrar o desplazar los paneles de resultados.

Las preguntas también aparecen en un cuadro editable. Puedes pegar direcciones o rutas largas: el campo desplaza horizontalmente el texto para mantener los bordes. **Enter** acepta, **Ctrl+C** cancela y **Ctrl+D**, en un campo vacío, sale. Se respetan el tema elegido y `--color never`. La salida `--json` continúa siendo JSON sin cuadros.

La **opción 18** abre una terminal ADB dentro de un marco con **Dogo_Box_Tv · Shell ADB · Firma: Dogo**. Su propia pseudo-terminal limita la escritura, la salida y los movimientos de cursor al área interior. El marco se adapta al redimensionar la ventana. **exit/Ctrl+D** cierra la sesión y vuelve al menú; **Ctrl+C** se envía al comando remoto. El código de salida pertenece al cliente ADB.

Se necesitan **tmux con display-popup** y **prompt_toolkit** para la shell enmarcada y los campos editables, respectivamente. En esta PC ya están disponibles (tmux 3.7c y prompt_toolkit 3.0.53); la opción **6** los incluye en el diagnóstico. En una instalación Debian/Ubuntu nueva:

```bash
sudo apt install tmux python3-prompt-toolkit
```

La herramienta utiliza una sesión tmux privada y temporal y la cierra al terminar. No utiliza la configuración ni las sesiones tmux del usuario. El contenido de la shell no se guarda en el registro de la herramienta. La shell enmarcada requiere una terminal compatible; los comandos no interactivos y JSON funcionan sin estas dos dependencias.

## Identidad y apariencia Dogo (1.14.0)

El programa se presenta como **Dogo_Box_Tv**, con la firma **Dogo** en el encabezado y los reportes. El menú incorpora una pantalla de TV dibujada en texto, paneles por función y una paleta cian/verde. En terminales de 78 columnas o más, las opciones se organizan en dos columnas; en terminales angostas se utiliza una y se ajustan los textos al ancho. Los números de las opciones se mantienen.

El tema predeterminado es **dogo**. La opción **12** permite elegir otro tema y personalizar los colores. Las preferencias de apariencia guardadas siguen teniendo prioridad. Los modos JSON y `--color never` continúan disponibles.

```bash
python3 Dogo_Box_Tv.py
python3 Dogo_Box_Tv.py --version
python3 Dogo_Box_Tv.py --theme dogo --color always
```

`Dogo_Box_Tv.py` es el lanzador con el nombre del proyecto. `tvbox.py` conserva los comandos existentes. En esta computadora, `/home/dogo/Dogo_Box_Tv` da acceso al proyecto y su configuración en `/home/dogo/tvbox-tools`.

## Mostrar una imagen o logo en el TV-box (1.12.0)

1. Conecta ADB con **17** o utiliza el destino ya guardado.
2. Elige **19. Mostrar imagen o logo en el TV-box**.
3. Escribe o pega la ruta del archivo de tu PC. Se admiten PNG, JPEG, GIF y WebP de hasta 25 MiB. Puedes usar una ruta con espacios, con o sin comillas exteriores.
4. Si hay varios visores, elige uno; en este TV-box aparecen **Galería del TV-box** y **Chrome**.
5. La imagen se copia al dispositivo y se abre en el visor en primer plano. Usa **20. Quitar imagen de la pantalla** para retirarla desde la PC, o **Atrás/Inicio** en el mando.

```bash
# Mostrar un archivo elegido desde la computadora
/home/dogo/tvbox-tools/iniciar.sh show-image "/ruta/a/mi logo.png"

# Elegir explícitamente el visor instalado
python3 tvbox.py show-image "/ruta/a/imagen.jpg" --viewer com.hisilicon.higallery/.NetworkHiGallery
```

Las imágenes se guardan en `/sdcard/Pictures/TVBoxTools/` con nombres generados. La copia queda disponible en el dispositivo para volver a abrirla; puedes eliminarla desde su administrador de archivos. La selección ADB se conserva. El programa comprueba el formato y que Android confirme la apertura del visor; la representación final depende del visor y de que el archivo pueda decodificarse. Si falla la transferencia o la apertura, intenta retirar únicamente la copia generada por esa operación.

La función utiliza un visor compatible ya instalado. Si no encuentra uno, informa el problema antes de copiar el archivo. La imagen multicolor usada para validar esta función es un archivo de prueba; puedes sustituirla por el logo o imagen que elijas en 19.

### Quitar la imagen desde el script (1.13.0)

La **opción 20** cierra la imagen mostrada por la herramienta y comprueba que deje de estar en primer plano. Primero envía Atrás; si el visor mantiene una imagen de la herramienta activa, utiliza Inicio. También está disponible por terminal:

```bash
/home/dogo/tvbox-tools/iniciar.sh hide-image
```

Se conserva el archivo copiado al TV-box. La opción reconoce la imagen por la actividad e intención Android activas y la ruta generada en `Pictures/TVBoxTools`; puede identificar una imagen abierta antes de reiniciar el script. Si estás usando otra aplicación u otra imagen, no envía navegación. Si no puede identificar o verificar el estado del visor, lo informa. La compatibilidad de esa detección depende del formato de diagnóstico de actividades del firmware.

## Shell ADB interactiva (1.11.0)

Conecta el dispositivo con **17** y elige **18. Abrir shell ADB interactiva**. La herramienta verifica el destino y abre la shell en tu propia terminal, dentro del marco personalizado de la versión 1.15.0, con entrada, salida y pseudo-terminal remota. Funciona con la selección IPv4, IPv6 o USB.

```bash
# Abrir la shell del destino guardado
/home/dogo/tvbox-tools/iniciar.sh shell

# Usar temporalmente un dispositivo explícito
python3 tvbox.py --device '[fe80::2e73:60ff:fef1:78d0%wlan0]:3222' shell
```

- Escribe **`exit`** o pulsa **Ctrl+D** para cerrar la shell. Desde la opción 18 vuelves al menú.
- **Ctrl+C** normalmente interrumpe el comando remoto y mantiene la shell abierta. Si sales sin indicar un código, la shell puede conservar el estado del último comando; se muestra el código de salida al cerrar.
- Si ocurre una interrupción local o falla el cliente, la herramienta termina su cliente ADB y restaura el estado de la terminal.
- La sesión necesita entrada y salida de terminal; no admite `--json` ni redirección de sus flujos.

La selección ADB no cambia por abrir o cerrar la shell. El registro de la herramienta guarda apertura y cierre, sin capturar el contenido de la sesión. La opción `shell` de terminal devuelve el código de salida del cliente ADB; desde el menú puedes abrir otra sesión al terminar.

## Conectar ADB al equipo descubierto (1.10.0)

1. Usa **15** para descubrir equipos IPv6. Puedes revisar sus puertos o volver al menú con `0`.
2. Elige **17. Conectar ADB por IP o fila (IPv4/IPv6)**.
3. Escribe el número de fila o pega la IP. Se ofrece la última IP revisada cuando está disponible. Para una IPv6 link-local sin ámbito, se utiliza la interfaz del último reconocimiento o del descubrimiento si es inequívoca.
4. Indica el **puerto ADB**, por ejemplo `3222` en el TV-box de esta sesión. Los puertos abiertos observados se muestran como referencia, sin asumir que todos sean ADB.
5. Elige `1` para guardar el destino o `0` para una conexión temporal. La herramienta ejecuta `adb connect` y comprueba `get-state`: solo una respuesta `device` permite cambiar la selección. Si aparece `unauthorized`, acepta la clave de la computadora en la pantalla del dispositivo y vuelve a conectar.
6. Usa **18** para abrir una shell, **2** para consultar estado/modelo, **3** para capturar o **5** para iniciar el directo.

```bash
# Conectar y guardar la selección IPv6, después de verificar ADB
python3 tvbox.py select fe80::2e73:60ff:fef1:78d0 --interface wlan0 --port 3222

# Otra forma de indicar el ámbito
python3 tvbox.py select 'fe80::2e73:60ff:fef1:78d0%wlan0' --port 3222

# Conexión temporal: no cambia config.json
python3 tvbox.py connect '[fe80::2e73:60ff:fef1:78d0%wlan0]:3222'

# Verificar el destino guardado en una ejecución posterior
python3 tvbox.py status
```

En ADB, IPv6 y puerto se representan como **`[IPv6%interfaz]:PUERTO`**. La herramienta forma ese identificador al seleccionar una IP. La opción 1 también lo acepta. Los fallos de conexión o autorización conservan la selección anterior; si falla la escritura, se restaura la selección en memoria aunque la conexión pueda seguir registrada en el servidor ADB. La herramienta utiliza el flujo normal de autorización de ADB y no activa por su cuenta la depuración del dispositivo.

Las capturas, grabaciones y directos usan el destino ADB activo y siguen requiriendo que el dispositivo esté disponible. La conexión temporal solo se mantiene como selección dentro de esa ejecución; para usarla en las siguientes, guárdala con 17 o `select`.

## Buscar vulnerabilidades en la IP elegida (1.9.0)

La **opción 16. Buscar vulnerabilidades (IPv4/IPv6)** revisa los servicios accesibles de una IP y genera un reporte con evidencia. Después de usar las opciones 15 u 11 para comprobar puertos, la IP revisada queda como destino inicial de esta opción. Puedes pulsar Enter para usarla, pegar otra IP o elegir una fila del último descubrimiento. La selección ADB guardada se conserva.

1. Elige **16** y la IP que quieres revisar.
2. Indica los puertos o rangos TCP y el tiempo de espera. Si acabas de revisar esa IP, se ofrecen los mismos puertos.
3. Elige si quieres consultar posibles CVE en NVD; `0` ejecuta solo las comprobaciones locales.
4. Consulta los resultados en pantalla y en `salidas/vulnerabilidades-FECHA-ID/`.

```bash
# Comprobaciones locales por IPv6, sin Nmap ni root
python3 tvbox.py vuln-scan --host 'fe80::2e73:60ff:fef1:78d0%wlan0' --ports 22,80,443,3222,5555

# Otra IP y consulta opcional de posibles CVE
python3 tvbox.py vuln-scan --host 192.168.0.110 --ports 22,80,443,8080,8443 --cves

# Interfaz explícita y resultado JSON
python3 tvbox.py --json vuln-scan --host fe80::2e73:60ff:fef1:78d0 --interface wlan0 --ports 3222
```

Las comprobaciones distinguen estos resultados:

- **COMPROBADO:** saludo ADB aceptado por un cliente nuevo sin autenticación, autenticación HTTP Basic ofrecida sin TLS o negociación efectiva de TLS 1.0/1.1. La prueba ADB no utiliza las claves del ordenador, no manda una clave pública ni abre una consola. Aceptar el saludo no demuestra privilegios root ni verifica qué operaciones posteriores permite el dispositivo.
- **REVISAR:** identificación de HTTP sin cifrado, Telnet o anuncio de SSH versión 1. Estas observaciones requieren contexto; no se presentan automáticamente como explotación ni CVE confirmada.
- **CVE por validar:** coincidencias de texto en NVD para producto y versión observados en banners de OpenSSH, nginx, Apache HTTP Server o PHP. Debes contrastar versiones afectadas, configuración y parches del fabricante. Cero coincidencias no demuestra que el software esté actualizado ni que no existan CVE.
- **Inconcluso:** respuesta inválida, protocolo no identificado, fallo o tiempo de espera. Los detalles quedan en el JSON; no se interpreta como servicio seguro.

Se vuelven a comprobar los puertos elegidos y se revisan hasta 64 servicios abiertos con ocho tareas simultáneas. El saludo ADB se prueba en 3222, 5555 y el puerto ADB configurado; HTTP y TLS se comprueban en sus puertos habituales definidos por la herramienta. Otros puertos se consultan mediante banners. No cubre todos los protocolos, vulnerabilidades web, UDP ni todos los puertos del equipo. No prueba contraseñas ni ejecuta comandos remotos ni cambia la configuración. Las pruebas TLS registran protocolo, cifrado y huella del certificado; no verifican confianza, caducidad o identidad del certificado.

La consulta NVD es opcional y envía **solo producto y versión**, nunca la IP/MAC de la LAN. Se limita a tres combinaciones de producto/versión y diez registros por consulta, con separación entre peticiones. Los fallos de Internet o de la API se registran como errores parciales y no eliminan las comprobaciones locales.

Cada revisión guarda `reporte.md`, `vulnerabilidades.json` y `SHA256SUMS.txt`; la carpeta y los archivos son privados en Linux. Si se cancela durante las sondas, se conserva el reconocimiento de puertos y las etapas ya guardadas. Si ningún puerto acepta conexión y hay tiempos de espera o errores, la revisión queda **inconclusa**. Los códigos de salida son 0 al terminar, 1 si hay errores parciales o falta acceso suficiente y 130 si se cancela; 0 no significa ausencia de problemas.

Referencias de las comprobaciones: [protocolo oficial ADB](https://android.googlesource.com/platform/packages/modules/adb/+/refs/heads/android14-release/protocol.txt), [API de vulnerabilidades NVD](https://nvd.nist.gov/developers/vulnerabilities) y [deprecación de TLS 1.0/1.1, RFC 8996](https://www.rfc-editor.org/rfc/rfc8996).

## Descubrir IPv6 y elegir una IP para revisar puertos (1.8.1)

1. Abre el menú y elige **15. Buscar equipos IPv6 y mostrar filas**.
2. Elige la interfaz, por ejemplo `wlan0`. Se muestran filas numeradas con IPv6, MAC, fabricante disponible y evidencia de respuesta o caché.
3. Al terminar aparece **IPv6 destino: pega la dirección o elige una fila**. Pega la IPv6 que quieras comprobar o escribe su número de fila. Si omites `%interfaz` en una IPv6 link-local, se utiliza la interfaz que acabas de elegir. `0` o Enter vuelve al menú sin comprobar puertos.
4. Indica los puertos o rangos que quieras revisar, por ejemplo `22,80,443,3222,5555` o `8000-8010`. La tabla muestra cada resultado, destaca los puertos abiertos y guarda un reporte JSON.

Las filas del último descubrimiento se conservan mientras ese menú esté abierto. La **opción 11** permite repetir el reconocimiento eligiendo otra fila o escribiendo cualquier IPv4/IPv6, incluso sin descubrimiento previo; Enter utiliza la IP del destino activo si es válida. Elegir una IP para revisar sus puertos no cambia el destino ADB guardado ni requiere que el equipo tenga ADB.

```bash
# Ver interfaces IPv6 y descubrir los vecinos de una interfaz
python3 tvbox.py networks --ipv6
python3 tvbox.py discover --ipv6 --interface wlan0

# Consultar únicamente la caché IPv6
python3 tvbox.py --json discover --ipv6 --interface wlan0 --passive

# Revisar puertos de una dirección IPv6 elegida
python3 tvbox.py scan-ports --host 'fe80::2e73:60ff:fef1:78d0%wlan0' --ports 22,80,443,3222,5555

# También puedes indicar el ámbito con --interface
python3 tvbox.py scan-ports --host fe80::2e73:60ff:fef1:78d0 --interface wlan0 --ports 3222,8000-8010

# Elegir libremente otra IPv4 sin cambiar config.json
python3 tvbox.py scan-ports --host 192.168.0.113 --ports 80,443
```

Las direcciones IPv6 que empiezan por `fe80::` necesitan el ámbito `%interfaz`; las filas ya lo incluyen. El descubrimiento usa dos consultas ICMPv6 multicast a los vecinos de la interfaz y comprueba por unicast hasta 256 vecinos adicionales de la caché. No recorre un `/64` completo ni traduce una IPv6 a IPv4. Puede funcionar cuando falla ARP/IPv4, siempre que los otros equipos tengan IPv6 y respondan. Una entrada marcada **en caché** no se presenta como una respuesta actual. No requiere root ni Nmap.

## Auditoría automatizada por etapas (1.6.0)

La **opción 13** ejecuta una auditoría del destino seleccionado y genera una carpeta independiente con reporte Markdown, evidencias JSON y hashes SHA-256. Antes de empezar, selecciona el equipo con la opción 10. No es necesario que tenga ADB abierto para auditar sus puertos.

```bash
# Seleccionar otro equipo sin conectar ADB
python3 tvbox.py select 192.168.0.110 --port 5555 --no-connect

# Auditoría de red con puertos predeterminados y dos rondas TCP
python3 tvbox.py audit

# Elegir puertos y hacer tres rondas de confirmación
python3 tvbox.py audit --ports 22,80,443,3222,5555,8000-8010 --rounds 3 --timeout 1

# Añadir sondas activas para identificar servicios y versiones (requiere Nmap)
python3 tvbox.py audit --services

# Añadir el inventario Android por la conexión ADB seleccionada
python3 tvbox.py audit --services --adb-inventory

# Datos sin colores para integraciones
python3 tvbox.py --json audit --ports 3222,5555
```

Las etapas son:

1. **Reconocimiento del destino:** IP, ruta, interfaz y MAC en la tabla de vecinos, cuando iproute2 está disponible. No recorre toda la red ni atribuye al destino la MAC de una pasarela.
2. **Comprobación TCP:** dos o tres rondas sobre todos los puertos indicados. Se conservan tiempos y estados de cada observación. Las rondas se separan al menos 0.25 segundos.
3. **Clasificación:** `confirmed_open` o `confirmed_closed` solo si todas las rondas requeridas coinciden; `inconsistent` si cambian los resultados o faltan muestras. Se mantienen `no_response`, `unreachable` y `error` cuando coinciden las observaciones. Abierto confirma una conexión TCP aceptada, no la identidad del servicio. Rechazado puede deberse al destino o a un filtro. Sin respuesta no demuestra filtrado.
4. **Servicios opcionales:** Nmap `-sT -sV --version-light`, sin scripts NSE de vulnerabilidades ni explotación, únicamente en puertos confirmados abiertos. Se guarda `nmap.xml`. Las etiquetas de una tabla de puertos se distinguen de las coincidencias de sondas: por ejemplo, que 3222 aparezca como `glbp` por tabla no demuestra que ese sea el servicio. El plazo es 60 segundos por destino, con un límite del proceso de 75 segundos.
5. **Android opcional:** verifica la conexión ADB seleccionada y consulta propiedades acotadas, identidad de la sesión, SELinux, paquetes del sistema, procesos, puertos en escucha y conexiones. Usa `ss`, con alternativa `netstat` cuando sea necesario. Las consultas tienen plazos de 15 segundos y sus errores se conservan. Una conexión ADB válida no demuestra que otros clientes sin clave puedan acceder.
6. **Evaluación y reporte:** observaciones sobre depuración, SELinux permisivo, propiedades de seguridad, identidad root ya existente y parche declarado de más de un año. Se aportan evidencias y medidas; las propiedades pueden estar manipuladas y no certifican el firmware.

Sin `--ports` se revisan `22,23,53,80,139,443,445,554,1900,3222,5000,5555,8000,8080,8443,9000,40000`, añadiendo el puerto ADB seleccionado si es diferente. Es una selección de puertos, **no un análisis de los 65535 puertos**, ni de UDP. Una lista explícita sustituye esta selección. No se intenta usar los servicios 5000/40000 para ejecutar comandos.

Los resultados se guardan en `salidas/auditoria-FECHA-ID/`: `reporte.md`, `auditoria.json`, `SHA256SUMS.txt` y `nmap.xml` cuando se solicitan servicios. La carpeta y los archivos tienen permisos privados en Linux. Cada etapa guarda un punto de control. Los fallos no eliminan las evidencias ya obtenidas; las consultas Android conservan sus errores y los inventarios parcialmente completados. Ctrl+C genera un reporte cancelado con las rondas disponibles, sin reanudar automáticamente. No interrumpas la escritura de un archivo ni borres la carpeta mientras se ejecuta.

En terminal, el código de salida es 0 si las etapas solicitadas terminaron, 1 si hay errores parciales y 130 si se cancela. Un 0 **no significa que el equipo sea seguro**. Una etapa opcional no solicitada se registra como omitida.

### Alcance e interpretación

- Las versiones/CPE y enlaces de búsqueda NVD sirven para investigación manual; **no se consultó NVD ni se confirmaron CVE**. No se concluye vulnerabilidad solo por un banner o por una fecha de parche. Verifica el producto, la versión real, los parches del fabricante y las precondiciones.
- Procesos, paquetes y conexiones son una observación puntual. No bastan para demostrar publicidad en segundo plano, persistencia, malware, puertas traseras ni que una aplicación viniera de fábrica. Eso requiere investigación y observación adicional.
- La auditoría no explota servicios, escala privilegios, cambia ajustes, instala apps ni captura o transmite pantallas automáticamente. Capturas, grabación y directo siguen siendo operaciones independientes del usuario.
- Los reportes pueden incluir paquetes, procesos y direcciones privadas. Conserva los originales para análisis y redacta una copia antes de compartir.

Para repetir auditorías de forma útil, registra modelo y firmware, conserva los originales y usa el mismo alcance y parámetros. Compara resultados antes y después de actualizar el firmware o cambiar la segmentación de red. Evita convertir una ausencia de respuesta en una conclusión de seguridad.

## Descubrir y seleccionar otros TV-box

### Localizar por MAC cuando cambia la IP (1.7.0)

La **opción 14** busca una MAC exacta en la red local y muestra su IP. Usa por defecto la MAC guardada al seleccionar el dispositivo. Si hay una coincidencia única con respuesta actual, permite actualizar la selección y opcionalmente conectar ADB.

```bash
# Buscar la MAC guardada, sin cambiar la configuración
python3 tvbox.py find-mac

# Buscar una MAC específica (también admite guiones y minúsculas)
python3 tvbox.py find-mac 2C:73:60:F1:78:D0

# Guardar la nueva IP manteniendo el puerto de la misma MAC
python3 tvbox.py find-mac --select

# Conectar ADB y guardar solo tras verificar la conexión
python3 tvbox.py find-mac --select --connect

# Elegir otra interfaz, subred o puerto ADB
python3 tvbox.py find-mac 2C:73:60:F1:78:D0 --interface eth0 --network 192.168.0.0/24 --select --port 3222

# Consultar únicamente datos en caché; salida estructurada
python3 tvbox.py --json find-mac --passive
```

La búsqueda utiliza el descubrimiento ICMP y la tabla de vecinos. Solo una respuesta ICMP actual con una asociación MAC coincidente se ofrece para guardar automáticamente. `cached` indica información sin respuesta actual o la interfaz local; `ambiguous` indica varias IP para la MAC; `not_found` significa que no se observó en el alcance consultado. Estos resultados no modifican la selección con `--select`; se devuelve un error explicativo. Una búsqueda sin `--select` nunca cambia el destino. Si la MAC coincide con la guardada, conserva su puerto ADB; para otra MAC utiliza 5555 salvo `--port` explícito.

Una MAC no permite calcular la IP ni localizar un dispositivo a través de Internet o de otra subred. El aislamiento Wi-Fi, equipos sin respuesta, interfaces diferentes o MAC aleatorias pueden impedir encontrarlo. Si ocurre, consulta las concesiones DHCP del router o la IP que aparece en el TV-box. La MAC identifica una interfaz y puede suplantarse: esta función facilita la selección, no autentica el dispositivo. No se solicitan automáticamente privilegios de administrador ni se fuerza una conexión a otro equipo.

```bash
# Interfaces, direcciones y subredes conectadas
python3 tvbox.py networks

# Descubrir equipos en la interfaz de la ruta predeterminada
python3 tvbox.py discover

# Elegir explícitamente una interfaz y subred conectada
python3 tvbox.py discover --interface eth0 --network 192.168.0.0/24

# Consultar la tabla de vecinos sin enviar sondas
python3 tvbox.py --json discover --passive

# Conectar y guardar la IP y el puerto ADB para futuras operaciones
python3 tvbox.py select 192.168.0.101 --port 3222

# Guardar un equipo que todavía no está disponible
python3 tvbox.py select 192.168.0.110 --port 5555 --no-connect
```

El descubrimiento requiere **Linux, iproute2 e iputils-ping**, sin privilegios root. En Debian/Ubuntu se instalan con `sudo apt install iproute2 iputils-ping`. Consulta las IP mediante ICMP y la tabla de vecinos de la interfaz; no busca puertos ADB ni intenta conectar a todos los equipos. La selección conecta únicamente al equipo y puerto elegidos. El puerto inicial para equipos nuevos es 5555 y se puede cambiar: el TV-box de esta sesión utiliza 3222. ADB debe estar habilitado y autorizado en el equipo.

La tabla muestra IP, MAC, fabricante cuando se dispone de una base local, evidencia de respuesta o caché y cuál es este ordenador. El fabricante se consulta sin Internet en `nmap-mac-prefixes`, si está instalado con Nmap; no se necesita Nmap para descubrir equipos. Una MAC administrada localmente puede ser aleatoria y se muestra sin atribuir fabricante. El fabricante corresponde al prefijo MAC y no identifica necesariamente la marca comercial ni el tipo de dispositivo.

Las MAC se observan solo en el mismo segmento local y algunas IP pueden no responder. Las entradas de caché pueden estar desactualizadas; no se presentan como respuestas actuales. Se admiten subredes IPv4 directamente conectadas de hasta 1024 direcciones. Si hay varias redes posibles, elige una interfaz; en redes mayores indica una subred menor. Si DHCP cambia la IP del TV-box, utiliza la opción 14 o find-mac para localizarla y actualizar la selección explícitamente.

La selección persistente actualiza solo el archivo indicado por `--config`, conservando sus otras opciones. `--device` y `TVBOX_DEVICE` siguen teniendo prioridad en la siguiente ejecución. Los directos que ya estén abiertos conservan su dispositivo; puedes consultarlos con `streams` y detenerlos por sesión.

## Menú, color y control

### Personalización de apariencia (1.5.0)

La **opción 12: Temas y colores personalizados** permite elegir un tema, previsualizar cambios, personalizar cada elemento y guardar o cancelar. Los cambios solo se guardan al elegir **5. Guardar y volver**. Cancelar o pulsar Ctrl+C restaura la apariencia anterior. La opción de restaurar prepara los valores predeterminados en la vista previa; también requiere guardar.

Temas disponibles: **dogo** (predeterminado, cian/verde), **neon** (rosa/turquesa/lavanda), **oceano**, **fuego**, **bosque**, **clasico** y **claro** (para fondos claros). Cada sección del menú tiene un color propio. Puedes cambiar doce elementos por separado: títulos, acciones, éxitos, avisos, errores, texto secundario, destino, red, capturas/directo, auditoría, separadores y progreso.

```bash
# Probar otro tema durante esta ejecución sin guardar
python3 tvbox.py --theme fuego

# Ver los temas, colores y elementos configurables
python3 tvbox.py appearance

# Guardar un tema para futuras sesiones
python3 tvbox.py appearance --theme oceano

# Personalizar colores concretos del tema guardado
python3 tvbox.py appearance --set title=rosa --set device='#FF8800' --set progress=lima

# Guardar el modo de color o restaurar todos los valores de apariencia
python3 tvbox.py appearance --mode auto
python3 tvbox.py appearance --reset
```

Los nombres de color son: `negro`, `rojo`, `verde`, `amarillo`, `azul`, `magenta`, `cian`, `blanco`, `gris`, `coral`, `lima`, `oro`, `lavanda`, `rosa`, `turquesa` y `nieve`. También se admiten colores hexadecimales `#RRGGBB`, que requieren una terminal con soporte RGB; los colores con nombre utilizan la paleta ANSI de la terminal y su aspecto puede variar. No se modifica el fondo de la terminal.

Los roles para `--set` son `title`, `accent`, `ok`, `warning`, `error`, `muted`, `device`, `network`, `media`, `audit`, `border` y `progress`. Elegir otro tema elimina las personalizaciones anteriores; puedes añadir nuevos `--set` en la misma orden. La configuración se guarda en `appearance` dentro del archivo seleccionado por `--config` y conserva el destino y las otras opciones. `--theme` y `--color` globales son ajustes temporales; `appearance --theme` y `appearance --mode` son persistentes. El modo JSON sigue sin códigos de color ni progreso.

Desde la versión 1.4.0, el menú agrupa las opciones en dispositivo/red, capturas/directo y auditoría/soporte. Conserva los números anteriores. El encabezado indica el destino activo y la carpeta de salida. La conexión ADB se verifica con la opción 2: el encabezado no afirma que un dispositivo esté conectado sin comprobarlo.

- Cian: títulos y acciones. Verde: operación correcta, respuesta recibida o puerto abierto. Amarillo: advertencias o información pendiente. Rojo: errores. Gris: información secundaria y puertos cerrados. El texto siempre identifica el estado, incluso sin colores.
- Los escaneos muestran cuántos elementos se han comprobado. Se mantienen hasta 32 tareas simultáneas y resultados en orden, sin instalar bibliotecas adicionales.
- Ctrl+C cancela la operación y vuelve al menú; las tareas pendientes se cancelan y las conexiones ya iniciadas terminan dentro de su tiempo de espera. No es una cancelación instantánea: el máximo configurado por puerto es 10 segundos. La limpieza de grabaciones/directos también puede necesitar tiempo.
- Ctrl+D u opción 0 salen y cierran los directos creados por esa instancia del menú. Los directos de otras ejecuciones se conservan.
- La opción 5 del menú avisa si ya existe un directo registrado del mismo destino. Usa 8 para detener los del destino o 9 para consultar sesiones. La terminal sigue permitiendo abrir varias sesiones explícitamente.
- Los errores de red, archivos y procesos se muestran y registran; el menú permite seguir trabajando. Consulta la opción 6 para diagnóstico.

```bash
python3 tvbox.py                     # Color automático en terminal compatible
python3 tvbox.py --color always      # Forzar color
python3 tvbox.py --color never       # Desactivar color
NO_COLOR=1 python3 tvbox.py          # Desactivar color automático
```

`--json` siempre devuelve datos sin colores ni progreso, incluso si se indica `--color always`. Las redirecciones tampoco usan colores en modo automático. No se limpian la pantalla ni el historial de resultados.

## Comprobar puertos específicos

La **opción 11 del menú** comprueba los puertos TCP que indiques en la IP seleccionada. También está disponible por terminal:

```bash
python3 tvbox.py scan-ports --ports 22,80,443,3222,5555
python3 tvbox.py scan-ports --ports 8000-8010,8080 --timeout 0.5
python3 tvbox.py --json scan-ports --ports 3222,5555
python3 tvbox.py scan-ports --host 'fe80::2e73:60ff:fef1:78d0%wlan0' --ports 3222,5555
```

Utiliza conexiones TCP normales y cierra cada conexión sin enviar datos de aplicación. No requiere ADB, Nmap ni root. Admite hasta 4096 puertos por ejecución, con un máximo de 32 conexiones simultáneas y un tiempo de espera por puerto de 0.1 a 10 segundos. Con `--host` eliges una IPv4 o IPv6; sin él se utiliza la IP del dispositivo seleccionado. Si solo hay un identificador USB, indica una IP con `--host`. No cambia el puerto ADB configurado.

Muestra puerto, estado y tiempo transcurrido, y guarda automáticamente un reporte JSON con fecha, destino, familia IP, parámetros, resultados y resumen en la carpeta de salida. Los estados son `open` (conexión aceptada), `closed` (conexión rechazada), `no_response` (sin respuesta a tiempo), `unreachable` (red o equipo inalcanzable) y `error` (otro error de conexión o del sistema local). Un tiempo de espera no demuestra que haya un cortafuegos; un puerto abierto tampoco identifica el servicio ni confirma una vulnerabilidad. Esta opción comprueba TCP sobre IPv4 o IPv6; no comprueba UDP. La auditoría avanzada de la opción 13 conserva su alcance IPv4; para revisar servicios IPv6 utiliza la opción 16. La conexión y selección ADB de la opción 17 y `select` admiten ambas familias.

## Comandos

```bash
# Conectar y consultar el equipo
python3 tvbox.py connect 192.168.0.101:3222
python3 tvbox.py status
python3 tvbox.py devices
python3 tvbox.py doctor

# Captura con nombre único y metadatos
python3 tvbox.py capture
python3 tvbox.py capture -o ./mi-captura.png

# Grabación: 10 segundos, 720p, 4 Mbps, sin audio
python3 tvbox.py record --duration 10
python3 tvbox.py record --duration 30 --size 1280x720 --bitrate 6M -o ./mi-video.mp4

# Directo: perfil que funcionó en este TV-box
python3 tvbox.py stream --profile equilibrado
python3 tvbox.py stream --profile fluido
python3 tvbox.py stream --profile nitido

# Abrir el directo y conservar disponible la terminal (Linux)
python3 tvbox.py stream --profile equilibrado --background

# Consultar y cortar directos creados por esta herramienta
python3 tvbox.py streams
python3 tvbox.py stream-stop
python3 tvbox.py stream-stop --session IDENTIFICADOR
python3 tvbox.py stream-stop --all

# Ajustes específicos
python3 tvbox.py stream --max-size 1920 --fps 30 --bitrate 6M

# Otro dispositivo o carpeta de salida: opciones globales antes del comando
python3 tvbox.py --device 192.168.0.101:3222 --output-dir ./evidencias capture

# Resultado estructurado, útil para automatización
python3 tvbox.py --json status
python3 tvbox.py --json capture
```

También puedes iniciar el menú con `bash iniciar.sh`. Para consultar todos los argumentos:

```bash
python3 tvbox.py --help
python3 tvbox.py record --help
python3 tvbox.py stream --help
```

## Perfiles del directo

| Perfil | Lado mayor máximo | Límite FPS | Bitrate |
|---|---:|---:|---:|
| fluido | 1280 px | 30 | 4 Mbps |
| equilibrado | 1920 px | 30 | 6 Mbps |
| nitido | 1920 px | 30 | 10 Mbps |

El tamaño y los FPS efectivos dependen del dispositivo, del contenido y de la red. En este TV-box el perfil equilibrado se vio bien y registró aproximadamente 20–24 FPS durante reproducción. Una pantalla estática puede generar pocos cuadros; eso no implica por sí mismo una conexión fallida.

La transmisión utiliza `scrcpy`, sin audio ni control remoto por teclado/ratón. No graba un archivo ni publica un servicio en Internet. Se detiene cerrando la ventana o pulsando Ctrl+C en la terminal. `scrcpy` puede copiar y ejecutar temporalmente su servidor en el dispositivo; no instala una app de usuario permanente.

### Cortar el directo desde el script

En Linux, la **opción 5 del menú inicia el directo sin bloquear el menú**. La **opción 8 lo corta**, y la **opción 9 muestra los directos activos**. Al salir del menú se cierran los directos que ese menú inició.

Desde una segunda terminal, `stream-stop` detiene los directos registrados del dispositivo seleccionado. `--session IDENTIFICADOR` permite elegir uno y `--all` incluye los de otros dispositivos registrados por la herramienta. No requiere reconectar ADB: cierra el cliente local de transmisión, que normalmente termina su servidor temporal al desconectarse.

El cierre automático comprueba usuario, instante de inicio del proceso, huella de sus argumentos y un marcador único de sesión antes de enviar una señal. Así evita actuar sobre un PID reutilizado o una ventana que no creó esta versión de la herramienta. Intenta primero un cierre suave y solo escala las señales para esa misma identidad verificada si no responde. No utiliza `killall` ni desconecta los demás dispositivos ADB.

Los registros privados de sesión están en `.tvbox-streams/`, junto al archivo de configuración; utiliza el mismo `--config` al iniciar y detener desde terminales diferentes. Los registros de procesos ya terminados se depuran sin enviar señales. Los directos iniciados con scripts anteriores, VLC u otros programas se cierran desde su propia ventana.

El registro de sesiones y el comando de cierre entre terminales están implementados para Linux. En Windows/macOS siguen disponibles el directo en primer plano, cerrar su ventana y Ctrl+C; no se ofrece cierre automático por PID sin una comprobación de identidad equivalente.

## Grabaciones y cancelación

- `screenrecord` admite de **1 a 180 segundos** por grabación en esta herramienta. Para una duración mayor, realiza varias grabaciones.
- El MP4 se genera temporalmente en `/data/local/tmp/` con un nombre aleatorio, se transfiere, se valida y se elimina del dispositivo después de confirmar la copia local.
- Ctrl+C cancela la grabación. Antes de enviar una señal, la herramienta verifica el PID y que su comando incluya la ruta única de esa grabación. No utiliza `killall` ni detiene procesos ajenos.
- Si falla la transferencia o validación, se informa la ruta remota para recuperación en vez de borrar la única copia disponible.
- Si la limpieza de un temporal falla, el resultado lo indica. No se afirma que el archivo haya sido eliminado.
- Estas grabaciones no incluyen audio. La duración real se informa desde el contenedor MP4 y puede diferir ligeramente de la solicitada.
- Algunos equipos no pueden codificar una grabación y un directo a la vez. Si el codificador falla, cierra la transmisión y vuelve a intentar; la herramienta no cierra otras sesiones automáticamente.

## Archivos y metadatos

La carpeta predeterminada es `salidas/`, junto al archivo de configuración. `--output-dir` permite elegir otra ubicación. Los nombres automáticos incluyen fecha, hora y un identificador para evitar colisiones.

Cada captura o grabación incluye un archivo adicional, por ejemplo `imagen.png.json`, con fecha, dispositivo, tamaño, resolución/duración, hash SHA-256 y versión de la herramienta. Usa `--no-metadata` para omitirlo.

Las capturas se verifican como PNG completo con CRC. Los MP4 se inspeccionan buscando su estructura, pista de vídeo y duración; esto no sustituye una comprobación visual de cada cuadro. La publicación local se realiza después de validar el archivo, sin sustituir salidas existentes salvo que se indique `--overwrite`.

Los registros se guardan en `salidas/tvbox-tools.log`, con rotación. Cada directo conserva su registro de diagnóstico. No se guardan píxeles del directo en esos registros. Las capturas, vídeos, registros y metadatos pueden contener información del dispositivo; no se suben automáticamente a ningún servicio.

## Requisitos y portabilidad

- Python **3.10 o posterior**; el script usa únicamente la biblioteca estándar.
- [Android Platform Tools / ADB](https://developer.android.com/tools/releases/platform-tools).
- [scrcpy 2.0 o posterior](https://github.com/Genymobile/scrcpy) para transmitir, con su servidor correspondiente.
- Sesión gráfica disponible para abrir la ventana del directo.

En esta computadora se detecta automáticamente la copia local de scrcpy ya verificada durante la sesión. No se instala ni descarga software al ejecutar la herramienta. En otra computadora, instala ADB y scrcpy según su documentación oficial y añádelos a PATH, o configura sus rutas.

`config.example.json` es una plantilla sin dispositivo preseleccionado. Las claves admitidas son:

```json
{
  "device": null,
  "output_dir": "salidas",
  "stream_profile": "equilibrado",
  "adb": null,
  "scrcpy": null,
  "scrcpy_server": null
}
```

Las opciones de línea de comandos tienen prioridad sobre la configuración. `TVBOX_DEVICE` permite seleccionar un dispositivo mediante el entorno. Si no se indica ninguno y solo hay uno conectado, se selecciona ese; si hay varios, se exige elegir.

El código admite rutas habituales de Windows/macOS, pero las pruebas con hardware se realizaron en Linux. El servidor de scrcpy y el cliente deben tener versiones compatibles. El comportamiento de contenido DRM o ventanas seguras depende de cada app y dispositivo.

## Diagnóstico y códigos de salida

`doctor` muestra rutas de herramientas, dispositivos y dependencias disponibles. `status` consulta modelo, versión declarada, API y parche; no certifica que las propiedades del firmware sean auténticas.

| Código | Significado |
|---:|---|
| 0 | Operación completada o directo detenido, cerrando su ventana o con Ctrl+C |
| 1 | Error de dispositivo, archivo, herramienta o ejecución |
| 2 | Argumentos de línea de comandos inválidos |
| 130 | Captura/grabación u otra operación cancelada por el usuario |

Con `--json`, una operación completada escribe su resultado en stdout y los errores se escriben como JSON en stderr. En un directo, el resultado final se emite después de cerrar la ventana; los detalles de scrcpy están en su registro.

Con `stream --background`, el resultado se emite al iniciar e incluye el identificador de sesión. `stream-stop` es idempotente: si no hay directos registrados, lo informa sin error. Si alguna sesión no se puede detener, devuelve sus errores y un código de salida 1.

## Pruebas sin dispositivo

```bash
python3 -m unittest discover -s tests -v
```

Las pruebas cubren validación de formatos, prevención de sobrescrituras, errores de ADB, selección de dispositivo, transferencia y limpieza simuladas, y comprobación de identidad del proceso antes de cancelar una grabación.
