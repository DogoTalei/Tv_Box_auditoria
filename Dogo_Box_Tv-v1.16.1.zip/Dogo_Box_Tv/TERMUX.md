# Dogo_Box_Tv en Termux y terminales Android

Firma: Dogo. Versión: **1.16.1**.

El programa puede ejecutarse como cliente de control desde una terminal Android con **Python 3.10 o posterior, ADB nativo y las dependencias de interfaz**. La instalación automática está preparada para Termux y derivados que proporcionen `PREFIX` y `pkg`. Otros entornos necesitan instalar las herramientas equivalentes con su propio gestor. No basta cualquier aplicación que muestre una consola: las restricciones y los paquetes disponibles dependen de cada aplicación y firmware.

La base de Termux con soporte completo requiere Android 7 o posterior; consulta sus [fuentes oficiales de instalación](https://github.com/termux/termux-app#installation). Debe utilizarse una distribución mantenida y paquetes compilados para la arquitectura de ese entorno. El programa no necesita root en el teléfono que actúa como cliente.

## Instalar desde el ZIP

Descarga `Dogo_Box_Tv-v1.16.1.zip`. Si está en Descargas, concede a Termux acceso al almacenamiento cuando Android lo solicite:

```bash
termux-setup-storage
pkg install unzip
cd "$HOME"
unzip /sdcard/Download/Dogo_Box_Tv-v1.16.1.zip
cd Dogo_Box_Tv
bash instalar-termux.sh
bash iniciar.sh
```

Ejecuta el instalador como usuario normal de Termux, **sin `su` ni `sudo`**. Si ya tienes otra versión, extrae el ZIP en otra carpeta para no mezclar código viejo con código nuevo. La configuración privada de Android sigue disponible para ambas instalaciones mientras utilicen la misma ruta predeterminada.

El código debe estar dentro del almacenamiento privado de la terminal, por ejemplo `$HOME/Dogo_Box_Tv`. No ejecutes la instalación dentro de `/sdcard` o `/storage`: Android limita la ejecución, los enlaces y los permisos en el almacenamiento compartido. El instalador lo detecta y se detiene; no mueve ni elimina tus archivos.

`instalar-termux.sh` actualiza los índices del gestor y solicita estos paquetes:

```text
python python-pip python-ensurepip-wheels android-tools tmux iproute2
```

`python-ensurepip-wheels` proporciona las ruedas necesarias para crear el entorno aunque estén desactivados los paquetes recomendados del gestor. Después crea `.venv` dentro del proyecto e instala `requirements.txt` allí. No intenta actualizar el pip administrado por Termux, no instala Nmap y no reemplaza la configuración guardada. Si el gestor o la conexión fallan, el instalador termina con error en vez de anunciar una instalación completa.

Puedes revisar sus requisitos sin instalar nada:

```bash
bash instalar-termux.sh --comprobar
```

Comandos de inicio y diagnóstico:

```bash
bash iniciar.sh --version
bash iniciar.sh doctor
bash iniciar.sh --json doctor
bash iniciar.sh
```

El lanzador prefiere `.venv/bin/python`, después `python3` y después `python`. Puedes fijar otro intérprete mediante `TVBOX_PYTHON=/ruta/a/python`. Usa `bash iniciar.sh` en Android para evitar depender de que exista `/bin/sh` en ese sistema.

## Corrección del paquete iputils (1.16.1)

La versión 1.16.0 incluía `iputils` por error en el instalador. El paquete no está en el repositorio actual de Termux y podía hacer que `pkg install` abortase todo el lote. La versión 1.16.1 lo elimina: ICMP no es una dependencia obligatoria para ADB ni para la búsqueda TCP.

Si ya tienes el ZIP 1.16.0 extraído, puedes desbloquear su instalador sin borrar configuración ni archivos:

```bash
cd "$HOME/Dogo_Box_Tv"
sed -i 's/ iputils//g' instalar-termux.sh
bash instalar-termux.sh
```

Esta reparación cambia el instalador de tu copia; para obtener también las mejoras de detección de ping, utiliza el paquete 1.16.1. Ahora se busca `ping` en PATH y, si no aparece, se comprueba `/system/bin/ping` en Android. Si no existe, el descubrimiento IPv4 automático recurre a TCP después de verificar la subred local. Si el firmware bloquea ICMP, puedes elegir explícitamente `discover --method tcp --network TU_SUBRED`. IPv6 puede utilizar vecinos en modo pasivo o una dirección conocida.

No se propone `inetutils` como sustituto: el paquete actual de Termux desactiva sus programas ping y ping6 en la compilación.

## Derivados y otros intérpretes Android

No se presupone el nombre del paquete `com.termux`. Las rutas se obtienen de `HOME`, `PREFIX`, `XDG_CONFIG_HOME`, `XDG_DATA_HOME` y `TMPDIR`, y los ejecutables se buscan en `PATH`. También se reconoce Python cuyo `sys.platform` es `android`.

Si tu entorno no tiene `pkg`, instala **Python 3.10+, ADB, tmux con display-popup y una shell compatible** con su gestor o sus paquetes nativos. Después, desde una carpeta privada:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
bash iniciar.sh doctor
```

Si tu intérprete no proporciona `venv`, puedes instalar las dependencias mediante el mecanismo soportado por esa aplicación y ejecutar `python3 Dogo_Box_Tv.py`. Los comandos no interactivos pueden utilizarse sin prompt_toolkit y sin tmux; las preguntas con cuadros necesitan prompt_toolkit y la shell delimitada necesita tmux. Un binario Linux de escritorio no sustituye a un ADB o tmux nativo compatible con Android y la arquitectura del teléfono.

En distribuciones Linux dentro de proot, usa los paquetes correspondientes a esa distribución y su intérprete; proot no elimina los permisos de red del Android que lo aloja. El instalador automático no es un instalador universal para todas las aplicaciones Android.

## Conectar por ADB

Utiliza **17** para introducir la IP del dispositivo y su puerto ADB. La herramienta guarda la selección después de comprobar el estado `device`. Desde otra terminal Android, la autorización ADB puede ser distinta de la que ya aceptaste para tu PC; acepta en el TV-box la autorización si aparece.

Ejemplos, sustituyendo las direcciones por las de tu equipo:

```bash
# Conectar y guardar el destino comprobado
bash iniciar.sh select 192.168.0.101 --port 3222

# Utilizar una IPv6 link-local con la interfaz del teléfono
bash iniciar.sh select 'fe80::2e73:60ff:fef1:78d0%wlan0' --port 3222

# Consultar estado y abrir la shell encuadrada
bash iniciar.sh status
bash iniciar.sh shell
```

Si el destino usa depuración inalámbrica con emparejamiento de Android, completa primero `adb pair IP:PUERTO_DE_EMPAREJAMIENTO` en Termux y después conecta mediante el puerto de conexión que muestre Android. No se presupone que ambos puertos sean iguales. El script no registra códigos de emparejamiento.

La conexión USB desde una aplicación Android depende de permisos y soporte adicionales del sistema; no se garantiza que un cable OTG baste. La vía documentada y preparada aquí es ADB por red.

## Configuración y archivos privados

Con los valores predeterminados de Android:

| Dato | Ruta |
| --- | --- |
| Configuración | `$HOME/.config/Dogo_Box_Tv/config.json` |
| Capturas, vídeos, reportes y registro | `$HOME/.local/share/Dogo_Box_Tv/salidas/` |
| Sesiones de directo | Junto a la configuración, en `.tvbox-streams/` |
| Temporales | `TMPDIR`, o `$PREFIX/tmp`, o una carpeta privada de caché |

Se respetan `XDG_CONFIG_HOME` y `XDG_DATA_HOME` si están definidos. `--config` tiene prioridad sobre `TVBOX_CONFIG` y sobre la ruta predeterminada; `--output-dir` tiene prioridad sobre la carpeta configurada. Una ruta de salida relativa en un archivo de configuración se resuelve junto a ese archivo. El `config.json` situado dentro del proyecto no se carga automáticamente en Android: así no se arrastran rutas o destinos de otra PC.

Puedes guardar un resultado explícitamente en almacenamiento compartido si Android te concedió acceso. El guardado sin sobrescritura funciona aunque ese sistema no admita enlaces duros; en ese caso utiliza creación exclusiva y copia. Esa copia no ofrece la misma publicación atómica que un enlace duro: un lector podría ver el archivo durante la escritura. Si falla, se intenta retirar solo la copia parcial creada por esa operación. La validación de PNG/MP4 se mantiene.

## Descubrir equipos cuando Android restringe la red

Los permisos del sistema pueden impedir consultar interfaces o tablas de vecinos mediante `ip`, aunque ADB o TCP por dirección conocida sí funcionen. El diagnóstico informa si puede enumerar las interfaces IPv4. La opción **10** ofrece introducir una subred manual cuando esa consulta falla en Android.

Desde comandos:

```bash
bash iniciar.sh discover --method tcp --network 192.168.0.0/24 --ports 3222,5555
```

Indica la **subred real de tu Wi-Fi**, consultando sus ajustes. El programa no inventa una máscara `/24`. Comprueba que la IP local que el sistema usaría para esa ruta esté dentro de la subred indicada antes de sondear.

Este método:

- No utiliza Nmap, sockets raw, ARP ni acceso a la tabla de vecinos.
- Admite como máximo 1024 direcciones y entre 1 y 16 puertos por dirección. La espera se ajusta con `--timeout`, entre 0.1 y 10 segundos.
- Muestra respuestas TCP, tanto de puertos abiertos como rechazados, además de la IP local. No garantiza descubrir todos los equipos y no identifica servicios.
- No obtiene MAC ni fabricante. No sustituye a la búsqueda por MAC.
- Usa la ruta del sistema; no se combina con `--interface` ni con `--passive`.
- Conserva los errores locales en JSON y marca el resultado como parcial si los hubo, en vez de presentar un bloqueo de permisos como ausencia de equipos.

El modo `auto` puede recurrir a TCP en Android si la enumeración falla y se proporcionó una subred explícita sin interfaz ni modo pasivo. El descubrimiento IPv6 sigue dependiendo de permisos para obtener interfaces; si solo falla la tabla de vecinos conserva las respuestas multicast observadas. Si Android impide enumerar IPv6, puedes pegar una dirección conocida con su ámbito en **11** o **17**. No se intenta recorrer un `/64`.

Algunas versiones de Android también restringen conexiones LAN mediante permisos de la aplicación anfitriona. Si aparecen errores de permiso, revisa los permisos de red/Wi-Fi que admita esa aplicación. Python no puede concedérselos por sí solo. [Referencia oficial de Android](https://developer.android.com/privacy-and-security/local-network-permission).

## Funciones y condiciones

| Función | Desde una terminal Android |
| --- | --- |
| Menú, colores, cuadros y preguntas | Con prompt_toolkit; los campos largos se desplazan dentro del marco |
| ADB, estado, shell, imágenes, PNG y MP4 | Con ADB nativo y un destino conectado/autorizado |
| Shell encuadrada | Con tmux y PTY; adapta el marco al reducir y ampliar sin reiniciar la shell |
| TCP IPv4/IPv6 por dirección conocida | Sujeto a conectividad y permisos de red de la aplicación |
| Descubrimiento IPv4 por TCP | Con una subred explícita y verificable por la ruta local |
| Descubrimiento por vecinos, MAC e IPv6 multicast | Sujeto a herramientas y permisos del Android |
| Directo scrcpy | Requiere scrcpy y un entorno gráfico, por ejemplo Termux:X11 con DISPLAY configurado |
| Gestión de directos entre sesiones | Requiere poder verificar la identidad de los procesos; no se envían señales a procesos sin verificar |

Para el directo, Termux mantiene [scrcpy en sus paquetes X11](https://github.com/termux/termux-packages/blob/master/x11-packages/scrcpy/build.sh). La preparación del repositorio y cliente puede hacerse con:

```bash
pkg install x11-repo
pkg install scrcpy
```

Instala y configura también la aplicación/servidor [Termux:X11 siguiendo su guía](https://github.com/termux/termux-x11). Solo tener `DISPLAY` definido no demuestra que el servidor gráfico esté funcionando. El instalador básico no instala el entorno gráfico. Las capturas PNG y la grabación MP4 no necesitan una ventana gráfica en el cliente.

## Alcance de la validación

Se verifican el código y su regresión en Linux, con pruebas que simulan Android, un PREFIX de otra aplicación, HOME privado, permisos de red denegados y almacenamiento sin enlaces duros. Hay una prueba real con PTY/tmux local que amplía y reduce el cuadro conservando una variable de la shell y el código de salida 7. El instalador se verifica con un gestor `pkg` simulado; no se modifican los paquetes de la PC durante esa prueba.

**Todavía no se ha ejecutado esta versión dentro de una instalación real de Termux en un teléfono o en el TV-box.** No se afirma compatibilidad con todas las derivaciones o firmwares. El diagnóstico identifica las dependencias presentes y las restricciones detectables en cada instalación.

Esta adaptación prepara el script para ejecutarlo desde Android. El objetivo de convertir la TV-box en servidor con dirección remota fija permanece documentado en `ACCESO_REMOTO.md`; no se generó todavía una dirección `.onion` ni se configuró acceso desde Internet.

## Fuentes de paquetes

- [Aplicación Termux e instalación](https://github.com/termux/termux-app).
- [ADB en android-tools](https://github.com/termux/termux-packages/blob/master/packages/android-tools/build.sh).
- [tmux para Termux](https://github.com/termux/termux-packages/blob/master/packages/tmux/build.sh).
- [Política de paquetes Python/pip](https://github.com/termux/termux-packages/discussions/2881).
