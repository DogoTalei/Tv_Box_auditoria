#!/usr/bin/env python3
"""Dogo_Box_Tv — Firma: Dogo."""

import sys

if sys.version_info < (3, 10):
    print("Dogo_Box_Tv requiere Python 3.10 o posterior.", file=sys.stderr)
    raise SystemExit(2)

from tvbox import main


if __name__ == "__main__":
    raise SystemExit(main())
