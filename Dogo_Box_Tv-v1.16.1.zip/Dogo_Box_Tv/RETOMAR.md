# Retomar Dogo_Box_Tv

Firma: Dogo. Versión: 1.16.1.

Estado guardado: 2026-11-11 01:50:20 CST.

## Uso desde Termux o un derivado Android

Consulta [TERMUX.md](TERMUX.md). Extrae el paquete dentro de `$HOME`, ejecuta `bash instalar-termux.sh` y luego `bash iniciar.sh`. El instalador prepara las dependencias en un entorno Python del proyecto. Android conserva su configuración en una ruta privada y no reutiliza automáticamente el `config.json` de la PC. La validación en una instalación real de Termux aún está pendiente.

## Inicio después de encender la PC

```bash
/home/dogo/Dogo_Box_Tv/iniciar.sh
```

El acceso `/home/dogo/Dogo_Box_Tv` enlaza a `/home/dogo/tvbox-tools`; ambos usan la misma configuración y salidas. Si hay problemas con la interfaz, utiliza la opción 6 para revisar dependencias. Se necesita una terminal compatible con UTF-8 y controles de terminal para los cuadros interactivos.

1. Enciende el TV-box y conecta la PC a su misma red.
2. Usa **2** para verificar el estado del destino guardado. Si cambió su dirección, utiliza **15** o **10** para descubrir y **17** para conectar y guardar el destino verificado.
3. Usa **18** para la shell, **5** para el directo o **19** para mostrar una imagen elegida.
4. **0** sale del menú y cierra los directos que ese menú creó. La shell regresa al menú con `exit` o Ctrl+D; Ctrl+C interrumpe el comando remoto.

## Referencias de conexión del propietario

- Destino guardado: `[fe80::2e73:60ff:fef1:78d0%wlan0]:3222`.
- IPv4 observada del TV-box: `192.168.0.101`.
- MAC: `2C:73:60:F1:78:D0`.
- Puerto ADB observado: `3222/TCP`.
- La IPv6 link-local necesita la interfaz `%wlan0`. Si cambia el nombre de interfaz o la red, selecciona de nuevo el destino.
- Se verificó anteriormente una shell root mediante el mecanismo nativo `adb root`, sin exploit. No se presupone que el privilegio persista tras reiniciar el TV-box: comprueba `id` en una nueva shell si necesitas saber el usuario actual.
- Apagar esta PC no apaga el TV-box ni modifica su configuración ADB.

## Opciones disponibles

| Opción | Función |
| --- | --- |
| 0 | Salir y cerrar los directos creados por este menú |
| 1 | Conexión temporal por red o selección USB |
| 2 | Verificar ADB, modelo y propiedades Android |
| 3 | Capturar pantalla PNG |
| 4 | Grabar vídeo MP4 |
| 5 | Iniciar directo con scrcpy |
| 6 | Diagnóstico de dependencias |
| 7 | Listar dispositivos ADB |
| 8 | Detener directo del destino |
| 9 | Listar directos registrados |
| 10 | Descubrir IPv4 y guardar selección |
| 11 | Elegir IP IPv4/IPv6 y comprobar puertos TCP |
| 12 | Temas y colores personalizados |
| 13 | Auditoría por etapas heredada, para IPv4 |
| 14 | Buscar un dispositivo por MAC |
| 15 | Descubrir IPv6, elegir fila o pegar una dirección y revisar puertos |
| 16 | Revisar servicios y problemas de configuración con evidencias |
| 17 | Conectar ADB por IP o fila y guardar el destino verificado |
| 18 | Shell ADB interactiva dentro de un marco personalizado |
| 19 | Enviar imagen o logo elegido y abrir un visor del TV-box |
| 20 | Retirar del primer plano la imagen administrada por la herramienta |

Se mantiene la preferencia del propietario de **no utilizar Nmap**. Las opciones 11, 15 y 16 no lo necesitan. En la auditoría heredada 13 deja desactivada la identificación opcional con Nmap.

## Qué quedó terminado

- Nombre Dogo_Box_Tv, firma Dogo, tema predeterminado cian/verde y temas personalizables.
- Descubrimiento y selección por IPv4/IPv6; comprobación de puertos a voluntad sin cambiar automáticamente la selección ADB.
- Conexión ADB verificada, shell interactiva, capturas, grabación, directos y visualización/retirada de imágenes.
- Resultados, avisos, errores y progresos dentro de cuadros que ajustan las líneas largas al ancho disponible. Las preguntas usan campos editables delimitados, con desplazamiento horizontal del texto largo.
- Shell real dentro de una PTY delimitada por tmux, con firma, ajuste al redimensionar y conservación del código de salida. La sesión tmux es privada y temporal; no se reutilizan sesiones ni configuración tmux del usuario.
- JSON de comandos no interactivos sin decoración. La herramienta no guarda el contenido escrito o mostrado en la shell.

## Código, documentación y archivos

| Archivo o carpeta | Contenido |
| --- | --- |
| `Dogo_Box_Tv.py`, `iniciar.sh` | Lanzadores |
| `branding.py` | Nombre, firma y versión |
| `tvbox.py` | Menú, comandos, red, ADB y multimedia |
| `tvbox_runtime.py` | Detección Android/Termux, rutas privadas, shell y capacidades |
| `instalar-termux.sh`, `requirements.txt` | Instalación en Termux y dependencias Python |
| `TERMUX.md` | Guía y límites de la ejecución desde Android |
| `terminal_ui.py` | Cuadros, cálculo de ancho y editor de entrada |
| `shell_frame.py` | Terminal tmux privada para la shell |
| `tvbox_audit.py` | Auditoría IPv4 heredada |
| `tvbox_vuln.py` | Comprobaciones de servicios y reportes |
| `tests/` | Pruebas automatizadas |
| `config.json` | Configuración real y destino guardado; conservar localmente |
| `config.example.json` | Configuración de ejemplo para distribuir |
| `salidas/` | Capturas, vídeos, reportes, registros y evidencias privadas |
| `.tvbox-streams/` | Registros de los directos gestionados |
| `README.md` | Manual de uso y dependencias |
| `VALIDACION.md` | Pruebas realizadas y sus alcances |
| `AVANCE.md` | Historial y estado del proyecto |
| `SHA256SUMS.txt` | Hashes de los paquetes de esta entrega |

Dependencias de interfaz presentes: tmux 3.7c y prompt_toolkit 3.0.53. El diagnóstico también informa ADB y scrcpy. En Debian/Ubuntu, las dependencias nuevas se instalan con `sudo apt install tmux python3-prompt-toolkit`. Los comandos no interactivos no requieren esas dependencias de interfaz.

## Validación y límites

La suite completa registrada para esta versión aprobó **159 pruebas**. Tras reforzar la limpieza se aprobaron las 9 pruebas del módulo de terminal. En este cierre documental se verificaron integridad ZIP, SHA-256 y ausencia de directos registrados; no se cambiaron funciones ni se repitieron operaciones de red contra el TV-box.

Pruebas previas de esta versión: cuadros entre 6 y 100 columnas; entradas PTY de 200 caracteres a 36/48 columnas; shell local redimensionada de 80 a 48 columnas y salida 7 conservada. En el TV-box se comprobaron estado, shell, `pwd`, texto largo, Ctrl+C y regreso al menú con Ctrl+D. La última shell probada conservó el código 130 de un comando interrumpido, que no indica por sí solo un fallo de conexión.

- El descubrimiento IPv6 consulta multicast y vecinos: no recorre un /64 ni garantiza encontrar todos los equipos.
- Un puerto abierto no identifica por sí mismo el servicio ni demuestra una vulnerabilidad; la falta de respuesta no confirma filtrado.
- La opción 16 realiza comprobaciones acotadas; las coincidencias NVD son candidatas por validar, no CVE confirmadas.
- La detección de imágenes activas depende del formato de diagnóstico del firmware. La copia remota permanece al retirar la imagen de la pantalla.
- La shell enmarcada necesita tmux con display-popup y una terminal compatible. Las pruebas de shell real utilizaron al menos 18 filas; los anchos mínimos del menú se verificaron mediante renderizado.
- No hay una función pendiente necesaria para completar la solicitud de los cuadros. Las mejoras nuevas se decidirán al retomar.

## Cierre de esta sesión

La configuración, los archivos del usuario y las evidencias se conservan en el proyecto. Los paquetes distribuibles incluyen configuración de ejemplo, sin el destino privado ni los registros/salidas. El resultado de la programación del apagado quedará anotado en `AVANCE.md`.
