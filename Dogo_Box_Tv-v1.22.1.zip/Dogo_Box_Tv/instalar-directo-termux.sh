#!/bin/sh
# Componentes gráficos opcionales para la opción 5.
set -eu
if [ -z "${PREFIX:-}" ] || ! command -v pkg >/dev/null 2>&1; then
    echo 'Este instalador requiere Termux o un derivado con PREFIX y pkg.' >&2
    exit 1
fi
if [ "$(id -u)" = 0 ]; then
    echo 'Ejecuta este instalador como usuario normal de Termux, sin su ni sudo.' >&2
    exit 1
fi
echo 'Dogo_Box_Tv · Directo desde Android · Firma: H4ckZone_by_Dogo'
pkg install -y x11-repo
pkg install -y scrcpy termux-x11-nightly
scrcpy --version
echo 'Instala también la aplicación Termux:X11 de su publicación oficial:'
echo 'https://github.com/termux/termux-x11/releases/tag/nightly'
echo 'Archivo: termux-x11-universal-debug.apk'
echo 'Después abre Dogo_Box_Tv y usa 17 para conectar el TV box y 5 para ver el directo.'
echo 'La opción 5 configura la pantalla X11 para ese proceso; no necesitas editar .bashrc.'
