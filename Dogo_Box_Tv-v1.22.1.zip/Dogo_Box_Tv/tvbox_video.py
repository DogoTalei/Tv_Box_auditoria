"""Validated video settings and bounded reading of scrcpy performance logs."""
from pathlib import Path
import re


def settings(value, presets):
    if not isinstance(value, dict) or set(value) - {"profile", "max_size", "fps", "bitrate"}:
        raise ValueError("Los ajustes de vídeo deben contener perfil, tamaño, FPS y bitrate.")
    name = value.get("profile")
    if name not in presets:
        raise ValueError("Perfil de vídeo desconocido.")
    result = {"profile": name, **presets[name], **value}
    for key, low, high in (("max_size", 320, 3840), ("fps", 1, 60), ("bitrate", 100000, 100000000)):
        if type(result[key]) is not int or not low <= result[key] <= high:
            raise ValueError(f"{key} debe estar entre {low} y {high}.")
    return result


def tail(path, limit=65536):
    with Path(path).open("rb") as handle:
        handle.seek(0, 2)
        handle.seek(max(0, handle.tell() - limit))
        return handle.read(limit).decode(errors="replace")


def statistics(path):
    try:
        text = tail(path)
    except OSError:
        return None
    samples = re.findall(r"INFO:\s+(\d+) fps(?:\s+\(\+(\d+) frames skipped\))?", text)[-10:]
    if not samples:
        return None
    fps = [int(item[0]) for item in samples]
    skipped = [int(item[1] or 0) for item in samples]
    return {"samples": len(samples), "recent_fps": round(sum(fps)/len(fps), 1),
            "recent_skipped_per_second": round(sum(skipped)/len(skipped), 1),
            "suggest_mobile": len(samples) >= 3 and sum(skipped)/len(skipped) > 2}
