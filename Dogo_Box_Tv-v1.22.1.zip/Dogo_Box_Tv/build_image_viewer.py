"""Build the bundled viewer from its embedded source; requires an Android SDK/JDK."""
import argparse
import base64
import hashlib
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

import tvbox_image_viewer as viewer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sdk", required=True, type=Path)
    parser.add_argument("--java-home", required=True, type=Path)
    parser.add_argument("--keystore", required=True, type=Path)
    parser.add_argument("--password-file", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--embed", action="store_true")
    args = parser.parse_args()
    sdk, java = args.sdk.resolve(), args.java_home.resolve()
    tools = sorted((sdk / "build-tools").iterdir(), key=lambda p: tuple(int(x) for x in re.findall(r"\d+", p.name)))[-1]
    platform = sorted((sdk / "platforms").glob("*/android.jar"), key=lambda p: tuple(int(x) for x in re.findall(r"\d+", p.parent.name)))[-1]
    environment = dict(os.environ, JAVA_HOME=str(java), PATH=str(java / "bin") + os.pathsep + os.environ.get("PATH", ""))
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    def run(command):
        subprocess.run([str(part) for part in command], env=environment, check=True)
    with tempfile.TemporaryDirectory(prefix="dogo-viewer-build-") as temporary:
        root = Path(temporary)
        manifest, source = root / "AndroidManifest.xml", root / "ViewerActivity.java"
        manifest.write_text(viewer.MANIFEST)
        source.write_text(viewer.JAVA_SOURCE)
        classes, dex = root / "classes", root / "dex"
        classes.mkdir(); dex.mkdir()
        run([java / "bin/javac", "--release", "8", "-classpath", platform, "-d", classes, source])
        run([tools / "d8", "--min-api", "21", "--lib", platform, "--output", dex, *sorted(classes.rglob("*.class"))])
        unsigned, aligned = root / "unsigned.apk", root / "aligned.apk"
        run([tools / "aapt", "package", "-f", "-M", manifest, "-I", platform, "-F", unsigned])
        with zipfile.ZipFile(unsigned, "a", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.write(dex / "classes.dex", "classes.dex")
        run([tools / "zipalign", "-f", "4", unsigned, aligned])
        run([tools / "apksigner", "sign", "--ks", args.keystore.resolve(), "--ks-key-alias", "dogo-image-viewer",
             "--ks-pass", "file:" + str(args.password_file.resolve()), "--out", output, aligned])
        run([tools / "apksigner", "verify", "--verbose", output])
    payload = output.read_bytes()
    checksum = hashlib.sha256(payload).hexdigest()
    if args.embed:
        path = Path(viewer.__file__)
        text = path.read_text().split('# Generated from JAVA_SOURCE and MANIFEST')[0]
        encoded = base64.b64encode(payload).decode("ascii")
        text += '# Generated from JAVA_SOURCE and MANIFEST by build_image_viewer.py.\n'
        text += f'APK_SHA256 = "{checksum}"\nAPK_BASE64 = (\n'
        text += ''.join(f'    "{encoded[n:n+120]}"\n' for n in range(0, len(encoded), 120))
        path.write_text(text + ')\n')
    print(f"APK: {output} ({len(payload)} bytes); SHA256: {checksum}")


if __name__ == "__main__":
    main()
