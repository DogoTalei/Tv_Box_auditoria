#!/bin/sh
# Ejecutar desde la terminal Android: bash instalar-termux.sh
set -eu
umask 077
TVBOX_SETUP_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
TVBOX_SETUP_MODE=${1:-instalar}
case "$TVBOX_SETUP_MODE" in
    instalar|--comprobar) ;;
    *) echo 'Uso: bash instalar-termux.sh [--comprobar]' >&2; exit 2 ;;
esac
if [ -z "${PREFIX:-}" ] || ! command -v pkg >/dev/null 2>&1; then
    echo 'Este instalador requiere Termux o un derivado con PREFIX y pkg.' >&2
    echo 'Otros entornos: consulta TERMUX.md para la instalación manual con Python.' >&2
    exit 1
fi
case "$TVBOX_SETUP_DIR" in
    /sdcard|/sdcard/*|/storage/*|/mnt/media_rw/*)
        echo 'Copia o extrae el proyecto dentro de tu HOME privado antes de instalarlo.' >&2
        echo 'El almacenamiento compartido de Android limita permisos y ejecución.' >&2
        exit 1 ;;
esac
if [ "$(id -u)" = 0 ]; then
    echo 'Ejecuta el instalador como usuario normal de Termux, sin su ni sudo.' >&2
    exit 1
fi
cd -- "$TVBOX_SETUP_DIR"
echo 'Dogo_Box_Tv · Firma: H4ckZone_by_Dogo · Preparación para Termux'
echo 'Paquetes: python python-pip libexpat libprotobuf python-ensurepip-wheels android-tools tmux iproute2'
echo 'Interfaz Python: requirements.txt, en .venv (sin actualizar pip del sistema).'
if [ "$TVBOX_SETUP_MODE" = --comprobar ]; then
    echo 'Comprobación terminada; no se instalaron paquetes ni se modificó la configuración.'
    exit 0
fi
pkg update -y
pkg install -y python python-pip libexpat libprotobuf python-ensurepip-wheels android-tools tmux iproute2
# An already-installed android-tools can retain older C++ libraries after a
# partial Termux update. Synchronize its declared dependencies, not unrelated apps.
if command -v apt-cache >/dev/null 2>&1; then
    TVBOX_ADB_DEPS=$(apt-cache depends --important android-tools | awk '$1 == "Depends:" && $2 ~ /^[a-z0-9][a-z0-9+.-]*$/ {print $2}' | sort -u)
    if [ -n "$TVBOX_ADB_DEPS" ]; then
        echo 'Sincronizando las dependencias nativas declaradas por android-tools…'
        # The list contains only package names validated by the filter above.
        pkg install -y $TVBOX_ADB_DEPS
    fi
fi
TVBOX_SETUP_PYTHON=$(command -v python3 || command -v python)
"$TVBOX_SETUP_PYTHON" -c 'import sys, pyexpat, ssl; sys.exit(0 if sys.version_info >= (3, 10) else "Se requiere Python 3.10 o posterior.")'
adb version
if [ ! -x .venv/bin/python ]; then
    "$TVBOX_SETUP_PYTHON" -m venv .venv
fi
if ! .venv/bin/python -m pip --version >/dev/null 2>&1; then
    echo 'Reparando pip dentro del entorno Python existente…'
    .venv/bin/python -m ensurepip --default-pip
fi
.venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt
.venv/bin/python -c 'import prompt_toolkit, wcwidth; from prompt_toolkit.application import Application; from prompt_toolkit.widgets import Frame, Label, TextArea; print("Interfaz de entrada verificada.")'
.venv/bin/python Dogo_Box_Tv.py --version
echo 'Instalación terminada. Inicio: bash iniciar.sh'
echo 'Diagnóstico: bash iniciar.sh doctor'
echo 'Ping es opcional: se usa el de Android si está disponible; también puedes descubrir por TCP.'
echo 'Para la opción 5: bash instalar-directo-termux.sh y la aplicación Termux:X11.'
echo 'Consulta TERMUX.md para ADB por Wi-Fi, permisos de Android y directo con entorno gráfico.'
