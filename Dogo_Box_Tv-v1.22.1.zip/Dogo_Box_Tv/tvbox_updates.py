"""Local ZIP updates with integrity checks, private backups and rollback."""
from __future__ import annotations

import ast
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import uuid
import zipfile


class UpdateError(Exception):
    pass


REQUIRED = {"Dogo_Box_Tv.py", "tvbox.py", "branding.py", "requirements.txt", "iniciar.sh"}
DOCUMENTS = {"README.md", "TERMUX.md", "VALIDACION.md", "RETOMAR.md", "AVANCE.md", "ACCESO_REMOTO.md", "MEJORAS.md"}


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1048576), b""):
            value.update(chunk)
    return value.hexdigest()


class Store:
    def __init__(self, root, config_path):
        self.root = Path(root).resolve()
        self.config_path = Path(config_path)
        self.folder = self.root / ".dogo-backups"
        if self.folder.is_symlink():
            raise UpdateError("La carpeta de respaldos no puede ser un enlace simbólico.")

    def target(self, name):
        path = self.root / name
        if path.is_symlink() or not path.resolve().is_relative_to(self.root):
            raise UpdateError("Ruta de actualización fuera del proyecto o enlazada: " + name)
        return path

    def inspect(self, archive, expected=None):
        archive = Path(archive).expanduser().resolve()
        if not archive.is_file() or archive.stat().st_size > 16*1024*1024:
            raise UpdateError("Elige un ZIP de hasta 16 MiB.")
        if expected is None:
            sidecar = archive.with_suffix(".sha256")
            if not sidecar.is_file():
                raise UpdateError("Indica --sha256 o conserva el archivo .sha256 junto al ZIP.")
            words = sidecar.read_text().split() if sidecar.stat().st_size <= 4096 else []
            expected = words[0] if words else ""
        if not re.fullmatch(r"[a-fA-F0-9]{64}", expected or "") or digest(archive) != expected.lower():
            raise UpdateError("El SHA256 del paquete no coincide. No se modificó el proyecto.")
        data, seen, total = {}, set(), 0
        try:
            with zipfile.ZipFile(archive) as zipped:
                if len(zipped.infolist()) > 512:
                    raise UpdateError("El ZIP contiene demasiadas entradas.")
                for member in zipped.infolist():
                    name = member.filename
                    parts = PurePosixPath(name).parts
                    if name in seen or "\\" in name or name.startswith("/") or ".." in parts or not parts or parts[0] != "Dogo_Box_Tv":
                        raise UpdateError("Ruta inválida o duplicada dentro del ZIP.")
                    seen.add(name)
                    if name.rstrip("/") != "/".join(parts):
                        raise UpdateError("La ruta del ZIP no es canónica.")
                    if stat.S_ISLNK(member.external_attr >> 16) or member.flag_bits & 1:
                        raise UpdateError("El ZIP contiene enlaces o archivos cifrados.")
                    if member.is_dir():
                        continue
                    relative = "/".join(parts[1:])
                    if relative == "config.json":
                        continue
                    allowed = (len(parts) == 2 and (relative.endswith(".py") or relative in DOCUMENTS
                              or relative in {"iniciar.sh", "instalar-termux.sh", "instalar-directo-termux.sh", "requirements.txt", "config.example.json", ".gitignore"}))
                    allowed |= len(parts) == 3 and parts[1] == "tests" and parts[2].startswith("test_") and relative.endswith(".py")
                    total += member.file_size
                    if not allowed or member.file_size > 2*1024*1024 or total > 16*1024*1024:
                        raise UpdateError("Archivo no permitido o demasiado grande en el ZIP: " + relative)
                    self.target(relative)
                    body = zipped.read(member)
                    if relative.endswith(".py"):
                        ast.parse(body.decode("utf-8"), feature_version=(3, 10))
                    data[relative] = body
        except (zipfile.BadZipFile, SyntaxError, UnicodeError, RuntimeError) as error:
            raise UpdateError("Paquete dañado o Python incompatible: " + str(error)) from error
        if not REQUIRED <= data.keys():
            raise UpdateError("El ZIP no contiene los componentes básicos de Dogo_Box_Tv.")
        version = None
        for node in ast.parse(data["branding.py"].decode()).body:
            if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "VERSION" for target in node.targets):
                try:
                    version = ast.literal_eval(node.value)
                except (ValueError, TypeError):
                    pass
        if not isinstance(version, str) or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
            raise UpdateError("El paquete no declara una versión válida.")
        return {"archive": str(archive), "sha256": expected.lower(), "version": version, "files": len(data)}, data

    def backups(self):
        result = []
        if self.folder.exists():
            for path in sorted(self.folder.iterdir(), key=lambda item: item.name):
                if re.fullmatch(r"[a-f0-9]{32}", path.name) and not path.is_symlink():
                    try:
                        item = json.loads((path/"metadata.json").read_text())
                        result.append({key: item.get(key) for key in ("id", "version", "previous_version", "created_at", "state")})
                    except (OSError, ValueError):
                        continue
        return result

    def _write(self, name, body, mode):
        target = self.target(name)
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, filename = tempfile.mkstemp(prefix=".dogo-update-", dir=target.parent)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(body)
                os.chmod(filename, mode)
            os.replace(filename, target)
        finally:
            Path(filename).unlink(missing_ok=True)

    def apply(self, archive, expected=None):
        plan, data = self.inspect(archive, expected)
        self.folder.mkdir(mode=0o700, exist_ok=True)
        backup = self.folder/uuid.uuid4().hex
        backup.mkdir(mode=0o700)
        metadata = {"id": backup.name, "version": plan["version"], "state": "prepared", "files": {},
                    "created_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"), "previous_version": None}
        previous = self.root/"branding.py"
        if previous.is_file():
            for node in ast.parse(previous.read_text()).body:
                if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "VERSION" for target in node.targets):
                    try:
                        metadata["previous_version"] = ast.literal_eval(node.value)
                    except (ValueError, TypeError):
                        pass
        for name, body in data.items():
            target = self.target(name)
            old = None
            mode = 0o755 if name.endswith(".sh") else 0o644
            if target.exists():
                if not target.is_file():
                    raise UpdateError("El destino no es un archivo: " + name)
                saved = backup/"files"/name
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
                old, mode = digest(saved), stat.S_IMODE(target.stat().st_mode)
            metadata["files"][name] = {"old": old, "new": hashlib.sha256(body).hexdigest(), "mode": mode}
        if self.config_path.is_file():
            shutil.copyfile(self.config_path, backup/"config-snapshot.json")
            (backup/"config-snapshot.json").chmod(0o600)
        self._metadata(backup, metadata)
        written = []
        try:
            for name, body in data.items():
                self._write(name, body, metadata["files"][name]["mode"])
                written.append(name)
        except BaseException:
            for name in reversed(written):
                entry = metadata["files"][name]
                if entry["old"] is None:
                    self.target(name).unlink()
                else:
                    self._write(name, (backup/"files"/name).read_bytes(), entry["mode"])
            metadata["state"] = "failed_restored"
            self._metadata(backup, metadata)
            raise
        metadata["state"] = "applied"
        self._metadata(backup, metadata)
        return {"operation": "update", **plan, "backup_id": backup.name, "message": "Actualización instalada. Reinicia el programa para cargarla."}

    @staticmethod
    def _metadata(folder, metadata):
        target = folder/"metadata.json"
        fd, name = tempfile.mkstemp(prefix=".metadata-", dir=folder)
        try:
            with os.fdopen(fd, "w") as handle:
                json.dump(metadata, handle, indent=2)
            os.replace(name, target)
        finally:
            Path(name).unlink(missing_ok=True)

    def rollback(self, key):
        if not re.fullmatch(r"[a-f0-9]{32}", key):
            raise UpdateError("Identificador de respaldo inválido.")
        folder = self.folder/key
        if folder.is_symlink():
            raise UpdateError("El respaldo no puede ser un enlace.")
        metadata = json.loads((folder/"metadata.json").read_text())
        if metadata.get("state") != "applied":
            raise UpdateError("Ese respaldo no corresponde a una actualización aplicada.")
        for name, entry in metadata["files"].items():
            # Only paths produced by the ZIP validator are accepted on restore.
            if PurePosixPath(name).is_absolute() or ".." in PurePosixPath(name).parts or "\\" in name:
                raise UpdateError("Ruta de respaldo inválida.")
            if digest(self.target(name)) != entry["new"]:
                raise UpdateError("Hay cambios posteriores en " + name + "; se conserva el proyecto para no sobrescribirlos.")
            saved = folder/"files"/name
            if entry["old"] is not None and (saved.is_symlink() or not saved.resolve().is_relative_to(folder.resolve()) or digest(saved) != entry["old"]):
                raise UpdateError("El respaldo está dañado: " + name)
        current = {name: self.target(name).read_bytes() for name in metadata["files"]}
        written = []
        try:
            for name, entry in metadata["files"].items():
                if entry["old"] is None:
                    self.target(name).unlink()
                else:
                    self._write(name, (folder/"files"/name).read_bytes(), entry["mode"])
                written.append(name)
        except BaseException:
            for name in written:
                self._write(name, current[name], metadata["files"][name]["mode"])
            raise
        metadata["state"] = "rolled_back"
        self._metadata(folder, metadata)
        return {"operation": "rollback", "backup_id": key, "message": "Código anterior restaurado; configuración y archivos conservados. Reinicia el programa."}
