"""Read-only Android network access, including an explicitly paired local ADB."""
from __future__ import annotations

import ipaddress
import json
import os
from pathlib import Path
import re
import shlex
import socket
import struct
import subprocess
import tempfile
import time


class NetworkError(Exception):
    pass


def wifi_networks(ipv6=False):
    """Targeted ioctls work on some Android versions that prohibit netlink dumps.

    Only known Wi-Fi interfaces are considered; never guess a cellular subnet.
    MACs remain unavailable without permission to read the neighbor table.
    """
    import fcntl
    found = []
    for name in ("wlan0", "wlan1", "wifi0"):
        try:
            index = socket.if_nametoindex(name)
            item = {"interface": name, "mac": None, "default": True, "access": "android_wifi_ioctl"}
            if ipv6:
                with socket.socket(socket.AF_INET6, socket.SOCK_DGRAM) as connection:
                    # UDP connect selects the source without sending a packet.
                    connection.connect(("ff02::1", 9, 0, index))
                    source = connection.getsockname()[0].split("%", 1)[0]
                if not ipaddress.IPv6Address(source).is_link_local:
                    continue
                item.update(ip=source, addresses=[source], network="fe80::/64")
            else:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as connection:
                    request = struct.pack("256s", name.encode())
                    address = socket.inet_ntoa(fcntl.ioctl(connection, 0x8915, request)[20:24])
                    mask = socket.inet_ntoa(fcntl.ioctl(connection, 0x891b, request)[20:24])
                network = ipaddress.IPv4Network(f"{address}/{mask}", strict=False)
                if network.is_loopback or network.is_unspecified:
                    continue
                item.update(ip=address, network=str(network))
            found.append(item)
        except (OSError, ValueError):
            continue
    return found


def parse_ip(text, arguments):
    """Old Android ip accepts -j but silently emits text; parse its read-only output."""
    if "neigh" in arguments:
        records = []
        for line in text.splitlines():
            words = line.split()
            if not words:
                continue
            try:
                ipaddress.ip_address(words[0])
            except ValueError:
                continue
            item = {"dst": words[0], "state": [word for word in words[1:] if word in
                    {"REACHABLE", "STALE", "DELAY", "PROBE", "PERMANENT", "NOARP", "FAILED", "INCOMPLETE"}]}
            for source, target in (("lladdr", "lladdr"), ("dev", "dev")):
                if source in words and words.index(source) + 1 < len(words):
                    item[target] = words[words.index(source) + 1]
            records.append(item)
        return records
    records, current = [], None
    for line in text.splitlines():
        header = re.match(r"^\d+: ([^:@]+)(?:@[^:]+)?: <([^>]*)>", line)
        if header:
            current = {"ifname": header[1], "flags": header[2].split(","), "addr_info": []}
            records.append(current)
            continue
        if current is None:
            continue
        hardware = re.search(r"link/ether ([0-9a-fA-F:]{17})", line)
        if hardware:
            current["address"] = hardware[1]
        address = re.search(r"\b(inet6?) ([0-9a-fA-F:.]+)/([0-9]+).*\bscope (\w+)", line)
        if address:
            current["addr_info"].append({"family": "inet6" if address[1] == "inet6" else "inet",
                "local": address[2], "prefixlen": int(address[3]), "scope": address[4],
                "tentative": "tentative" in line, "dadfailed": "dadfailed" in line})
    return records


def loopback_endpoint(value):
    match = re.fullmatch(r"127\.0\.0\.1:([0-9]{1,5})", value.strip())
    if not match or not 1 <= int(match[1]) <= 65535:
        raise NetworkError("Usa 127.0.0.1:PUERTO de depuración del propio teléfono.")
    return f"127.0.0.1:{int(match[1])}"


class LocalADB:
    """Never use the selected TV-box to enumerate the phone's network."""
    def __init__(self, adb, path):
        self.adb, self.path = adb, Path(path)
        self.endpoint, self.identity, self.checked = None, None, 0.0
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text())
                self.endpoint = loopback_endpoint(data["endpoint"])
                self.identity = data["identity"]
                if not isinstance(self.identity, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", self.identity):
                    raise ValueError("identidad inválida")
            except (ValueError, KeyError, TypeError, NetworkError) as error:
                raise NetworkError("Configuración de red ADB inválida; revisa la opción 21.") from error

    def run(self, arguments, timeout=12):
        if not self.adb:
            raise NetworkError("Instala android-tools para utilizar acceso de red por ADB local.")
        try:
            # Keep the phone's helper separate from TV-box ADB connections.
            result = subprocess.run([self.adb, "-P", "5038", *arguments], stdin=subprocess.DEVNULL,
                                    capture_output=True, timeout=timeout)
        except (OSError, subprocess.TimeoutExpired) as error:
            raise NetworkError(f"ADB local no respondió: {error}. Revisa la opción 21.") from error
        if result.returncode:
            raise NetworkError("ADB local: " + (result.stderr or result.stdout).decode(errors="replace").strip()[-500:])
        return result

    def remote_identity(self, endpoint):
        return self.run(["-s", endpoint, "shell", "getprop ro.serialno"]).stdout.decode().strip()

    def connect(self, endpoint):
        endpoint = loopback_endpoint(endpoint)
        self.run(["connect", endpoint])
        identity = self.remote_identity(endpoint)
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", identity):
            raise NetworkError("No se pudo comprobar la identidad del Android local.")
        self.endpoint, self.identity, self.checked = endpoint, identity, time.monotonic()
        self.save()
        return {"endpoint": endpoint, "identity": identity, "access": "local_adb"}

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        descriptor, filename = tempfile.mkstemp(prefix=".network-adb-", dir=self.path.parent)
        temporary = Path(filename)
        try:
            with os.fdopen(descriptor, "w") as handle:
                json.dump({"endpoint": self.endpoint, "identity": self.identity}, handle)
                handle.write("\n")
            os.replace(temporary, self.path)
        finally:
            temporary.unlink(missing_ok=True)

    def ensure(self):
        if time.monotonic() - self.checked < 5:
            return
        try:
            if self.remote_identity(self.endpoint) == self.identity:
                self.checked = time.monotonic()
                return
        except NetworkError:
            try:
                self.run(["connect", self.endpoint])
                if self.remote_identity(self.endpoint) == self.identity:
                    self.checked = time.monotonic()
                    return
            except NetworkError:
                pass
        # TLS ports change when wireless debugging restarts. Only reconnect to
        # announcements at our own Wi-Fi address and verify the saved identity.
        local = {item["ip"] for item in wifi_networks()}
        try:
            services = self.run(["mdns", "services"]).stdout.decode(errors="replace")
            for line in services.splitlines()[:64]:
                words = line.split()
                if len(words) < 3 or "_adb-tls-connect._tcp" not in words[1]:
                    continue
                host, _, port = words[-1].rpartition(":")
                if host not in local or not port.isdecimal():
                    continue
                candidate = loopback_endpoint("127.0.0.1:" + port)
                self.run(["connect", candidate])
                if self.remote_identity(candidate) == self.identity:
                    self.endpoint, self.checked = candidate, time.monotonic()
                    self.save()
                    return
        except NetworkError:
            pass
        raise NetworkError("ADB local desconectado o identidad distinta. Activa depuración inalámbrica y reconecta con la opción 21.")

    def query(self, arguments):
        self.ensure()
        if "route" in arguments:
            # Android policy routes do not reliably identify Wi-Fi from shell.
            data = [{"dev": item["interface"]} for item in wifi_networks()]
        else:
            family = "-6" if "-6" in arguments else "-4" if "-4" in arguments else None
            if "neigh" in arguments:
                interface = arguments[-1]
                if not re.fullmatch(r"[A-Za-z0-9_.-]{1,32}", interface):
                    raise NetworkError("Interfaz inválida.")
                command = ["/system/bin/ip", family, "neigh", "show", "dev", interface]
            elif "link" in arguments or "addr" in arguments or "address" in arguments:
                command = ["/system/bin/ip", *([family] if family and "link" not in arguments else []), "address", "show"]
            else:
                raise NetworkError("Consulta de red no admitida.")
            text = self.run(["-s", self.endpoint, "shell", shlex.join(command)]).stdout.decode(errors="replace")
            data = parse_ip(text, arguments)
        return subprocess.CompletedProcess(arguments, 0, json.dumps(data).encode(), b"")
