# Dogo_Box_Tv — avance del proyecto

Firma: H4ckZone_by_Dogo

Última actualización: 2026-11-12 12:07:18 CST.

## Estado del proyecto

- Carpeta: `/home/dogo/tvbox-tools`.
- Nombre actual: **Dogo_Box_Tv**. Firma: **Dogo**.
- Versión actual: **1.19.1**.
- Inicio: `/home/dogo/Dogo_Box_Tv/iniciar.sh`. También disponible `Dogo_Box_Tv.py`.
- Paquete: `/home/dogo/Dogo_Box_Tv-v1.19.1.zip`.
- SHA-256 del paquete: `aed6082b05c70d7521a39cf330938fe9f98f43208c03989b56c45839a2fbb62a`.
- Selección ADB persistente verificada: `[fe80::2e73:60ff:fef1:78d0%wlan0]:3222`.

## Galería y selector de imagen, 1.19.0

La opción **19** ofrece selector visual y ruta manual. En Android abre una página local que permite elegir desde el selector de fotos, revisar vista previa y confirmar con **Enviar al TV**. El resultado se comunica tras completar el envío; se intenta regresar a Termux. En escritorio se utilizan diálogos de archivos disponibles. La opción **20** conserva la retirada de la imagen.

Se probaron selección, envío y retirada en el teléfono/TV reales con un PNG preparado y hash idéntico en destino. La regresión es de **233 casos en Linux** y **233 en Android, 7 omitidos de escritorio**. No se requieren nuevas dependencias Python ni APK. Se conserva la configuración del propietario y el mecanismo de respaldo/restauración. Detalles en [MEJORAS.md](MEJORAS.md#selector-visual-de-imagenes-1190).

## Mejoras 1.18.0, 2026-11-12

Se conservan los valores de los perfiles anteriores y se incorpora `movil` (960 px, 15 FPS, 2 Mbps). Opciones nuevas **22** equipos guardados, **23** calidad por equipo/cliente, **24** compatibilidad y **25** actualización local con respaldo/restauración. La recuperación de conexión es acotada a direcciones guardadas y verifica el número de serie. Se aplica al iniciar operaciones, sin reiniciar directos en un bucle.

La regresión añade protección de configuración y pruebas de fallos de actualización/restauración. Se probó primero en una copia aislada de Termux: conexión, captura en memoria, perfiles, calidad y arranque/cierre de ambos modos de vídeo. La pantalla estaba estática; no se afirma una mejora de FPS en movimiento todavía. Detalles en [MEJORAS.md](MEJORAS.md) y [VALIDACION.md](VALIDACION.md).

## Directo desde el teléfono, 1.17.1

Se corrigió la opción **5** para preparar y abrir Termux:X11 desde Android. Se instaló el visor oficial y los paquetes de vídeo/gráficos en el teléfono del propietario. El código comprueba los dos componentes de X11, espera el primer cuadro de vídeo y usa el wrapper am de Termux para abrir la aplicación con su identidad correcta. Se conserva el arranque de escritorio en Linux.

Verificado: directo real en el teléfono con scrcpy 5.0.1, renderizado software y vídeo 1280x720. La opción **8** detiene la sesión; la lista de directos queda vacía. La conexión del teléfono al TV box está guardada por IPv6. Regresión actual: **191 pruebas Linux OK** y **191 Android OK, 7 omitidas de escritorio**. Detalles y registros privados en [VALIDACION.md](VALIDACION.md).

Para otra instalación Android se añade `instalar-directo-termux.sh`; prepara los paquetes gráficos y señala el APK oficial. La aplicación y el paquete de terminal son necesarios. Las instrucciones actuales están en [TERMUX.md](TERMUX.md#directo-con-termuxx11-1171).

## Actualización de red Android, 1.17.0

Se corrigieron `ping -6` incompatible, SO_BINDTODEVICE denegado para IPv4 y pérdida de respuestas ICMP cuando Android no permite consultar MAC. Se incorporó consulta Wi-Fi por ioctl y la opción **21**, que configura ADB local seguro del propio teléfono para leer las MAC reales sin root. El acceso auxiliar utiliza un servidor separado en 5038, no cambia el destino TV box y comprueba identidad al reconectar.

Verificado en Termux real: siete IPv6 con MAC, y búsqueda por MAC del TV box mediante IPv6 con resultado `found`. La comprobación final IPv4 encontró router, TV box y teléfono con MAC. Antes se observó ARP fallido hacia el TV box, que luego respondió; no quedó probada la causa de la falta de respuesta inicial. La opción **14** ahora permite elegir IPv4/IPv6. La vinculación ya está configurada en el teléfono; si Android desactiva depuración inalámbrica, debe reactivarse y, si es necesario, reconectarse mediante 21.

Validación actual: **181 pruebas Linux OK** y **181 pruebas Android OK, 7 omitidas por ser de escritorio**. Detalles en [VALIDACION.md](VALIDACION.md) y uso en [TERMUX.md](TERMUX.md). Se conservan configuración, capturas, historial y respaldos. No se configuró acceso público al TV box.

## Funciones completadas

1. **Opción 15: descubrimiento IPv6.** Consulta multicast y vecinos de la interfaz. Muestra filas numeradas con IP, MAC y evidencia de respuesta actual o caché. Incluye el ámbito `%wlan0` cuando corresponde; no recorre un /64 completo ni garantiza descubrir todos los equipos.
2. **Reconocimiento directo después de descubrir.** Se puede pegar una IPv6 encontrada o elegir su fila. Si se omite el ámbito link-local, se añade la interfaz elegida. Después se indican puertos/rangos TCP y tiempo de espera. `0` o Enter regresa al menú.
3. **Opción 11: puertos de una IP elegida.** Acepta filas y direcciones manuales IPv4/IPv6, sin cambiar el destino ADB guardado. Muestra estados, destaca puertos abiertos y guarda JSON.
4. **Opción 16: revisión de vulnerabilidades.** Ofrece la última IP y puertos revisados; permite elegir otro destino. Comprueba el saludo de autenticación ADB, HTTP Basic sin TLS y negociación de TLS antiguo. HTTP sin cifrado, Telnet y anuncio SSH1 quedan como observaciones. La consulta NVD opcional busca candidatos por producto/versión observados; las coincidencias de texto no se presentan como CVE confirmadas.
5. **Reportes privados.** Las revisiones generan Markdown, JSON y hashes en `salidas/vulnerabilidades-FECHA-ID/`. Una falta de respuesta que impide revisar servicios queda como resultado inconcluso. Se conservan evidencias al cancelar.

## Validación

- **191 pruebas automatizadas aprobadas en Linux**, con `python3 -m unittest discover -s tests`.
- Pruebas reales del menú en terminal PTY: descubrimiento, selección de fila o IPv6 pegada, reconocimiento TCP y entrada a la opción 16 recordando el destino anterior.
- Verificado JSON en una terminal PTY, sin colores ni progreso intercalados.
- Verificados HTTP Basic en un servidor local de prueba y TLS 1.2 real por IPv6 con certificado temporal.
- ZIP verificado, extraído temporalmente e importado correctamente con el módulo nuevo.
- No se utilizó Nmap para estas funciones ni se cambiaron reglas de firewall o configuraciones de red.

## Observaciones reales del TV-box

- MAC identificada: `2C:73:60:F1:78:D0`.
- IPv4 comprobada desde el propio equipo: `192.168.0.101`.
- IPv6 link-local observada: `fe80::2e73:60ff:fef1:78d0%wlan0`.
- Cuando estuvo encendido: `3222/TCP` abierto; `22`, `80`, `443` y `5555` cerrados en los alcances revisados.
- Dos conexiones nuevas, sin claves ni firmas, recibieron CNXN en el saludo ADB. La herramienta registró `ADB-NO-AUTH`. Esto comprueba aceptación del saludo sin autenticar al cliente; no se abrieron streams ni se ejecutaron comandos en esa prueba, y no se demostró root ni una CVE específica.
- Evidencia inicial: `salidas/vulnerabilidades-20261110-143556-63ddf735/reporte.md` y `vulnerabilidades.json` en esa misma carpeta.
- Durante una prueba posterior el TV-box dejó de responder. **El usuario confirmó que lo había apagado**. No atribuir esos últimos tiempos de espera a una regresión del script ni inferir que el dispositivo es seguro.

## Diagnóstico de red anterior y límites pendientes

- La PC usa Wi-Fi HackZone, `192.168.0.103/24`, router `192.168.0.1`.
- Se observó fallo de ARP/IPv4 hacia otros equipos; el router respondía. Varios vecinos sí respondieron por IPv6, incluido el TV-box. No quedó probada una causa raíz para el fallo ARP ni un aislamiento completo de clientes.
- El fallo IPv4 ya se había registrado por Ethernet antes del cambio a Wi-Fi. El kernel y la actualización de red actuales ya se utilizaban durante la sesión que funcionaba.
- Diagnóstico y capturas: `/home/dogo/diagnostico-red-5xzuhmsz/INFORME.md`.
- Queda pendiente la inspección de filtros activos y la comparación ARP broadcast/unicast con administrador. La sesión no pudo ejecutar sudo sin contraseña. Script de diagnóstico preparado: `/home/dogo/diagnostico-red-5xzuhmsz/comprobar_arp.py`.
- No se identificó el inventario completo de los nueve dispositivos vistos en la aplicación del celular.

## Para retomar

1. Encender el TV-box y volver a abrir `iniciar.sh` para cargar la versión actual.
2. Elegir 15 y la interfaz activa. Volver a descubrir: filas, direcciones o interfaces pueden cambiar.
3. Pegar la IPv6 encontrada o elegir su fila; indicar puertos TCP.
4. Entrar en 16 para revisar esa IP. Enter reutiliza la última IP y los puertos, dentro de la misma sesión del menú. La memoria del último escaneo no se conserva al cerrar el programa.
5. Elegir 17 para conectar ADB a una IP o fila; indicar puerto y guardar o usar temporalmente. La opción 2 verifica el estado y las opciones 3/5 permiten capturar o iniciar el directo.
6. Contrastar cada observación y cualquier CVE candidata con el contexto, firmware y parches reales. El escáner cubre comprobaciones acotadas, no una evaluación exhaustiva de todas las vulnerabilidades.

El usuario solicitó guardar este avance y después apagar el computador.

Apagado programado correctamente para el **10 de noviembre de 2026 a las 14:51:49 CST**, después de guardar y sincronizar este documento.

## Sesión retomada — 10 de noviembre, 22:55

- La versión 1.9.0 y el paquete con su manifiesto siguen presentes.
- La PC sigue conectada por wlan0 con IPv4 192.168.0.103 y la misma IPv6 link-local.
- El nuevo descubrimiento observó cinco vecinos remotos con respuesta IPv6, incluido el TV-box de MAC 2C:73:60:F1:78:D0.
- Nueva comprobación de `22,80,443,3222,5555`: 3222 abierto y el resto cerrados.
- Se repitió la revisión local de vulnerabilidades. Volvió a observarse aceptación del saludo ADB sin claves ni reto AUTH; no se ejecutaron comandos remotos ni se verificó una CVE.
- Reporte actualizado: `salidas/vulnerabilidades-20261110-225522-3464541b/reporte.md`, con JSON de evidencias en la misma carpeta.


## Conexión ADB completada — versión 1.10.0

- Nueva opción 17: elegir IPv4/IPv6 por fila o manualmente, indicar el puerto y conectar con selección persistente o temporal.
- `connect` acepta `[IPv6%interfaz]:PUERTO`; `select` admite IPv6 y `--interface`. El ámbito se conserva en el serial que reciben ADB y las funciones de captura/directo.
- Se verifica `get-state == device` antes de cambiar el destino. Una autorización pendiente o un fallo de conexión conserva la selección previa. Si falla el guardado se restaura el destino en memoria.
- Las llamadas programáticas ADB usan stdin cerrado para no consumir entradas del menú.
- Prueba real desde la opción 15: se eligió la fila del TV-box con MAC 2C:73:60:F1:78:D0, puerto 3222, y se guardó la conexión IPv6. La opción 2 confirmó estado device y modelo AndroidTV.
- Una ejecución independiente de `tvbox.py --json status`, sin override de dispositivo, confirmó la reutilización del destino IPv6 guardado. `adb devices -l` lista la misma conexión activa.
- 100 pruebas aprobadas; paquete ZIP extraído y verificado. Se conservaron las versiones anteriores.
- No se hicieron nuevas capturas, grabaciones ni directos de hardware durante esta actualización. El inventario de estado/propiedades fue de lectura.
- La opción 13 mantiene su alcance IPv4 y ahora explica esa limitación si el destino guardado es IPv6; para revisar servicios IPv6 se usa 16.


## Shell interactiva completada — versión 1.11.0

- Nueva opción 18 y comando `iniciar.sh shell`: abren una shell ADB interactiva usando el destino seleccionado.
- Se verifica la conexión antes de abrir; entrada y salida se heredan de la terminal y ADB solicita una PTY remota. No se utiliza el ejecutor no interactivo que cierra stdin.
- `exit` y Ctrl+D regresan al menú. Ctrl+C se maneja normalmente en el comando remoto. Si la interrupción es local, se cierra solo el cliente creado por esta sesión, con espera acotada, y se restaura la terminal.
- La shell no admite --json ni flujos redirigidos. El código de salida se conserva por CLI y el menú permite volver a abrirla.
- La herramienta no captura el contenido interactivo en su registro y conserva la selección del dispositivo.
- Prueba real sobre el TV-box por IPv6: prompt AndroidTV:/ $, `pwd` devolvió /, Ctrl+C mantuvo la sesión y exit regresó al menú. Otra sesión terminó con Ctrl+D y código 0; después se cerró el menú con 0.
- 109 pruebas aprobadas y paquete ZIP validado. Las comprobaciones remotas fueron el comando de lectura pwd y los controles de la sesión.


## Privilegios elevados por solicitud del usuario — 2026-11-10 23:26

- La sesión inicial era uid=2000(shell). Se ejecutó el comando nativo `adb root`, que respondió `restarting adbd as root`.
- Tras reconectar, una nueva ejecución de `adb shell id` confirmó uid=0(root), gid=0(root), contexto u:r:su:s0. `service.adb.root=1`; SELinux continúa Permissive.
- Las nuevas shells abiertas con la opción 18 usan el adbd elevado. Una shell anterior puede haberse desconectado durante el reinicio; volver a abrir 18 y comprobar con id.
- El cambio corresponde al servicio ADB activo; no se asume persistencia tras reiniciar el TV-box. Para devolver adbd al usuario normal se puede utilizar el comando nativo adb unroot sobre el mismo destino.
- La elevación también afecta a las nuevas conexiones al servicio ADB de red, que ya había aceptado el saludo sin autenticación en las comprobaciones anteriores.
- Evidencia privada: `salidas/root-adb-20261110-232645.json`. El código del script se conserva en la versión 1.11.0.


## Imagen o logo en pantalla — versión 1.12.0

- Nueva opción 19 y comando `show-image ARCHIVO`: elegir una imagen de la computadora, copiarla al TV-box y abrirla en un visor instalado.
- PNG/JPEG/GIF/WebP, máximo 25 MiB. Se genera un nombre remoto seguro en /sdcard/Pictures/TVBoxTools; no se interpola el nombre local en comandos remotos. Se conserva la selección ADB y se permite elegir visor.
- El archivo copiado permanece en la carpeta de imágenes. Atrás o Inicio en el mando permite salir del visor. Si falla la operación se intenta limpiar únicamente su copia generada.
- Prueba real con PNG de barras multicolor de 1280x720. Android confirmó la apertura de la Galería y el usuario confirmó ver la imagen en su televisor. No se tomó una nueva captura de pantalla para esta verificación.
- Archivos de prueba: salidas/prueba-imagen-20261110-234011.png y salidas/prueba-imagen-resultado.json. La imagen de colores es una prueba; el usuario puede elegir su propio logo por la opción 19.
- 116 pruebas aprobadas y paquete ZIP validado. Se conservaron los paquetes anteriores.


## Retirar imagen de pantalla — versión 1.13.0

- Nueva opción 20 y comando hide-image. Identifican la imagen administrada en primer plano por su ActivityRecord y URI generada; no dependen de memoria de la sesión anterior del script.
- Envía Atrás y verifica el cambio. Si sigue activa una imagen administrada, utiliza Inicio. Si el primer plano es ajeno o no puede identificarse, no navega esa pantalla.
- Se conserva la copia remota y la selección ADB. No se fuerza el cierre de la aplicación ni se eliminan archivos.
- Prueba real: la imagen multicolor dejó de estar en primer plano usando Atrás; resultado hidden/back. La copia sigue disponible en Pictures/TVBoxTools para volver a mostrarla.
- 122 pruebas aprobadas y paquete ZIP validado. La detección depende del formato de dumpsys del firmware; ante ambigüedad informa la situación.


## Nombre, firma y estética — Dogo_Box_Tv 1.14.0

- Nombre visible y lanzador Dogo_Box_Tv.py; firma Dogo en encabezado y reportes. La identidad/versionado se centraliza en branding.py.
- Menú con monitor de texto, tema dogo cian/verde, paneles por función y dos columnas a partir de 78 columnas de terminal. Conserva números y funciones 0–20.
- Se ajustan textos y paneles a terminales angostas; colores y temas se personalizan con 12. Se respetan preferencias guardadas, NO_COLOR y --color never.
- Nombre y autor en los nuevos reportes y metadatos. Se conserva JSON sin elementos de decoración y los archivos históricos no se reescriben.
- Acceso /home/dogo/Dogo_Box_Tv enlaza a la carpeta existente /home/dogo/tvbox-tools. El lanzador iniciar.sh usa Dogo_Box_Tv.py y la configuración/salidas siguen en el mismo proyecto.
- 122 pruebas existentes aprobadas. Renderizado validado a 20/36/60/80/100 columnas y revisión real en PTY del menú coloreado.
- Archivo Dogo_Box_Tv-v1.14.0.zip validado; incluye el lanzador y branding.py, con configuración de ejemplo sin el dispositivo privado guardado. Las versiones anteriores se conservan.


## 2026-11-11 — Cuadros adaptables y shell enmarcada, versión 1.15.0

- Todos los resultados, avisos, errores, progresos y listas de las acciones se presentan en paneles. Se ajustan al ancho actual de la terminal y continúan las rutas/IPv6 largas dentro del marco. En terminales angostas, los equipos aparecen con número, IP y datos debajo.
- Las preguntas utilizan cuadros editables con desplazamiento horizontal del campo. Enter acepta, Ctrl+C cancela y Ctrl+D en vacío cierra. Se conservan números de acciones, selección y preferencias de colores.
- Opción 18: shell ADB real dentro de un marco personalizado con firma Dogo, mediante PTY de tmux. Adapta el marco al cambiar el tamaño de la terminal. La sesión tmux es privada, temporal y separada de las del usuario. No se registra el contenido de la shell. Se conserva el código de salida remoto; una sesión incompleta no se presenta como salida correcta.
- Dependencias de la interfaz: tmux con display-popup y prompt_toolkit. Ya disponibles en esta PC y añadidas al diagnóstico de la opción 6. JSON y comandos no interactivos conservan su funcionamiento sin esas dependencias.
- Validación: suite completa de 131 pruebas aprobadas y 9 pruebas del módulo de terminal aprobadas tras reforzar la limpieza. Menú y resultados verificados entre 6 y 100 columnas; entradas PTY de 200 caracteres en 36/48 columnas; shell PTY redimensionada de 80 a 48 con entrada funcional y salida 7 conservada.
- Validación real del TV-box: estado ADB, apertura por opción 18, pwd, impresión larga, Ctrl+C sobre sleep y Ctrl+D de regreso al menú, conservando el estado 130 del comando interrumpido. No se cambiaron el destino guardado ni la configuración de red.
- Paquete creado y comprobado: `/home/dogo/Dogo_Box_Tv-v1.15.0.zip`, raíz `Dogo_Box_Tv/`. Extraído temporalmente: versión, ayuda, JSON IPv6 y configuración de ejemplo sin destino comprobados. SHA-256: `aaae9d7effe3f870272dfb66f4dec292179e4d6adb6d87c50ad6f27463672204`. No contiene la configuración privada, registros ni salidas del usuario.


## 2026-11-11 01:50:20 CST — Documentación final y preparación del apagado

- Solicitud del propietario: documentar todo y apagar la PC al terminar.
- Se añadió RETOMAR.md con inicio tras reiniciar, conexión guardada, tabla completa de opciones 0–20, arquitectura, archivos, dependencias, pruebas, límites y preferencia de no utilizar Nmap. README enlaza la guía y el historial.
- Paquete original 1.15.0 validado por CRC y SHA-256; coincide con aaae9d7effe3f870272dfb66f4dec292179e4d6adb6d87c50ad6f27463672204.
- No hay registros de directos y no se observaron procesos de shell o directo de la herramienta activos. No se volvió a conectar al TV-box para este cierre. Se conserva la configuración real y las salidas.
- El sistema informa autorización disponible para apagado normal. Se programará después de guardar y verificar la documentación.
- Documentación respaldada en `/home/dogo/Dogo_Box_Tv-documentacion-20261111.zip`; SHA-256: `8e6326acbdaf6b95fd67b5478104020f5449a1e3315f79f01d640b1938234e9d`. El ZIP de código 1.15.0 original se conserva sin cambios. El archivo AVANCE local incorporará también el resultado de programar el apagado.
- Apagado normal aceptado por el sistema para **2026-11-11 01:51:43 CST** (`poweroff`), después de guardar y sincronizar la documentación y los respaldos. Puede cancelarse antes de esa hora con `shutdown -c`.


## 2026-11-11 09:43:07 CST — Preparación de acceso remoto por Internet

- Nueva solicitud: conectarse al TV-box desde fuera de la red local.
- Diagnóstico de solo lectura: ADB funciona y ya escucha TCP 3222; API 28, ARM de 32 bits, Android TV/Leanback y Play Store presentes. No hay Tailscale/WireGuard instalado. La shell actual es uid 2000, sin root en esta conexión.
- Se creó ACCESO_REMOTO.md con el estado real, fuentes oficiales, pasos de instalación/registro y validación externa pendientes. No hay acceso externo configurado todavía; no se modificaron router, firewall, privilegios ni destino guardado.
- Se solicitó elegir Tailscale u otra infraestructura existente. La autenticación del usuario en la VPN es un paso pendiente.


## 2026-11-11 13:39:48 CST — TV-box como servidor propio

- El propietario precisó que la TV-box debe alojar los servicios, como un servidor doméstico accesible desde Internet.
- Recursos leídos: ARMv7/32 bits, 1 GiB de RAM y 346 MB libres en /data; no hay Termux ni sshd/dropbear en PATH. Se propone comenzar con SSH y servicios ligeros, sin otra instalación todavía.
- Consulta UPnP de solo lectura al router: WAN 192.168.9.102, privada. Hay una capa previa; no se puede afirmar CGNAT sin revisar el módem/proveedor. IPv6 global no observada en TV-box.
- No se modificaron puertos, router, aplicaciones ni privilegios. Evidencia: /home/dogo/tvbox-tools/salidas/diagnostico-servidor-tvbox-20261111-133948.json. Detalles y siguiente dato necesario en ACCESO_REMOTO.md.


## 2026-11-11 13:46:58 CST — Dirección estable para acceso remoto

- Requisito nuevo: el enlace remoto debe permanecer fijo. Se registró en ACCESO_REMOTO.md.
- El propietario solo administra el router actual. La capa previa podría ser del proveedor, sin confirmación de CGNAT.
- Se verificó en documentación oficial que una identidad onion persistente y respaldada permite conservar la dirección a pesar de reinicios o cambios de IP. No se creó ni instaló el servicio todavía; la disponibilidad requerirá TV-box encendida y conectividad Tor.


## 2026-11-11 14:21:35 CST — Portabilidad a Termux y terminales Android, versión 1.16.0

- Solicitud: poder usar Dogo_Box_Tv desde Termux y derivaciones Android compatibles.
- Nuevo tvbox_runtime.py: detección de Python Android/Termux y otros PREFIX, rutas privadas de configuración/salidas/temporales, shell desde PATH y capacidades del entorno. La PC conserva su configuración anterior. TVBOX_CONFIG, --config y --output-dir permiten elegir las rutas.
- Nuevo instalar-termux.sh: usa pkg para Python, python-pip, python-ensurepip-wheels, android-tools, tmux, iproute2 e iputils, e instala requirements.txt en .venv. No actualiza pip del sistema, no instala Nmap ni modifica destinos. Incluye --comprobar y rechaza ejecutarse como root o desde almacenamiento compartido. El lanzador prefiere el entorno Python del proyecto y admite TVBOX_PYTHON.
- Descubrimiento IPv4 por TCP sin sockets raw ni vecinos: subred explícita de hasta 1024 direcciones, máximo 16 puertos por dirección, verificación previa de que la IP de salida pertenece a esa subred. Sin suponer máscara /24 ni atribuir MAC/fabricante. La opción 10 ofrece este método cuando Android restringe la enumeración; errores locales quedan como resultado parcial.
- IPv6 conserva respuestas multicast si Android solo impide leer vecinos. Si no se pueden enumerar interfaces, se informa de la alternativa de pegar una dirección conocida en 11/17. Los controles de permisos de la aplicación Android siguen aplicándose.
- Guardado sin sobrescritura compatible con FUSE/almacenamiento sin enlaces duros mediante copia con creación exclusiva y limpieza de parciales. La copia de reserva no promete publicación atómica a lectores concurrentes.
- Shell delimitada sin /bin/sh fijo. Una sesión privada mantiene la PTY ADB y otra ventana ajusta el marco al ampliar o reducir; conserva estado y código de salida. El cierre elimina solo su servidor privado. Si falta el editor de entrada, el menú termina con un error de instalación accionable, sin bucle de reintentos.
- Directo Android con diagnóstico de entorno gráfico: requiere scrcpy y X11/entorno compatible configurado. Capturas y MP4 siguen siendo operaciones sin ventana gráfica en el cliente.
- TERMUX.md documenta instalación desde ZIP, ejecución manual en otros intérpretes, Wi-Fi/ADB y emparejamiento, permisos, rutas, límites de descubrimiento, capacidades por función y fuentes oficiales. README y RETOMAR enlazan la guía.
- Validación: 156 pruebas aprobadas (131 existentes, 24 de portabilidad y una PTY real local). El instalador se probó con pkg simulado; se comprobó una entrada de 200 caracteres en 36 columnas y la shell local a 36→48→32 columnas preservando estado y salida 7.
- Prueba real adicional desde la PC contra el TV-box/IPv6: shell uid 2000, entrada tras cambio de tamaño, Ctrl+C y salida normal. No se instalaron aplicaciones ni se cambiaron permisos, privilegios o configuración en el TV-box.
- Prueba local TCP de la subred acotada 192.168.0.96/28, puerto 3222: únicamente se observó la IP local. No se atribuyó detección del TV-box por IPv4 ni ausencia de equipos a la falta de respuesta.
- Alcance pendiente: esta versión no se ha ejecutado dentro de Termux real; no se garantiza cualquier firmware o aplicación Android. La dirección remota fija solicitada sigue pendiente de configurar; no se creó una dirección onion ni se abrió acceso externo.
- Entrega: `/home/dogo/Dogo_Box_Tv-v1.16.0.zip`, raíz Dogo_Box_Tv/. CRC, sintaxis Python 3.10, versión/ayuda, configuración de ejemplo y JSON en HOME/PREFIX Android simulado correctos. Incluye guías y fuentes, sin configuración privada, salidas, sesiones reales ni .venv. SHA-256: `dc43c5cbbf676e52c273bbfffc1688dbd8153126f7be521c815fda84666126a4`. Se conservan los paquetes anteriores.


## 2026-11-11 16:54:17 CST — Corrección de instalación Termux, versión 1.16.1

- Fallo comunicado por el propietario en Termux real: el paquete iputils de la lista inicial no se encuentra. Se incluyó por error; las pruebas con pkg simulado anteriores no verificaban la existencia de cada paquete contra los repositorios reales.
- Retirado del lote obligatorio. Detección de ping en PATH y /system/bin/ping; descubrimiento IPv4 con alternativa TCP después de verificar la subred cuando no existe ping. No se requiere ICMP para conectar ADB o consultar puertos TCP.
- Prueba del instalador reforzada para rechazar iputils expresamente y tres nuevas pruebas de ping/fallback. Resultado: 159 pruebas aprobadas. Se verificó que inetutils desactiva ping/ping6, por lo que no se añadió como falso sustituto.
- Reparación para la copia del usuario: desde la carpeta del proyecto, sed -i 's/ iputils//g' instalar-termux.sh y bash instalar-termux.sh. TERMUX.md explica el alcance y la actualización completa.
- Todavía pendiente verificar el instalador corregido dentro del Termux real del usuario; no se accedió al teléfono ni se modificó la TV-box.
- ZIP 1.16.1 verificado (CRC, sintaxis Python 3.10, configuración de ejemplo, instalador sin iputils, versión y JSON con HOME Android simulado). Paquete: `/home/dogo/Dogo_Box_Tv-v1.16.1.zip`; SHA-256 `3d55c6bc8dd02b28cc3aaae6491b774e5b20edd84e158b2d08ea678d8b158b30`. Se conserva el ZIP anterior.


## 2026-11-11 17:43:22 CST — Reparación directa por ADB de Termux, versión 1.16.2

- El propietario autorizó controlar su Android por ADB para resolver el error de prompt_toolkit. Se identificó su teléfono USB, distinto del AndroidTV de red. Termux 0.118.3 permite run-as; no se utilizó root.
- Proyecto real: $HOME/Tv_Box_auditoria/Dogo_Box_Tv. Entorno .venv existente sin pip ni editor; Python 3.14.10 y libexpat 2.8.4 eran incompatibles. Se actualizó libexpat a 2.10.0 y se instalaron pip 26.2.2, prompt_toolkit 3.0.53 y wcwidth 0.9.4 dentro de .venv.
- Menú y editor observados en pantalla real. La suite real detectó os.link ausente en ese Python; se corrigió la copia exclusiva y se adaptó la prueba PTY a secuencias ANSI intercaladas. Resultado corregido: 163 pruebas ejecutadas, OK con 7 omitidas de Linux de escritorio.
- El diagnóstico también detectó protobuf antiguo impidiendo cargar ADB. Se actualiza esa dependencia concreta; el instalador ahora valida adb version y las importaciones del editor antes del éxito.
- Nuevo total de regresión Linux: 165 pruebas aprobadas, incluidas seis nuevas para los fallos reales de esta reparación.
- Archivos modificados respaldados en la carpeta .respaldo-soporte-20261111-173655 del proyecto del teléfono y en salidas/soporte-termux/20261111-173655/originales en la PC. Configuración y salidas conservadas.
- Se mantiene pendiente la dirección remota fija; esta reparación no crea un servicio onion ni publica el puerto ADB.
- Resultado final real de la reparación: libprotobuf 2:36.2-1 y las siete dependencias nativas antiguas de android-tools sincronizadas desde paquetes cuyos SHA-256 coinciden con el índice APT autenticado. ADB 37.0.0p1 carga correctamente. No se actualizaron los restantes paquetes ajenos a la reparación.
- Instalador corregido completado en el teléfono con salida 0. Doctor JSON sin error de ADB y editor disponible. Suite final real: 165 pruebas, OK con 7 omitidas de Linux de escritorio. Captura privada del menú 1.16.2 y entrada de opción 6 verificadas. Registros: salidas/soporte-termux/resumen-reparacion-1.16.2.json y verificacion-final-1.16.2.txt.
- El teléfono queda en el menú, con el destino aún sin seleccionar; no se configuró acceso externo ni un servicio onion.
- Entrega 1.16.2: `/home/dogo/Dogo_Box_Tv-v1.16.2.zip`, CRC/sintaxis Python 3.10/versión y JSON con HOME Android simulado verificados. SHA-256: `70323e85b8036a92b36af867006d4a8a246d066cf4ddf30d4563fc4db88bbbb7`. El teléfono ya tiene el código actualizado; no necesita volver a descargarlo.
