"""Visual image selection: desktop dialog or a one-shot local Android gallery UI."""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import threading
import uuid

import tvbox_runtime as runtime

LIMIT = 25 * 1024 * 1024


class PickerError(Exception):
    pass


@dataclass
class Selection:
    path: str | None
    automatic_viewer: bool = False


PAGE = '''<!doctype html><html lang="es"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dogo_Box_Tv · Elegir imagen</title>
<style>
:root{color-scheme:dark;font:17px system-ui;background:#081319;color:#e7f5fa}
body{margin:0;padding:16px 12px}main{max-width:520px;margin:1vh auto;border:1px solid #26b7ca;border-radius:20px;padding:18px;background:#102129}
h1{font-size:1.5rem;margin:8px 0}small{color:#74d1d9}p{line-height:1.55;color:#bfd4dc}
button{width:100%;border:0;border-radius:12px;padding:16px;margin:8px 0;font:inherit;font-weight:650;background:#26c5ce;color:#062329}
button.secondary{background:#263f49;color:#e7f5fa}button:disabled{opacity:.5}img{display:block;max-width:100%;max-height:26vh;margin:18px auto;border-radius:12px}[hidden]{display:none!important}#status{min-height:3em} .error{color:#ffaaa5!important}
</style><main><small>DOGO_BOX_TV · FIRMA: DOGO</small><h1>Enviar una imagen al TV</h1>
<p>Elige una imagen, revisa la vista previa y confirma el envío.</p>
<input id="file" type="file" accept="image/png,image/jpeg,image/gif,image/webp" hidden>
<button id="choose">Elegir imagen</button>
<img id="preview" alt="Vista previa de la imagen elegida" hidden><p id="filename"></p>
<button id="send" disabled>Enviar al TV</button><button id="cancel" class="secondary">Cancelar</button><p id="status" role="status">PNG, JPEG, GIF o WebP · Hasta 25 MiB.</p>
<small>La imagen original se conserva.</small></main>
<script nonce="NONCE">
const input=document.querySelector('#file'),choose=document.querySelector('#choose'),send=document.querySelector('#send'),cancel=document.querySelector('#cancel'),status=document.querySelector('#status'),preview=document.querySelector('#preview'),filename=document.querySelector('#filename');
let busy=false,previewUrl,selectedFile;
choose.onclick=()=>input.click();
async function stop(){if(busy)return;busy=true;choose.disabled=send.disabled=cancel.disabled=true;try{await fetch('cancel',{method:'POST'});}catch(e){}status.textContent='Selección cancelada. Puedes volver a Termux.';}
cancel.onclick=stop;input.addEventListener('cancel',()=>{if(!selectedFile)stop();});
input.addEventListener('change',()=>{
const file=input.files[0];if(!file)return;
if(file.size===0||file.size>26214400){selectedFile=null;send.disabled=true;preview.hidden=true;status.className='error';status.textContent='Elige una imagen de hasta 25 MiB.';input.value='';return;}
selectedFile=file;if(previewUrl)URL.revokeObjectURL(previewUrl);previewUrl=URL.createObjectURL(file);preview.src=previewUrl;preview.hidden=false;filename.textContent=file.name;send.disabled=false;status.className='';status.textContent='Revisa la imagen y pulsa Enviar al TV.';
});
send.onclick=async()=>{
if(!selectedFile||busy)return;
busy=true;choose.disabled=send.disabled=cancel.disabled=true;status.className='';status.textContent='Enviando imagen al TV box…';
try{const response=await fetch('image',{method:'POST',body:selectedFile});const result=await response.json();status.textContent=result.message;if(!result.ok)status.className='error';}
catch(e){status.className='error';status.textContent='No se pudo confirmar el envío. Vuelve a Termux para revisar el resultado.';}
};
</script></html>'''


class Gallery:
    """Only a random local URL can submit one selected file; no gallery enumeration."""
    def __init__(self, directory, timeout=300):
        self.path = Path(directory)/"seleccion.imagen"
        self.timeout = timeout
        self.prefix = "/" + uuid.uuid4().hex + "/"
        self.ready, self.done, self.replied = threading.Event(), threading.Event(), threading.Event()
        self.lock = threading.Lock()
        self.selected = False
        self.result = {"ok": False, "message": "Selección cancelada. Puedes volver a Termux."}
        gallery = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def reply(self, code, body, mime="application/json; charset=utf-8"):
                try:
                    self.send_response(code)
                    self.send_header("Content-Type", mime)
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.send_header("Referrer-Policy", "no-referrer")
                    self.send_header("Content-Security-Policy", "default-src 'none'; script-src 'nonce-" + gallery.nonce + "'; style-src 'unsafe-inline'; img-src blob:; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
                    self.end_headers()
                    self.wfile.write(body)
                    self.wfile.flush()
                except (ConnectionError, OSError):
                    self.close_connection = True

            def valid(self, post=False):
                if self.headers.get("Host") != gallery.host or (post and self.headers.get("Origin") != gallery.origin):
                    self.close_connection = True
                    self.reply(403, b'{}')
                    return False
                return True

            def do_GET(self):
                if not self.valid():return
                if self.path != gallery.prefix:
                    self.reply(404, b'{}');return
                self.reply(200, PAGE.replace("NONCE", gallery.nonce).encode(), "text/html; charset=utf-8")

            def do_POST(self):
                if not self.valid(post=True):return
                if self.path not in (gallery.prefix+"image", gallery.prefix+"cancel"):
                    self.reply(404, b'{}');return
                if gallery.ready.is_set() or not gallery.lock.acquire(blocking=False):
                    self.reply(409, b'{}');return
                try:
                    if self.path.endswith("cancel"):
                        gallery.ready.set()
                        self.reply(200, json.dumps(gallery.result).encode())
                        gallery.replied.set()
                        return
                    try:
                        length = int(self.headers.get("Content-Length", "-1"))
                    except ValueError:
                        length = -1
                    if not 0 < length <= LIMIT or self.headers.get("Transfer-Encoding"):
                        self.close_connection = True
                        self.reply(413, b'{"ok":false,"message":"Elige una imagen de hasta 25 MiB."}')
                        return
                    self.connection.settimeout(15)
                    try:
                        with gallery.path.open("xb") as target:
                            gallery.path.chmod(0o600)
                            while length:
                                block = self.rfile.read(min(65536, length))
                                if not block:raise OSError("Imagen incompleta")
                                target.write(block);length -= len(block)
                    except OSError:
                        gallery.path.unlink(missing_ok=True)
                        self.close_connection = True
                        self.reply(400, b'{"ok":false,"message":"La imagen no se transfirio completa. Vuelve a intentarlo."}')
                        return
                    gallery.selected = True
                    gallery.ready.set()
                    gallery.done.wait(90)
                    if not gallery.done.is_set():
                        result = {"ok": False, "message": "El envío sigue pendiente. Revisa el resultado en Termux."}
                    else:
                        result = gallery.result
                    try:
                        self.reply(200 if result["ok"] else 400, json.dumps(result, ensure_ascii=False).encode())
                    finally:
                        gallery.replied.set()
                finally:
                    gallery.lock.release()
        self.nonce = uuid.uuid4().hex
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        self.host = f"127.0.0.1:{self.server.server_port}"
        self.origin = "http://" + self.host
        self.url = self.origin + self.prefix
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.done.set()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)


def open_android(url):
    launcher = shutil.which("am")
    if not launcher:
        raise PickerError("No se encontró el lanzador Android. Puedes usar la entrada manual de ruta.")
    command = [launcher, "start", "--user", str(os.getuid()//100000), "-a", "android.intent.action.VIEW", "-d", url]
    try:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True, timeout=12)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise PickerError("No se pudo abrir el selector de imágenes. Usa la entrada manual de ruta.") from error
    if result.returncode or b"Error:" in result.stdout + result.stderr:
        raise PickerError("Android no pudo abrir el navegador para elegir la imagen. Usa la entrada manual de ruta.")


def return_to_terminal():
    prefix = os.environ.get("PREFIX", "")
    match = re.fullmatch(r"/data/(?:data|user/\d+)/([A-Za-z0-9_.]+)/files/usr/?", prefix)
    launcher = shutil.which("am")
    if not match or not launcher:return
    try:
        subprocess.run([launcher, "start", "--user", str(os.getuid()//100000), "-a", "android.intent.action.MAIN",
                        "-c", "android.intent.category.LAUNCHER", "-p", match[1]],
                       stdin=subprocess.DEVNULL, capture_output=True, timeout=8)
    except (OSError, subprocess.TimeoutExpired):
        pass


def desktop_file(timeout):
    if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or os.name == "nt"):
        raise PickerError("No hay un escritorio gráfico disponible. Puedes usar la entrada manual de ruta.")
    zenity, kdialog = shutil.which("zenity"), shutil.which("kdialog")
    if zenity:
        command = [zenity, "--file-selection", "--title=Dogo_Box_Tv · Elegir imagen", "--file-filter=Imágenes | *.png *.jpg *.jpeg *.gif *.webp *.PNG *.JPG *.JPEG *.GIF *.WEBP"]
    elif kdialog:
        command = [kdialog, "--getopenfilename", str(Path.home()), "Imágenes (*.png *.jpg *.jpeg *.gif *.webp)", "--title", "Dogo_Box_Tv · Elegir imagen"]
    else:
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk();root.withdraw()
            try:
                return filedialog.askopenfilename(title="Dogo_Box_Tv · Elegir imagen", filetypes=[("Imágenes", "*.png *.jpg *.jpeg *.gif *.webp")]) or None
            finally:
                root.destroy()
        except Exception as error:
            raise PickerError("No hay un selector gráfico disponible. Usa la entrada manual de ruta.") from error
    try:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise PickerError("El selector de imágenes no respondió. Puedes reintentar o usar la ruta manual.") from error
    if result.returncode in (1, 255):return None
    if result.returncode:
        raise PickerError("No se pudo abrir el selector de imágenes. Puedes usar la ruta manual.")
    return result.stdout.rstrip("\r\n") or None


@contextmanager
def select_image(timeout=300):
    if not runtime.android_host():
        yield Selection(desktop_file(timeout))
        return
    runtime.prepare_environment()
    with tempfile.TemporaryDirectory(prefix="dogo-imagen-", dir=os.environ["TMPDIR"]) as directory:
        with Gallery(directory, timeout) as gallery:
            open_android(gallery.url)
            try:
                if not gallery.ready.wait(timeout):
                    raise PickerError("No se eligió una imagen dentro de cinco minutos. Vuelve al menú e inténtalo otra vez.")
                try:
                    yield Selection(str(gallery.path) if gallery.selected else None, automatic_viewer=True)
                except BaseException as error:
                    gallery.result = {"ok": False, "message": str(error) if isinstance(error, Exception) else "Envío cancelado. Vuelve a Termux."}
                    raise
                else:
                    if gallery.selected:
                        gallery.result = {"ok": True, "message": "Imagen enviada al TV box. Puedes volver a Termux."}
            finally:
                gallery.done.set()
                if gallery.selected:gallery.replied.wait(2)
                return_to_terminal()
