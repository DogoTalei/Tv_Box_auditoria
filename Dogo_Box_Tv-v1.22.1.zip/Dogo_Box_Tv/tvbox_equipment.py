"""Named devices, video preferences and identity-checked bounded reconnection."""
from __future__ import annotations

import copy
import ipaddress
import json
import re
import shutil
import uuid

from tvbox import ToolError, PROFILES, load_config, temporary_for, publish, now, normalize_adb_address
from tvbox_video import settings


def commit(app, config):
    """Every new configuration action preserves the previous file privately."""
    backup = None
    if app.config_path.exists():
        folder = app.config_path.parent / "backups-config"
        folder.mkdir(parents=True, exist_ok=True, mode=0o700)
        backup = folder / (uuid.uuid4().hex + ".json")
        with app.config_path.open("rb") as source, backup.open("xb") as target:
            backup.chmod(0o600)
            shutil.copyfileobj(source, target)
    temporary = temporary_for(app.config_path)
    try:
        temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        publish(temporary, app.config_path, True)
    finally:
        temporary.unlink(missing_ok=True)
    app.config = config
    return str(backup) if backup else None


def profiles(app):
    data = app.config.get("equipment_profiles", [])
    if not isinstance(data, list) or len(data) > 100:
        raise ToolError("equipment_profiles debe ser una lista de hasta 100 equipos.")
    ids, names = set(), set()
    for item in data:
        if (not isinstance(item, dict) or not isinstance(item.get("name"), str)
                or not 1 <= len(item["name"]) <= 60 or re.search(r"[\x00-\x1f\x7f]", item["name"])
                or not re.fullmatch(r"[a-f0-9]{32}", str(item.get("id", "")))
                or not isinstance(item.get("endpoints"), list) or not 1 <= len(item["endpoints"]) <= 8):
            raise ToolError("Perfil de equipo inválido.")
        for endpoint in item["endpoints"]:
            valid_endpoint(endpoint)
        identity = item.get("identity")
        if identity is not None and (not isinstance(identity, dict) or not isinstance(identity.get("serial"), str)
                                      or not identity["serial"] or len(identity["serial"]) > 256):
            raise ToolError("Identidad guardada inválida.")
        if item["id"] in ids or item["name"].casefold() in names:
            raise ToolError("Hay nombres o identificadores de equipos duplicados.")
        ids.add(item["id"]); names.add(item["name"].casefold())
    return copy.deepcopy(data)


def valid_endpoint(value):
    if not isinstance(value, str) or not value or len(value) > 256 or value.startswith("-") or re.search(r"[\s\x00-\x1f\x7f]", value):
        raise ToolError("Identificador ADB inválido.")
    if value.startswith("["):
        match = re.fullmatch(r"\[([^\]]+)\]:([0-9]{1,5})", value)
        if not match or not 1 <= int(match[2]) <= 65535:
            raise ToolError("Dirección ADB IPv6 inválida.")
        base, _, zone = match[1].partition("%")
        try:
            address = ipaddress.IPv6Address(base)
        except ValueError as error:
            raise ToolError("Dirección ADB IPv6 inválida.") from error
        if address.is_unspecified or address.is_multicast or (address.is_link_local and not zone) or (zone and not re.fullmatch(r"[A-Za-z0-9_.-]{1,32}", zone)):
            raise ToolError("IPv6 o ámbito de interfaz inválidos.")
        return f"[{address}" + ("%" + zone if zone else "") + f"]:{int(match[2])}"
    if ":" in value:
        return normalize_adb_address(value)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", value):
        raise ToolError("Identificador USB inválido.")
    return value


def find(app, name):
    matches = [item for item in profiles(app) if name == item["id"] or name.casefold() == item["name"].casefold()]
    if len(matches) != 1:
        raise ToolError("Elige un equipo guardado por nombre o identificador; usa equipment list.")
    return matches[0]


def identity(app):
    result = app.run_adb(["shell", "getprop ro.serialno; getprop ro.boot.serialno; getprop ro.product.model"], timeout=8)
    lines = result.stdout.decode(errors="replace").splitlines()
    serial = next((value.strip() for value in lines[:2] if value.strip()), "")
    if not serial or serial.lower() == "unknown":
        raise ToolError("El equipo no proporciona número de serie; no se puede verificar su identidad para reconectar.")
    return {"serial": serial[:256], "model": lines[2].strip()[:256] if len(lines) > 2 else ""}


def verified(app, profile, observed=None):
    expected = profile.get("identity")
    if expected and (observed or identity(app))["serial"] != expected["serial"]:
        raise ToolError("La identidad ADB es distinta del equipo guardado. No se seleccionó ese destino.")


def save(app, name, offline=False, overwrite=False):
    name = name.strip()
    if not 1 <= len(name) <= 60 or re.search(r"[\x00-\x1f\x7f]", name):
        raise ToolError("El nombre debe tener entre 1 y 60 caracteres visibles.")
    if not app.device:
        raise ToolError("Selecciona primero el equipo con 17 o select.")
    endpoint = valid_endpoint(app.device)
    data = profiles(app)
    old = next((x for x in data if x["name"].casefold() == name.casefold()), None)
    if old and not overwrite:
        raise ToolError("Ya existe ese nombre. Usa --overwrite para sustituirlo.")
    if not old and len(data) >= 100:
        raise ToolError("Se alcanzó el límite de 100 equipos guardados.")
    if not offline:
        app.ensure_device()
    observed = identity(app) if not offline else None
    item = {"id": old["id"] if old else uuid.uuid4().hex, "name": name, "endpoints": [endpoint],
            "identity": observed, "mac": (app.config.get("selected_target") or {}).get("mac"),
            "stream_settings": quality(app), "saved_at": now()}
    data = [x for x in data if x["id"] != item["id"]] + [item]
    config = load_config(app.config_path)
    config.update(equipment_profiles=data, active_equipment=item["id"])
    backup = commit(app, config)
    return {"operation": "equipment-save", "equipment": item, "backup": backup}


def use(app, name):
    item = find(app, name)
    previous = app.device
    try:
        for index, endpoint in enumerate(item["endpoints"][:3]):
            try:
                if ":" in endpoint:
                    app.connect(endpoint, timeout=5)
                else:
                    app.device = endpoint
                    app.run_adb(["get-state"], timeout=5)
                observed = identity(app)
                verified(app, item, observed)
                break
            except ToolError as error:
                app.device = previous
                if ("autoriz" in str(error).lower() or "identidad" in str(error).lower()
                        or not item.get("identity") or index == min(len(item["endpoints"]), 3)-1):
                    raise
        item["identity"] = observed
        config = load_config(app.config_path)
        config.update(device=endpoint, active_equipment=item["id"])
        config["equipment_profiles"] = [item if x["id"] == item["id"] else x for x in profiles(app)]
        from tvbox import device_ip
        if ":" in endpoint:
            config["selected_target"] = {"ip": device_ip(endpoint), "port": int(endpoint.rsplit(":", 1)[1]),
                                         "mac": item.get("mac"), "selected_at": now()}
        else:
            config.pop("selected_target", None)
        commit(app, config)
    except BaseException:
        app.device = previous
        raise
    return {"operation": "equipment-use", "device": app.device, "name": item["name"], "identity": observed}


def add_endpoint(app, name, endpoint):
    item = find(app, name)
    if not item.get("identity"):
        raise ToolError("Conecta y guarda primero el equipo para verificar su identidad.")
    endpoint = valid_endpoint(endpoint)
    if endpoint in item["endpoints"]:
        return {"operation": "equipment-endpoint", "equipment": item, "changed": False}
    if len(item["endpoints"]) >= 8:
        raise ToolError("Cada equipo admite hasta ocho direcciones verificadas.")
    previous = app.device
    try:
        if ":" in endpoint:
            app.connect(endpoint, timeout=8)
        else:
            app.device = endpoint
            app.run_adb(["get-state"], timeout=8)
        verified(app, item)
    finally:
        app.device = previous
    item["endpoints"].append(endpoint)
    config = load_config(app.config_path)
    config["equipment_profiles"] = [item if x["id"] == item["id"] else x for x in profiles(app)]
    commit(app, config)
    return {"operation": "equipment-endpoint", "equipment": item, "changed": True}


def delete(app, name):
    item = find(app, name)
    config = load_config(app.config_path)
    config["equipment_profiles"] = [x for x in profiles(app) if x["id"] != item["id"]]
    if config.get("active_equipment") == item["id"]:
        config.pop("active_equipment", None)
    backup = commit(app, config)
    return {"operation": "equipment-delete", "name": item["name"], "backup": backup}


def active(app):
    key = app.config.get("active_equipment")
    if not key:
        return None
    item = find(app, key)
    return item if app.device in item["endpoints"] else None


def recover(app):
    item = active(app)
    if not item or not item.get("identity"):
        return False
    previous, errors = app.device, []
    for endpoint in item["endpoints"][:3]:
        try:
            if ":" in endpoint:
                app.connect(endpoint, timeout=5)
            else:
                app.device = endpoint
                app.run_adb(["get-state"], timeout=5)
            verified(app, item)
            if app.config.get("device") != endpoint:
                config = load_config(app.config_path)
                config["device"] = endpoint
                config.pop("selected_target", None)
                commit(app, config)
            app.note("Conexión recuperada con " + item["name"])
            return True
        except ToolError as error:
            app.device = previous
            if "autoriz" in str(error).lower() or "identidad" in str(error).lower():
                raise
            errors.append(str(error))
    raise ToolError("No se pudo recuperar el equipo guardado. Revisa Wi-Fi y ADB. " + errors[-1])


def quality(app):
    item = active(app)
    value = (item or {}).get("stream_settings") or app.config.get("stream_settings") or {"profile": app.config.get("stream_profile", "equilibrado")}
    try:
        return settings(value, PROFILES)
    except ValueError as error:
        raise ToolError(str(error)) from error


def set_quality(app, value):
    try:
        value = settings(value, PROFILES)
    except ValueError as error:
        raise ToolError(str(error)) from error
    config = load_config(app.config_path)
    item = active(app)
    if item:
        item["stream_settings"] = value
        config["equipment_profiles"] = [item if x["id"] == item["id"] else x for x in profiles(app)]
    else:
        config["stream_settings"] = value
    backup = commit(app, config)
    return {"operation": "stream-quality", "settings": value, "equipment": item["name"] if item else None, "backup": backup,
            "message": "Los ajustes se aplicarán al próximo directo."}
