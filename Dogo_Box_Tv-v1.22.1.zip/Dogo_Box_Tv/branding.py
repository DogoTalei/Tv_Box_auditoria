"""Identidad de la aplicación y firma del proyecto."""

APP_NAME = "Dogo_Box_Tv"
AUTHOR = "H4ckZone_by_Dogo"
VERSION = "1.22.1"
SIGNATURE = f"Firma: {AUTHOR}"
