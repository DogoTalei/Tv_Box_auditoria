# Dogo_Box_Tv en Termux y terminales Android

Firma: H4ckZone_by_Dogo. Versión: **1.22.1**.

El programa puede ejecutarse como cliente de control desde una terminal Android con **Python 3.10 o posterior, ADB nativo y las dependencias de interfaz**. La instalación automática está preparada para Termux y derivados que proporcionen `PREFIX` y `pkg`. Otros entornos necesitan instalar las herramientas equivalentes con su propio gestor. No basta cualquier aplicación que muestre una consola: las restricciones y los paquetes disponibles dependen de cada aplicación y firmware.

La base de Termux con soporte completo requiere Android 7 o posterior; consulta sus [fuentes oficiales de instalación](https://github.com/termux/termux-app#installation). Debe utilizarse una distribución mantenida y paquetes compilados para la arquitectura de ese entorno. El programa no necesita root en el teléfono que actúa como cliente.

## Instalar desde el ZIP

Descarga `Dogo_Box_Tv-v1.19.1.zip`. Si está en Descargas, concede a Termux acceso al almacenamiento cuando Android lo solicite:

```bash
termux-setup-storage
pkg install unzip
cd "$HOME"
unzip /sdcard/Download/Dogo_Box_Tv-v1.19.1.zip
cd Dogo_Box_Tv
bash instalar-termux.sh
bash iniciar.sh
```

Ejecuta el instalador como usuario normal de Termux, **sin `su` ni `sudo`**. Si ya tienes otra versión, extrae el ZIP en otra carpeta para no mezclar código viejo con código nuevo. La configuración privada de Android sigue disponible para ambas instalaciones mientras utilicen la misma ruta predeterminada.

El código debe estar dentro del almacenamiento privado de la terminal, por ejemplo `$HOME/Dogo_Box_Tv`. No ejecutes la instalación dentro de `/sdcard` o `/storage`: Android limita la ejecución, los enlaces y los permisos en el almacenamiento compartido. El instalador lo detecta y se detiene; no mueve ni elimina tus archivos.

`instalar-termux.sh` actualiza los índices del gestor y solicita estos paquetes:

```text
python python-pip libexpat libprotobuf python-ensurepip-wheels android-tools tmux iproute2
```

`python-ensurepip-wheels` proporciona las ruedas necesarias para crear el entorno aunque estén desactivados los paquetes recomendados del gestor. Después crea `.venv` dentro del proyecto e instala `requirements.txt` allí. No intenta actualizar el pip administrado por Termux, no instala Nmap y no reemplaza la configuración guardada. Si el gestor o la conexión fallan, el instalador termina con error en vez de anunciar una instalación completa.

Puedes revisar sus requisitos sin instalar nada:

```bash
bash instalar-termux.sh --comprobar
```

Comandos de inicio y diagnóstico:

```bash
bash iniciar.sh --version
bash iniciar.sh doctor
bash iniciar.sh --json doctor
bash iniciar.sh
```

El lanzador prefiere `.venv/bin/python`, después `python3` y después `python`. Puedes fijar otro intérprete mediante `TVBOX_PYTHON=/ruta/a/python`. Usa `bash iniciar.sh` en Android para evitar depender de que exista `/bin/sh` en ese sistema.

## Reparación de dependencias y entornos incompletos (1.16.2)

En el teléfono del propietario se reprodujo una instalación parcial: `.venv/bin/python` existía, pero pip y el editor no estaban instalados. Python tampoco podía cargar pyexpat por una versión antigua de libexpat; ADB tenía un problema análogo con protobuf.

El instalador ahora solicita explícitamente libexpat y libprotobuf, sincroniza las dependencias nativas que android-tools declara mediante apt-cache cuando está disponible, comprueba la carga de Python y `adb version`, repara pip dentro de un entorno existente y verifica la importación real del editor antes de mostrar «Instalación terminada». No añade paquetes sugeridos ni proveedores virtuales a esa sincronización. El diagnóstico muestra el ejecutable Python activo y si está dentro de un entorno virtual.

Si la interfaz no se carga, el error incluye el motivo original y la ruta exacta del instalador/lanzador correspondiente. No se presupone que hayas extraído el ZIP directamente en `$HOME/Dogo_Box_Tv`. En el teléfono reparado está en:

```bash
cd "$HOME/Tv_Box_auditoria/Dogo_Box_Tv"
bash iniciar.sh
```

Para reparar otra instalación, utiliza `bash instalar-termux.sh` **desde su propia carpeta**. No es necesario borrar la configuración, las capturas ni el proyecto. Se mantiene el gestor de paquetes de Termux y no se actualiza pip del sistema por fuera de ese gestor.

La versión también contempla intérpretes Android que no exponen `os.link`: utiliza creación exclusiva y copia, conservando la protección contra sobrescrituras.

## Corrección del paquete iputils (1.16.1)

La versión 1.16.0 incluía `iputils` por error en el instalador. El paquete no está en el repositorio actual de Termux y podía hacer que `pkg install` abortase todo el lote. La versión 1.16.1 lo elimina: ICMP no es una dependencia obligatoria para ADB ni para la búsqueda TCP.

Si ya tienes el ZIP 1.16.0 extraído, puedes desbloquear su instalador sin borrar configuración ni archivos:

```bash
cd "$HOME/Dogo_Box_Tv"
sed -i 's/ iputils//g' instalar-termux.sh
bash instalar-termux.sh
```

Esta reparación cambia el instalador de tu copia; para obtener también las mejoras de detección de ping, utiliza el paquete actual. Ahora se busca `ping` en PATH y, si no aparece, se comprueba `/system/bin/ping` en Android. Si no existe, el descubrimiento IPv4 automático recurre a TCP después de verificar la subred local. Si el firmware bloquea ICMP, puedes elegir explícitamente `discover --method tcp --network TU_SUBRED`. IPv6 puede utilizar vecinos en modo pasivo o una dirección conocida.

No se propone `inetutils` como sustituto: el paquete actual de Termux desactiva sus programas ping y ping6 en la compilación.

## Derivados y otros intérpretes Android

No se presupone el nombre del paquete `com.termux`. Las rutas se obtienen de `HOME`, `PREFIX`, `XDG_CONFIG_HOME`, `XDG_DATA_HOME` y `TMPDIR`, y los ejecutables se buscan en `PATH`. También se reconoce Python cuyo `sys.platform` es `android`.

Si tu entorno no tiene `pkg`, instala **Python 3.10+, ADB, tmux con display-popup y una shell compatible** con su gestor o sus paquetes nativos. Después, desde una carpeta privada:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
bash iniciar.sh doctor
```

Si tu intérprete no proporciona `venv`, puedes instalar las dependencias mediante el mecanismo soportado por esa aplicación y ejecutar `python3 Dogo_Box_Tv.py`. Los comandos no interactivos pueden utilizarse sin prompt_toolkit y sin tmux; las preguntas con cuadros necesitan prompt_toolkit y la shell delimitada necesita tmux. Un binario Linux de escritorio no sustituye a un ADB o tmux nativo compatible con Android y la arquitectura del teléfono.

En distribuciones Linux dentro de proot, usa los paquetes correspondientes a esa distribución y su intérprete; proot no elimina los permisos de red del Android que lo aloja. El instalador automático no es un instalador universal para todas las aplicaciones Android.

## Conectar por ADB

Utiliza **17** para introducir la IP del dispositivo y su puerto ADB. La herramienta guarda la selección después de comprobar el estado `device`. Desde otra terminal Android, la autorización ADB puede ser distinta de la que ya aceptaste para tu PC; acepta en el TV-box la autorización si aparece.

Ejemplos, sustituyendo las direcciones por las de tu equipo:

```bash
# Conectar y guardar el destino comprobado
bash iniciar.sh select 192.168.0.101 --port 3222

# Utilizar una IPv6 link-local con la interfaz del teléfono
bash iniciar.sh select 'fe80::2e73:60ff:fef1:78d0%wlan0' --port 3222

# Consultar estado y abrir la shell encuadrada
bash iniciar.sh status
bash iniciar.sh shell
```

Si el destino usa depuración inalámbrica con emparejamiento de Android, completa primero `adb pair IP:PUERTO_DE_EMPAREJAMIENTO` en Termux y después conecta mediante el puerto de conexión que muestre Android. No se presupone que ambos puertos sean iguales. El script no registra códigos de emparejamiento.

La conexión USB desde una aplicación Android depende de permisos y soporte adicionales del sistema; no se garantiza que un cable OTG baste. La vía documentada y preparada aquí es ADB por red.

## Configuración y archivos privados

Con los valores predeterminados de Android:

| Dato | Ruta |
| --- | --- |
| Configuración | `$HOME/.config/Dogo_Box_Tv/config.json` |
| Capturas, vídeos, reportes y registro | `$HOME/.local/share/Dogo_Box_Tv/salidas/` |
| Sesiones de directo | Junto a la configuración, en `.tvbox-streams/` |
| Temporales | `TMPDIR`, o `$PREFIX/tmp`, o una carpeta privada de caché |

Se respetan `XDG_CONFIG_HOME` y `XDG_DATA_HOME` si están definidos. `--config` tiene prioridad sobre `TVBOX_CONFIG` y sobre la ruta predeterminada; `--output-dir` tiene prioridad sobre la carpeta configurada. Una ruta de salida relativa en un archivo de configuración se resuelve junto a ese archivo. El `config.json` situado dentro del proyecto no se carga automáticamente en Android: así no se arrastran rutas o destinos de otra PC.

Puedes guardar un resultado explícitamente en almacenamiento compartido si Android te concedió acceso. El guardado sin sobrescritura funciona aunque ese sistema no admita enlaces duros; en ese caso utiliza creación exclusiva y copia. Esa copia no ofrece la misma publicación atómica que un enlace duro: un lector podría ver el archivo durante la escritura. Si falla, se intenta retirar solo la copia parcial creada por esa operación. La validación de PNG/MP4 se mantiene.

## Elegir una imagen desde la galería (1.19.0)

Usa **19 → 1**. Se abre una página local en tu navegador con **Elegir imagen**, vista previa y **Enviar al TV**. La elección utiliza el selector de fotos de Android; no necesitas copiar rutas ni instalar Termux:API. La imagen se envía cuando confirmas. **Cancelar** vuelve al menú y **20** retira la imagen del TV. La alternativa manual sigue en **19 → 2**.

El selector local requiere un navegador que admita selección de archivos. Se usa `am` de Termux para abrirlo. La página no utiliza servidores externos y la copia privada temporal se elimina al finalizar. Consulta [MEJORAS.md](MEJORAS.md#selector-visual-de-imagenes-1190).

## Perfiles y mantenimiento (1.18.0)

Consulta [MEJORAS.md](MEJORAS.md). El perfil `movil` limita el lado mayor a 960 píxeles, 15 FPS y 2 Mbps; es una alternativa más ligera, sin cambiar los perfiles anteriores. Las opciones **22** a **25** permiten equipos guardados, calidad por equipo, compatibilidad y actualización/restauración con respaldo. La configuración privada de Android y sus archivos se conservan.

## Directo con Termux:X11 (1.17.1)

La opción **5** utiliza scrcpy para recibir vídeo del TV box a través de su conexión ADB. En una terminal Android necesita el servidor gráfico Termux:X11: se instala su paquete de terminal y también su aplicación Android, tal como especifica la [guía oficial](https://github.com/termux/termux-x11#setup-instructions).

```bash
bash instalar-directo-termux.sh
```

Este instalador opcional añade el repositorio gráfico oficial y los paquetes `scrcpy` y `termux-x11-nightly` mediante `pkg`. Las bibliotecas de vídeo y gráficos son dependencias de esos paquetes. Instala además `termux-x11-universal-debug.apk` desde [la publicación oficial de Termux:X11](https://github.com/termux/termux-x11/releases/tag/nightly). No necesitas instalar XFCE ni un escritorio completo.

Conecta y guarda el TV box mediante **17**, después utiliza **5** y elige el perfil. El arranque prepara `DISPLAY` solo para el proceso del directo, reutiliza una pantalla local disponible o abre una entre `:1` y `:9`, desactiva la escucha TCP del servidor nuevo y abre Termux:X11. No modifica `.bashrc` ni configura acceso público. Si ya definiste un DISPLAY o WAYLAND_DISPLAY propio, lo conserva.

El visor Android usa pantalla completa y renderizado software para evitar depender de aceleración OpenGL. Se utiliza el comando `am` de Termux para abrir el visor, porque Android rechaza al UID de una aplicación que el comando del sistema se identifique como `com.android.shell`. En Android se espera el primer cuadro de vídeo antes de indicar que el directo inició; si falla el decodificador o la conexión, se conserva el registro y se muestra el error. El sonido y el control remoto continúan desactivados.

Puedes volver a Termux mediante el selector de aplicaciones y utilizar **8** para detener el directo o **9** para ver las sesiones activas. **0** cierra los directos iniciados por ese menú. El servidor Termux:X11 permanece disponible para reutilizarlo; su aplicación permite cerrar el visor. Si Android impide traer otra aplicación al frente, abre Termux:X11 manualmente.

## MAC e IPv6 con ADB local (1.17.0)

En Android 14 del teléfono probado, el UID normal de Termux no puede leer las tablas ARP/NDP ni enumerar interfaces mediante netlink. ADB autorizado sí puede consultar esos vecinos. Se reproducen las restricciones descritas por los [mantenedores de Termux](https://github.com/termux/termux-packages/issues/16226).

La versión 1.17.0 también corrige problemas independientes de esos permisos: usa `ping6` cuando está disponible y enlaza ping IPv4 a la IP de Wi-Fi, evitando el `SO_BINDTODEVICE: Operation not permitted` producido al indicar el nombre de interfaz. Cuando netlink está bloqueado, intenta consultas ioctl dirigidas a `wlan0`, `wlan1` y `wifi0`: obtiene la máscara real IPv4 y la dirección link-local IPv6 sin exigir que exista IPv4. No inventa MAC ni deriva una MAC de la dirección IPv6.

Para disponer de las MAC reales en un teléfono con Android 11 o posterior:

1. Abre Opciones de desarrollador, activa **Depuración inalámbrica** y elige **Vincular dispositivo con un código de vinculación**.
2. En el script abre **21**, elige **1** e introduce `127.0.0.1:PUERTO` con el puerto de vinculación y el código de seis dígitos del propio teléfono.
3. Introduce `127.0.0.1:PUERTO` con el puerto de conexión mostrado en la pantalla principal de Depuración inalámbrica. Es distinto del puerto de vinculación.
4. Usa **10** para IPv4, **15** para IPv6 o **14** para buscar una MAC; esta última permite elegir IPv4 o IPv6.

En el teléfono del propietario esta vinculación ya quedó realizada. El proyecto sigue en `$HOME/Tv_Box_auditoria/Dogo_Box_Tv` y el menú se abre con `bash iniciar.sh`. La conexión al TV box sigue siendo una selección independiente con **17**.

El acceso de red acepta únicamente conexiones a `127.0.0.1`, verifica el número de serie del teléfono y guarda endpoint e identidad en `network-adb.json`, junto a la configuración privada. El código de vinculación no se guarda en ese archivo ni en el registro. Las claves las administra ADB. Se utiliza un servidor ADB local separado en el puerto **5038**, para que el teléfono auxiliar no se seleccione como TV box.

Si Android apaga la depuración inalámbrica al cambiar de Wi-Fi o reiniciar, actívala de nuevo. Se intenta reconectar al endpoint guardado; si cambia el puerto, se consultan anuncios mDNS de la propia IP Wi-Fi y se verifica la identidad antes de utilizarlos. Si mDNS no está disponible, entra en **21 → 2** e introduce el puerto actual. **21 → 3** retira la configuración del acceso auxiliar; para desactivar el servicio de depuración o revocar la vinculación utiliza los ajustes Android. La conexión desde Termux es local y no configura acceso desde Internet.

La prueba real recuperó **siete IPv6 con sus MAC**, incluida `2C:73:60:F1:78:D0` del TV box. Un sondeo unicast a quienes respondieron al multicast permite que el kernel complete NDP antes de consultar la tabla. Una MAC aleatoria permanece como tal y no se asigna un fabricante por su apariencia.

La comprobación final IPv4 mostró **tres direcciones con MAC**: router, TV box `192.168.0.101` y teléfono `192.168.0.113`. Al principio ARP hacia el TV box quedó `FAILED`; en la prueba final respondió al ping con enlace de origen corregido. No se estableció la causa de esa falta de respuesta inicial. El acceso ADB recupera los datos que el sistema conoce y no garantiza descubrir todos los dispositivos.

## Cambiar de Wi-Fi y recuperar la opción 15 (1.22.1)

La conexión ADB del script con el propio teléfono sirve para consultar sus interfaces y vecinos. Es independiente de la conexión con la TV-box. Si la primera queda desconectada, **21 → 2** permite reconectarla usando `127.0.0.1:PUERTO`, con el puerto actual de **conexión** que muestra Depuración inalámbrica. El puerto para vincular con código es distinto. Si el teléfono solicita permiso para la nueva red, debe concederse desde sus ajustes.

La recuperación automática del auxiliar utiliza anuncios del propio teléfono y comprueba su identidad. Depende de que se encuentren esos anuncios; la documentación de [ADB describe la dependencia de mDNS para descubrir dispositivos vinculados](https://developer.android.com/tools/adb#connect-to-a-device-over-wi-fi).

Desde 1.22.1, un auxiliar desconectado no bloquea toda la búsqueda: se intentan las consultas básicas de Android. Si falla multicast, se conservan los vecinos conocidos y se marca el resultado como parcial. Si aparecen respuestas sin MAC, no se inventa el fabricante ni se afirma que el equipo esté ausente. Los datos de vinculación y el destino elegido se conservan.

Si **15** solo muestra el teléfono, comprueba que teléfono y TV-box tengan conectividad en la misma red local y usa **10** para IPv4. El script no puede garantizar descubrimiento si el router aísla clientes, bloquea multicast o la interfaz no dispone de IPv6. Los casos de fallo se verificaron mediante simulaciones Android; falta probar esta versión en el teléfono dentro de la red nueva.

Para actualizar una copia existente, conserva juntos `Dogo_Box_Tv-v1.22.1.zip` y `Dogo_Box_Tv-v1.22.1.sha256`, y usa **25 → 1** con la ruta del ZIP. Si se usan las rutas compartidas de Descargas, Android debe haber concedido acceso a ese almacenamiento. El actualizador conserva la configuración, crea respaldo y requiere detener los directos de ese cliente. Reinicia el programa al terminar.

## Descubrimiento básico y alternativa TCP

Sin vincular ADB local, los métodos básicos conservan las respuestas ICMP/ICMPv6 aunque Android deniegue la tabla de MAC. El resultado JSON expone `mac_available: false` y el menú explica cómo habilitar el acceso. Una búsqueda por MAC no presenta ese bloqueo como «equipo no encontrado».

Si el firmware impide las consultas dirigidas de Wi-Fi, la opción **10** permite indicar la subred manual para buscar respuestas TCP:

```bash
bash iniciar.sh discover --method tcp --network 192.168.0.0/24 --ports 3222,5555
bash iniciar.sh discover --ipv6 --interface wlan0
bash iniciar.sh find-mac 2C:73:60:F1:78:D0 --ipv6 --interface wlan0
```

La alternativa TCP comprueba que la IP de salida está dentro de la subred solicitada; admite hasta 1024 direcciones y 16 puertos, con `--timeout` entre 0.1 y 10 segundos. No obtiene MAC ni fabricante y no admite `--interface` ni `--passive`. Conserva errores locales y marca resultados parciales. Si se configuró acceso ADB local y falla su conexión, se informa del problema para reconectarlo.

IPv6 utiliza multicast y vecinos de una interfaz, sin recorrer un `/64`. Si el firmware bloquea el sondeo, puedes pegar una dirección conocida con su ámbito en **11** o **17**. La compatibilidad depende de los permisos y herramientas del Android concreto; proot no concede permisos del sistema.

## Funciones y condiciones

| Función | Desde una terminal Android |
| --- | --- |
| Menú, colores, cuadros y preguntas | Con prompt_toolkit; los campos largos se desplazan dentro del marco |
| ADB, estado, shell, imágenes, PNG y MP4 | Con ADB nativo y un destino conectado/autorizado |
| Shell encuadrada | Con tmux y PTY; adapta el marco al reducir y ampliar sin reiniciar la shell |
| TCP IPv4/IPv6 por dirección conocida | Sujeto a conectividad y permisos de red de la aplicación |
| Descubrimiento IPv4 por TCP | Con una subred explícita y verificable por la ruta local |
| Descubrimiento por vecinos, MAC e IPv6 multicast | Sujeto a herramientas y permisos del Android |
| Directo scrcpy | Requiere scrcpy y un entorno gráfico, por ejemplo Termux:X11 con DISPLAY configurado |
| Gestión de directos entre sesiones | Requiere poder verificar la identidad de los procesos; no se envían señales a procesos sin verificar |

Para el directo, Termux mantiene [scrcpy en sus paquetes X11](https://github.com/termux/termux-packages/blob/master/x11-packages/scrcpy/build.sh). La preparación del repositorio y cliente puede hacerse con:

```bash
pkg install x11-repo
pkg install scrcpy
```

Instala y configura también la aplicación/servidor [Termux:X11 siguiendo su guía](https://github.com/termux/termux-x11). Solo tener `DISPLAY` definido no demuestra que el servidor gráfico esté funcionando. El instalador básico no instala el entorno gráfico. Las capturas PNG y la grabación MP4 no necesitan una ventana gráfica en el cliente.

## Alcance de la validación

La regresión **1.17.1** ejecutó 191 pruebas en Linux (OK) y 190 en Termux real (OK, 7 omitidas de escritorio). Se añadieron comprobaciones del arranque X11, paquete/APK incompleto, reutilización de pantalla, permisos por usuario Android y fallos de vídeo anteriores al primer cuadro.

La versión **1.17.0** ejecutó 181 pruebas en Linux (OK) y 181 en el teléfono Android 14 (OK, 7 omitidas de escritorio). Se verificaron además descubrimiento IPv4/IPv6, MAC del TV box y el modo sin auxiliar en el teléfono.

Se verifican el código y su regresión en Linux, con pruebas que simulan Android, un PREFIX de otra aplicación, HOME privado, permisos de red denegados y almacenamiento sin enlaces duros. Hay una prueba real con PTY/tmux local que amplía y reduce el cuadro conservando una variable de la shell y el código de salida 7. El instalador se verifica con un gestor `pkg` simulado; no se modifican los paquetes de la PC durante esa prueba.

**La versión 1.16.2 se verificó en Termux real 0.118.3 sobre Android 14/ARM64 con Python 3.14.10**, además de Linux. El instalador completo, ADB y el editor se comprobaron, y se observaron el menú y el cuadro editable en la pantalla del teléfono. La suite real ejecutó 165 pruebas: resultado OK, con 7 comprobaciones de Linux de escritorio omitidas. No se afirma compatibilidad con todas las derivaciones o firmwares. El diagnóstico identifica las dependencias presentes y las restricciones detectables en cada instalación.

Esta adaptación prepara el script para ejecutarlo desde Android. El objetivo de convertir la TV-box en servidor con dirección remota fija permanece documentado en `ACCESO_REMOTO.md`; no se generó todavía una dirección `.onion` ni se configuró acceso desde Internet.

## Fuentes de paquetes

- [Aplicación Termux e instalación](https://github.com/termux/termux-app).
- [ADB en android-tools](https://github.com/termux/termux-packages/blob/master/packages/android-tools/build.sh).
- [tmux para Termux](https://github.com/termux/termux-packages/blob/master/packages/tmux/build.sh).
- [Política de paquetes Python/pip](https://github.com/termux/termux-packages/discussions/2881).
