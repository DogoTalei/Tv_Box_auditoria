"""Start a local Termux:X11 display without changing the user's shell settings."""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import socket
import subprocess
import time


class DisplayError(Exception):
    pass


def installed():
    binary = shutil.which("termux-x11")
    if not binary:
        return None
    try:
        result = subprocess.run(["/system/bin/pm", "path", "--user", str(os.getuid() // 100000), "com.termux.x11"],
                                stdin=subprocess.DEVNULL, capture_output=True, timeout=8)
        return binary if result.returncode == 0 and result.stdout.startswith(b"package:") else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def require_available():
    binary = installed()
    if not binary:
        raise DisplayError("El directo en Android requiere scrcpy y Termux:X11 (paquete y aplicación). "
                           "Ejecuta bash instalar-directo-termux.sh y consulta TERMUX.md. "
                           "La opción 5 abrirá el visor automáticamente cuando estén instalados.")
    return binary


def connected(path):
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
            connection.settimeout(0.3)
            connection.connect(str(path))
        return True
    except OSError:
        return False


def prepare(output, environment=None):
    env = dict(os.environ if environment is None else environment)
    # Explicit displays may belong to proot or a remote X server.
    if env.get("DISPLAY") or env.get("WAYLAND_DISPLAY"):
        return env
    binary = require_available()
    temporary = Path(os.environ["TMPDIR"])
    chosen = None
    for number in range(1, 10):
        path = temporary / ".X11-unix" / f"X{number}"
        if connected(path):
            env["DISPLAY"] = f":{number}"
            return env
        if chosen is None and not path.exists():
            chosen = (number, path)
    if chosen is None:
        raise DisplayError("No hay una pantalla X11 libre entre :1 y :9. Revisa los servidores de Termux:X11.")
    number, path = chosen
    destination = Path(output) / "termux-x11.log"
    descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    os.chmod(destination, 0o600)
    with os.fdopen(descriptor, "ab") as log:
        process = subprocess.Popen([binary, f":{number}", "-nolisten", "tcp"],
                                   stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        if connected(path):
            env["DISPLAY"] = f":{number}"
            return env
        if process.poll() not in (None, 0):
            break
        time.sleep(0.1)
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    raise DisplayError(f"Termux:X11 no abrió la pantalla en 10 segundos. Revisa {destination}.")


def show():
    user = str(os.getuid() // 100000)
    # Termux's am wrapper identifies the calling app. The system shell command
    # claims com.android.shell, which Android rejects for a regular app UID.
    launcher = shutil.which("am") or "/system/bin/am"
    try:
        result = subprocess.run([launcher, "start", "--user", user, "-n",
                                 "com.termux.x11/com.termux.x11.MainActivity"],
                                stdin=subprocess.DEVNULL, capture_output=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise DisplayError("Abre la aplicación Termux:X11 para ver el directo.") from error
    if result.returncode or b"Error:" in result.stdout + result.stderr:
        raise DisplayError("El directo está iniciado. Abre la aplicación Termux:X11 para verlo.")


def wait_video(process, log_path, timeout=15):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        text = Path(log_path).read_text(errors="replace")[-16000:]
        if process.poll() is not None:
            raise DisplayError("scrcpy terminó antes de mostrar vídeo: " + text[-1800:])
        if "Texture:" in text:
            return
        time.sleep(0.1)
    raise DisplayError(f"No llegó el primer cuadro de vídeo en {timeout} segundos. Revisa {log_path}.")
