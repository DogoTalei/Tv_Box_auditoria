# Retomar Dogo_Box_Tv

Firma: H4ckZone_by_Dogo. Versión: 1.22.1.

Estado actualizado: 2026-11-17.

El tema predeterminado y guardado en esta PC es **fuego**, con naranja, amarillo y texto claro. El encabezado es compacto y las acciones forman una tabla alineada; desde 72 columnas aparece también su área. El menú principal mantiene las opciones del 1 al 26 en una sola columna y aparece una vez al iniciar. Los resultados quedan abajo, seguidos del campo para elegir otra opción. Escribe **m** para mostrar de nuevo el menú y **0** para salir. Reinicia el menú para cargar la versión 1.22.0; los números conservan sus funciones.

La opción **15** tiene una corrección para Android al cambiar de Wi-Fi: intenta continuar si se desconecta el ADB local del teléfono, conserva vecinos cuando falla multicast y señala los resultados parciales. **21 → 2** reconecta el auxiliar del teléfono con su puerto actual; **10** permite descubrir por IPv4. Hay 279 pruebas Linux aprobadas, incluidas nueve de estas condiciones Android simuladas; falta probar 1.22.1 en la red nueva desde el teléfono. La copia del teléfono debe actualizarse con **25 → 1** y reiniciarse.

La opción **19** muestra las imágenes con el visor Dogo: completas, centradas y proporcionadas, con corrección EXIF. Ya está instalado y probado en el TV-box actual. **20** retira la imagen. El APK está incluido en el módulo Python y se instala automáticamente al primer uso en otro equipo compatible; no hace falta compilarlo.

## Activar ADB desde el puerto 5000

Usa **26**, elige la IP o fila del TV-box y espera la verificación de ADB en 5555. Se guarda el destino solo cuando ADB confirma la conexión. Desde comandos: `bash iniciar.sh enable-adb --host 192.168.0.116`. Las búsquedas TCP y la opción 11 incluyen 5000 en su lista predeterminada. Consulta [MEJORAS.md](MEJORAS.md#activación-adb-por-tcp-5000-1200).

Desde 1.20.1 puedes elegir la fila IPv6: si el servicio 5000 no responde por IPv6, se busca una IPv4 del mismo equipo mediante su MAC y una respuesta actual. Los cuadros de preguntas comparten el ancho del menú y los resultados. Reinicia un menú abierto para cargar estos cambios.

## Selector de imágenes actual

**19 → 1** abre el selector visual; en el teléfono elige una foto en la galería, revisa la vista previa y pulsa **Enviar al TV**. Se intenta volver a Termux con el resultado. **19 → 2** conserva la ruta manual y **20** quita la imagen del TV. Consulta [MEJORAS.md](MEJORAS.md#selector-visual-de-imagenes-1190).

## Mejoras actuales

Consulta [MEJORAS.md](MEJORAS.md). **22** guarda/conecta varios equipos, **23** configura calidad, **24** comprueba compatibilidad y **25** revisa/aplica ZIP con respaldo y permite restaurar el código anterior. **5** también acepta `movil`; los perfiles anteriores permanecen disponibles. Las preferencias antiguas no se modifican al leerlas. Reinicia un menú ya abierto para cargar la versión nueva.

## Uso desde Termux o un derivado Android

Consulta [TERMUX.md](TERMUX.md). Extrae el paquete dentro de `$HOME`, ejecuta `bash instalar-termux.sh` y luego `bash iniciar.sh`. El instalador prepara las dependencias en un entorno Python del proyecto. Android conserva su configuración en una ruta privada y no reutiliza automáticamente el `config.json` de la PC. La versión 1.16.2 se verificó en Termux real sobre Android 14/ARM64. En el teléfono del propietario el proyecto está en `$HOME/Tv_Box_auditoria/Dogo_Box_Tv`.

## Directo desde el teléfono, 1.17.1

La opción **5** configura una pantalla local de Termux:X11 y abre el visor de scrcpy. Requiere el paquete de terminal y su APK. El instalador gráfico opcional es `bash instalar-directo-termux.sh`; consulta [TERMUX.md](TERMUX.md#directo-con-termuxx11-1171). La conexión ADB del teléfono al TV box se verificó y guardó para esta función. **8** detiene el directo al regresar a Termux y **9** muestra sus sesiones.

## Descubrimiento desde el teléfono, 1.17.0

La opción **21** configura acceso a vecinos por ADB local seguro; ya se vinculó el propio teléfono y se verificó el acceso a MAC sin root. Mantén Depuración inalámbrica activada. Si el puerto cambia y mDNS no permite reconectar, usa **21 → 2** con el nuevo puerto de conexión en `127.0.0.1:PUERTO`.

Usa **15** para IPv6: se verificaron siete direcciones con MAC. **14** permite elegir búsqueda MAC por IPv6, que sí encuentra el TV box en esta red. **10** también recupera las MAC visibles por IPv4: se comprobaron router, TV box y teléfono. Consulta [TERMUX.md](TERMUX.md#mac-e-ipv6-con-adb-local-1170).

## Inicio después de encender la PC

```bash
/home/dogo/Dogo_Box_Tv/iniciar.sh
```

El acceso `/home/dogo/Dogo_Box_Tv` enlaza a `/home/dogo/tvbox-tools`; ambos usan la misma configuración y salidas. Si hay problemas con la interfaz, utiliza la opción 6 para revisar dependencias. Se necesita una terminal compatible con UTF-8 y controles de terminal para los cuadros interactivos.

1. Enciende el TV-box y conecta la PC a su misma red.
2. Usa **2** para verificar el estado del destino guardado. Si cambió su dirección, utiliza **15** o **10** para descubrir y **17** para conectar y guardar el destino verificado.
3. Usa **18** para la shell, **5** para el directo o **19** para mostrar una imagen elegida.
4. **0** sale del menú y cierra los directos que ese menú creó. La shell regresa al menú con `exit` o Ctrl+D; Ctrl+C interrumpe el comando remoto.

## Referencias de conexión del propietario

- Destino actual: `192.168.0.116:5555`.
- MAC del equipo actual: `30:4A:26:91:D9:48`.
- Se comprobó ADB y una shell interactiva como UID 2000 (`shell`). El servicio 5000 permitió iniciar el ejecutable ADB instalado.
- La tarea reside en memoria; comprueba la conexión tras reiniciar la TV-box o el servicio 5000 y utiliza 26 si hace falta activarla.
- El equipo anterior era `192.168.0.101`, MAC `2C:73:60:F1:78:D0`, con ADB en 3222 e IPv6 `fe80::2e73:60ff:fef1:78d0%wlan0`. Las pruebas antiguas de `adb root` corresponden a ese equipo.

## Opciones disponibles

| Opción | Función |
| --- | --- |
| 0 | Salir y cerrar los directos creados por este menú |
| 1 | Conexión temporal por red o selección USB |
| 2 | Verificar ADB, modelo y propiedades Android |
| 3 | Capturar pantalla PNG |
| 4 | Grabar vídeo MP4 |
| 5 | Iniciar directo con scrcpy |
| 6 | Diagnóstico de dependencias |
| 7 | Listar dispositivos ADB |
| 8 | Detener directo del destino |
| 9 | Listar directos registrados |
| 10 | Descubrir IPv4 y guardar selección |
| 11 | Elegir IP IPv4/IPv6 y comprobar puertos TCP |
| 12 | Temas y colores personalizados |
| 13 | Auditoría por etapas heredada, para IPv4 |
| 14 | Buscar un dispositivo por MAC |
| 15 | Descubrir IPv6, elegir fila o pegar una dirección y revisar puertos |
| 16 | Revisar servicios y problemas de configuración con evidencias |
| 17 | Conectar ADB por IP o fila y guardar el destino verificado |
| 18 | Shell ADB interactiva dentro de un marco personalizado |
| 19 | Enviar imagen o logo elegido y abrir un visor del TV-box |
| 20 | Retirar del primer plano la imagen administrada por la herramienta |
| 21 | Vincular/reconectar acceso ADB local del teléfono para consultar MAC |
| 22 | Equipos guardados y direcciones verificadas |
| 23 | Calidad del próximo directo |
| 24 | Comprobación de compatibilidad |
| 25 | Actualización local y restauración con respaldo |
| 26 | Activar ADB 5555 mediante el servicio compatible del puerto 5000 |

Se mantiene la preferencia del propietario de **no utilizar Nmap**. Las opciones 11, 15 y 16 no lo necesitan. En la auditoría heredada 13 deja desactivada la identificación opcional con Nmap.


## Qué quedó terminado

- Nombre Dogo_Box_Tv, firma H4ckZone_by_Dogo, tema predeterminado fuego y temas personalizables; `dogo` conserva cian/verde.
- Descubrimiento y selección por IPv4/IPv6; comprobación de puertos a voluntad sin cambiar automáticamente la selección ADB.
- Conexión ADB verificada, shell interactiva, capturas, grabación, directos y visualización/retirada de imágenes.
- Resultados, avisos, errores y progresos dentro de cuadros que ajustan las líneas largas al ancho disponible. Las preguntas usan campos editables delimitados, con desplazamiento horizontal del texto largo.
- Shell real dentro de una PTY delimitada por tmux, con firma, ajuste al redimensionar y conservación del código de salida. La sesión tmux es privada y temporal; no se reutilizan sesiones ni configuración tmux del usuario.
- JSON de comandos no interactivos sin decoración. La herramienta no guarda el contenido escrito o mostrado en la shell.

## Código, documentación y archivos

| Archivo o carpeta | Contenido |
| --- | --- |
| `Dogo_Box_Tv.py`, `iniciar.sh` | Lanzadores |
| `branding.py` | Nombre, firma y versión |
| `tvbox.py` | Menú, comandos, red, ADB y multimedia |
| `android_display.py` | Preparación y apertura de Termux:X11 para vídeo |
| `instalar-directo-termux.sh` | Dependencias gráficas opcionales de Termux |
| `network_access.py` | Consultas Wi-Fi Android y acceso ADB local a vecinos/MAC |
| `tvbox_runtime.py` | Detección Android/Termux, rutas privadas, shell y capacidades |
| `instalar-termux.sh`, `requirements.txt` | Instalación en Termux y dependencias Python |
| `TERMUX.md` | Guía y límites de la ejecución desde Android |
| `terminal_ui.py` | Cuadros, cálculo de ancho y editor de entrada |
| `shell_frame.py` | Terminal tmux privada para la shell |
| `tvbox_audit.py` | Auditoría IPv4 heredada |
| `tvbox_vuln.py` | Comprobaciones de servicios y reportes |
| `tvbox_adb_bootstrap.py` | Protocolo de listado y activación ADB por TCP 5000 |
| `tvbox_image_viewer.py` | Visor de imágenes universal, fuente Java, APK y transferencia privada |
| `build_image_viewer.py` | Recompilación opcional del visor con SDK/JDK y firma del propietario |
| `tests/` | Pruebas automatizadas |
| `config.json` | Configuración real y destino guardado; conservar localmente |
| `config.example.json` | Configuración de ejemplo para distribuir |
| `salidas/` | Capturas, vídeos, reportes, registros y evidencias privadas |
| `.tvbox-streams/` | Registros de los directos gestionados |
| `README.md` | Manual de uso y dependencias |
| `VALIDACION.md` | Pruebas realizadas y sus alcances |
| `AVANCE.md` | Historial y estado del proyecto |
| `SHA256SUMS.txt` | Hashes de los paquetes de esta entrega |

Dependencias de interfaz presentes: tmux 3.7c y prompt_toolkit 3.0.53. El diagnóstico también informa ADB y scrcpy. En Debian/Ubuntu, las dependencias nuevas se instalan con `sudo apt install tmux python3-prompt-toolkit`. Los comandos no interactivos no requieren esas dependencias de interfaz.

## Validación y límites

La suite 1.21.0 aprobó **270 pruebas en Linux**. Se verificaron además siete casos de imagen en el TV-box real: vertical, cuadrada, panorámica, JPEG con EXIF, imagen de 48 megapíxeles, GIF y transparencia PNG. Las capturas confirmaron proporciones y centrado; también se comprobó la retirada con 20. La ejecución anterior en el teléfono correspondió a 1.19.0: **233 casos, OK con 7 omitidos de escritorio**. La nueva versión no se volvió a ejecutar en el teléfono; los ZIP anteriores conservan sus versiones originales.

Pruebas previas de la interfaz: cuadros entre 6 y 100 columnas; entradas PTY de 200 caracteres a 36/48 columnas; shell local redimensionada de 80 a 48 columnas y salida 7 conservada. En el TV-box se comprobaron estado, shell, `pwd`, texto largo, Ctrl+C y regreso al menú con Ctrl+D. La última shell probada conservó el código 130 de un comando interrumpido, que no indica por sí solo un fallo de conexión.

- El descubrimiento IPv6 consulta multicast y vecinos: no recorre un /64 ni garantiza encontrar todos los equipos.
- Un puerto abierto no identifica por sí mismo el servicio ni demuestra una vulnerabilidad; la falta de respuesta no confirma filtrado.
- La opción 16 realiza comprobaciones acotadas; las coincidencias NVD son candidatas por validar, no CVE confirmadas.
- La detección de imágenes activas depende del formato de diagnóstico del firmware. La copia remota permanece al retirar la imagen de la pantalla.
- La shell enmarcada necesita tmux con display-popup y una terminal compatible. Las pruebas de shell real utilizaron al menos 18 filas; los anchos mínimos del menú se verificaron mediante renderizado.
- No hay una función pendiente necesaria para completar la solicitud de los cuadros. Las mejoras nuevas se decidirán al retomar.

## Cierre de esta sesión

La configuración, los archivos del usuario y las evidencias se conservan en el proyecto. Los paquetes distribuibles incluyen configuración de ejemplo, sin el destino privado ni los registros/salidas. El apagado solicitado en una sesión anterior quedó registrado en `AVANCE.md`. Esta revisión de red no programa otro apagado.
