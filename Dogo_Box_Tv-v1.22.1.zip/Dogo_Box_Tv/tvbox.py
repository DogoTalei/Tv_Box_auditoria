#!/usr/bin/env python3
"""Dogo_Box_Tv — Firma: H4ckZone_by_Dogo. Control y multimedia Android mediante ADB."""
from __future__ import annotations

import argparse
import contextlib
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt
import errno
import hashlib
import ipaddress
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
from typing import BinaryIO
import uuid
import zlib

from branding import APP_NAME, AUTHOR, SIGNATURE, VERSION
from terminal_ui import output_frame, unframed_terminal, read_input as terminal_read_input, wrap_cells, cells, terminal_width, color_spec, InputDependencyError
from shell_frame import framed_shell
import tvbox_runtime as runtime
import network_access
import android_display
import tvbox_video
import image_picker

ROOT = Path(__file__).resolve().parent
LOG = logging.getLogger("tvbox")
COLORS = {"negro": "30", "rojo": "31", "verde": "32", "amarillo": "33", "azul": "34",
          "magenta": "35", "cian": "36", "blanco": "37", "gris": "90", "coral": "91",
          "lima": "92", "oro": "93", "lavanda": "94", "rosa": "95", "turquesa": "96", "nieve": "97"}
BASE_THEME = dict(title="rosa", accent="turquesa", ok="lima", warning="oro", error="coral", muted="gris",
                  device="oro", network="turquesa", media="rosa", audit="lavanda", border="magenta", progress="lima")
THEMES = {
    "dogo": dict(BASE_THEME, title="cian", accent="turquesa", device="lima", network="cian",
                 media="turquesa", audit="lavanda", border="cian", progress="lima"),
    "neon": BASE_THEME,
    "oceano": dict(BASE_THEME, title="turquesa", accent="cian", device="nieve", media="lavanda", border="azul"),
    "fuego": dict(BASE_THEME, title="#FFD166", accent="#F4EDE4", ok="#B8D68A", warning="#FFC857",
                  error="#FF705B", muted="#ADA49A", device="#FFD166", network="#FF9F43",
                  media="#F2BB77", audit="#EBA45D", border="#C56A32", progress="#FFC857"),
    "bosque": dict(BASE_THEME, title="lima", accent="verde", device="oro", network="cian", media="lima", audit="amarillo", border="verde"),
    "clasico": dict(BASE_THEME, title="cian", accent="cian", ok="verde", warning="amarillo", error="rojo", device="cian", network="cian", media="cian", audit="cian", border="gris"),
    "claro": dict(BASE_THEME, title="magenta", accent="azul", ok="verde", warning="magenta", error="rojo", muted="negro", device="azul", network="azul", media="magenta", audit="rojo", border="azul", progress="azul"),
}
ROLE_LABELS = dict(title="Títulos", accent="Texto y acciones", ok="Éxitos y puertos abiertos", warning="Avisos",
                   error="Errores", muted="Información secundaria", device="Destino activo", network="Dispositivo y red",
                   media="Capturas y directo", audit="Auditoría y soporte", border="Separadores", progress="Progreso")
PROFILES = {
    "movil": {"max_size": 960, "fps": 15, "bitrate": 2_000_000},
    "fluido": {"max_size": 1280, "fps": 30, "bitrate": 4_000_000},
    "equilibrado": {"max_size": 1920, "fps": 30, "bitrate": 6_000_000},
    "nitido": {"max_size": 1920, "fps": 30, "bitrate": 10_000_000},
}
DISCOVERY_PORTS = [22, 80, 443, 3222, 5000, 5555]


class ToolError(Exception):
    def __init__(self, message: str, code: int = 1):
        super().__init__(message)
        self.code = code


def color_code(value):
    if isinstance(value, str) and value in COLORS:
        return COLORS[value]
    if isinstance(value, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", value):
        return "38;2;" + ";".join(str(int(value[index:index + 2], 16)) for index in (1, 3, 5))
    raise ToolError("Color inválido. Usa un nombre de la paleta o #RRGGBB.")


def appearance_settings(value):
    if not isinstance(value, dict):
        raise ToolError("appearance debe ser un objeto JSON.")
    theme, mode, colors = value.get("theme", "fuego"), value.get("mode", "auto"), value.get("colors", {})
    if not isinstance(theme, str) or theme not in THEMES or mode not in ("auto", "always", "never"):
        raise ToolError("Tema o modo de color inválido en appearance.")
    if not isinstance(colors, dict) or any(role not in BASE_THEME for role in colors):
        raise ToolError("Rol de color desconocido en appearance.colors.")
    for color in colors.values():
        color_code(color)
    return {"theme": theme, "mode": mode, "colors": dict(colors)}


class Console:
    def __init__(self):
        self.mode = "auto"
        self.machine = False
        self.configure({})

    def configure(self, settings, theme=None, mode=None):
        settings = appearance_settings(settings)
        self.theme = theme or settings["theme"]
        self.mode = mode or settings["mode"]
        names = dict(THEMES[self.theme])
        if not theme or theme == settings["theme"]:
            names.update(settings["colors"])
        self.palette = {role: ("1;" if role == "title" else "") + color_code(color) for role, color in names.items()}

    def preview(self):
        self.message(f"\nTema: {self.theme} · Colores: {self.mode}", "title")
        for role, label in ROLE_LABELS.items():
            self.message(f"  ██  {role:<9} {label}", role)
        if not self.enabled():
            print("Vista sin color: usa --color always si tu terminal admite ANSI.")

    def enabled(self):
        return not self.machine and (self.mode == "always" or (self.mode == "auto" and sys.stdout.isatty()
                                         and "NO_COLOR" not in os.environ and os.environ.get("TERM") != "dumb"))

    def paint(self, value, style="accent"):
        # Device names and external error text must not inject terminal control sequences.
        value = re.sub(r"[\x00-\x08\x0b-\x1f\x7f-\x9f]", "", str(value))
        return f"\033[{self.palette[style]}m{value}\033[0m" if self.enabled() else value

    def message(self, value, style="accent"):
        print(self.paint(value, style), flush=True)


UI = Console()


def read_input(prompt):
    return terminal_read_input(prompt, UI)


def parallel_tasks(items, function, workers=32, label="Progreso"):
    """Bound concurrency, report from the main thread and cancel queued work on Ctrl+C."""
    values = list(items)
    if not values:
        return []
    cancelled = threading.Event()
    pool = ThreadPoolExecutor(max_workers=min(workers, len(values)))
    def run(value):
        return None if cancelled.is_set() else function(value)
    futures = {pool.submit(run, value): index for index, value in enumerate(values)}
    results = [None] * len(values)
    interactive = sys.stdout.isatty() and not UI.machine
    completed = 0
    last_progress = 0.0
    try:
        for future in as_completed(futures):
            results[futures[future]] = future.result()
            completed += 1
            if interactive and (time.monotonic()-last_progress >= 0.3 or completed == len(values)):
                last_progress = time.monotonic()
                print("\r" + UI.paint(f"{label}: {completed}/{len(values)}", "progress"), end="", flush=True)
        return results
    finally:
        cancelled.set()
        for future in futures:
            future.cancel()
        pool.shutdown(wait=True, cancel_futures=True)
        if interactive:
            print()


def now() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def bitrate(value: str) -> int:
    match = re.fullmatch(r"([1-9][0-9]*)([kKmM]?)", str(value).strip())
    if not match:
        raise argparse.ArgumentTypeError("Bitrate inválido. Ejemplos: 6M, 4000000, 800k.")
    rate = int(match[1]) * {"": 1, "k": 1000, "m": 1_000_000}[match[2].lower()]
    if not 100_000 <= rate <= 100_000_000:
        raise argparse.ArgumentTypeError("El bitrate debe estar entre 100k y 100M.")
    return rate


def size(value: str) -> tuple[int, int]:
    match = re.fullmatch(r"([1-9][0-9]*)[xX]([1-9][0-9]*)", value)
    if not match:
        raise argparse.ArgumentTypeError("Usa ANCHOxALTO, por ejemplo 1280x720.")
    width, height = map(int, match.groups())
    if min(width, height) < 16 or max(width, height) > 8192 or width % 2 or height % 2:
        raise argparse.ArgumentTypeError("Las dimensiones deben ser pares, entre 16 y 8192.")
    return width, height


def bounded(low: int, high: int):
    def parse(value: str) -> int:
        try:
            number = int(value)
        except ValueError as error:
            raise argparse.ArgumentTypeError("Introduce un número entero.") from error
        if not low <= number <= high:
            raise argparse.ArgumentTypeError(f"El valor debe estar entre {low} y {high}.")
        return number
    return parse


def port_list(value: str) -> list[int]:
    ports = set()
    for part in value.split(","):
        match = re.fullmatch(r"\s*([0-9]{1,5})(?:\s*-\s*([0-9]{1,5}))?\s*", part)
        if not match:
            raise argparse.ArgumentTypeError("Usa puertos separados por comas o rangos: 22,80,443,8000-8010.")
        start, end = int(match[1]), int(match[2] or match[1])
        if not 1 <= start <= end <= 65535:
            raise argparse.ArgumentTypeError("Los puertos deben estar entre 1 y 65535 y los rangos en orden ascendente.")
        if end - start + 1 > 4096:
            raise argparse.ArgumentTypeError("Selecciona como máximo 4096 puertos por comprobación.")
        ports.update(range(start, end + 1))
        if len(ports) > 4096:
            raise argparse.ArgumentTypeError("Selecciona como máximo 4096 puertos por comprobación.")
    return sorted(ports)


def scan_timeout(value: str) -> float:
    try:
        seconds = float(value)
    except ValueError as error:
        raise argparse.ArgumentTypeError("El tiempo de espera debe ser un número entre 0.1 y 10 segundos.") from error
    if not 0.1 <= seconds <= 10:
        raise argparse.ArgumentTypeError("El tiempo de espera debe estar entre 0.1 y 10 segundos.")
    return seconds


def terminal_snapshot():
    try:
        import termios
    except ImportError:
        return None
    try:
        descriptor = sys.stdin.fileno()
        return termios, descriptor, termios.tcgetattr(descriptor)
    except (OSError, ValueError, termios.error):
        return None


def restore_terminal(snapshot):
    if snapshot is not None:
        termios, descriptor, attributes = snapshot
        try:
            termios.tcsetattr(descriptor, termios.TCSANOW, attributes)
        except (OSError, ValueError, termios.error):
            LOG.warning("No se pudo restaurar el estado de la terminal local.")


def ip_host(value: str, interface: str | None = None) -> str:
    """Normalize a literal address and retain the interface of link-local IPv6."""
    value = value.strip()
    if value.startswith("[") and value.endswith("]"):
        value = value[1:-1]
    base, separator, zone = value.partition("%")
    try:
        address = ipaddress.ip_address(base)
    except ValueError as error:
        raise ToolError("Introduce una dirección IPv4 o IPv6 válida, sin puerto.") from error
    if address.is_multicast or address.is_unspecified:
        raise ToolError("Elige la dirección de un equipo, no una dirección multicast o sin especificar.")
    if address.version == 4:
        if separator:
            raise ToolError("Una dirección IPv4 no lleva %interfaz.")
        return str(address)
    if separator and not zone:
        raise ToolError("Falta la interfaz después de %.")
    zone = zone or (interface if address.is_link_local else None)
    if address.is_link_local and not zone:
        raise ToolError("La IPv6 link-local necesita %interfaz, por ejemplo fe80::1%wlan0, o --interface wlan0.")
    if zone:
        try:
            index = int(zone) if zone.isdecimal() else socket.if_nametoindex(zone)
            socket.if_indextoname(index)
            if interface and socket.if_nametoindex(interface) != index:
                raise ToolError("La interfaz indicada no coincide con el ámbito %interfaz de la IPv6.")
        except (OSError, ValueError, OverflowError) as error:
            raise ToolError(f"No existe la interfaz IPv6 indicada: {zone}.") from error
    return str(address) + ("%" + zone if zone else "")


def device_ip(device: str | None, interface: str | None = None) -> str:
    if not device:
        raise ToolError("Indica una IP con --host o selecciona un destino primero.")
    if device.startswith("["):
        match = re.fullmatch(r"\[([^\]]+)\]:[0-9]{1,5}", device)
        if match:
            return ip_host(match[1], interface)
    if device.count(":") == 1:
        host, port = device.rsplit(":", 1)
        if port.isdecimal() and 1 <= int(port) <= 65535:
            return ip_host(host, interface)
    return ip_host(device, interface)


def adb_address(host: str, port: int) -> str:
    if type(port) is not int or not 1 <= port <= 65535:
        raise ToolError("El puerto ADB debe estar entre 1 y 65535.")
    return f"[{host}]:{port}" if ":" in host else f"{host}:{port}"


def normalize_adb_address(address: str, interface: str | None = None) -> str:
    if address.startswith("["):
        match = re.fullmatch(r"\[([^\[\]\s]+)\]:([0-9]{1,5})", address)
        if not match:
            raise ToolError("Usa [IPv6%interfaz]:PUERTO, por ejemplo [fe80::1%wlan0]:3222.")
        host = ip_host(match[1], interface)
        if ":" not in host:
            raise ToolError("Los corchetes se utilizan para direcciones IPv6.")
    else:
        match = re.fullmatch(r"([A-Za-z0-9_.-]+):([0-9]{1,5})", address)
        if not match or match[1].startswith("-"):
            raise ToolError("Usa HOST:PUERTO o [IPv6%interfaz]:PUERTO.")
        host = match[1]
    return adb_address(host, int(match[2]))


def tcp_probe(host: str, port: int, timeout: float) -> dict:
    started = time.monotonic()
    code, detail = None, None
    try:
        if ":" in host:
            address, _, zone = host.partition("%")
            scope = (int(zone) if zone.isdecimal() else socket.if_nametoindex(zone)) if zone else 0
            family, endpoint = socket.AF_INET6, (address, port, 0, scope)
        else:
            family, endpoint = socket.AF_INET, (host, port)
        with socket.socket(family, socket.SOCK_STREAM) as connection:
            connection.settimeout(timeout)
            code = connection.connect_ex(endpoint)
        if code == 0:
            state = "open"
        elif code == errno.ECONNREFUSED:
            state = "closed"
        elif code in {errno.ETIMEDOUT, errno.EAGAIN, errno.EWOULDBLOCK}:
            state = "no_response"
        elif code in {errno.EHOSTUNREACH, errno.ENETUNREACH, errno.ENETDOWN}:
            state = "unreachable"
        else:
            state = "error"
    except (socket.timeout, TimeoutError):
        state = "no_response"
    except OSError as error:
        state, code, detail = "error", error.errno, str(error)
    result = {"port": port, "protocol": "tcp", "state": state,
              "elapsed_ms": round((time.monotonic() - started) * 1000, 2)}
    if code:
        result["error_code"] = code
    if detail:
        result["error"] = detail
    return result


def png_info(data: bytes) -> dict:
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ToolError("ADB no devolvió un PNG. Comprueba la conexión y los permisos de captura.")
    position, width, height, ended, first = 8, 0, 0, False, True
    while position + 12 <= len(data):
        length = struct.unpack_from(">I", data, position)[0]
        kind = data[position + 4:position + 8]
        end = position + 12 + length
        if end > len(data):
            raise ToolError("La captura PNG está incompleta.")
        payload = data[position + 8:position + 8 + length]
        expected = struct.unpack_from(">I", data, position + 8 + length)[0]
        if zlib.crc32(kind + payload) & 0xFFFFFFFF != expected:
            raise ToolError("La captura PNG tiene un error de integridad CRC.")
        if first:
            if kind != b"IHDR" or length != 13:
                raise ToolError("La cabecera PNG es inválida.")
            width, height = struct.unpack_from(">II", payload)
            if not 0 < width <= 32768 or not 0 < height <= 32768:
                raise ToolError("La resolución de la captura es inválida.")
            first = False
        if kind == b"IEND":
            if length:
                raise ToolError("El cierre PNG es inválido.")
            ended = True
            break
        position = end
    if not ended:
        raise ToolError("La captura PNG no tiene un cierre completo.")
    return {"format": "PNG", "width": width, "height": height}


def mp4_info(path: Path) -> dict:
    """Inspect MP4 metadata without reading the video payload into memory."""
    def boxes(handle: BinaryIO, start: int, end: int):
        position = start
        while position < end:
            if end - position < 8:
                raise ToolError("El contenedor MP4 está truncado.")
            handle.seek(position)
            length, kind = struct.unpack(">I4s", handle.read(8))
            header = 8
            if length == 1:
                extra = handle.read(8)
                if len(extra) != 8:
                    raise ToolError("La cabecera MP4 está incompleta.")
                length, header = struct.unpack(">Q", extra)[0], 16
            elif length == 0:
                length = end - position
            if length < header or position + length > end:
                raise ToolError("Se detectó un bloque MP4 inválido o incompleto.")
            yield kind, position + header, position + length
            position += length

    duration, tracks, dimensions, top = None, [], None, set()
    with path.open("rb") as handle:
        for kind, start, end in boxes(handle, 0, path.stat().st_size):
            top.add(kind)
            if kind != b"moov":
                continue
            for subtype, a, b in boxes(handle, start, end):
                if subtype == b"mvhd":
                    handle.seek(a)
                    header = handle.read(min(32, b - a))
                    if len(header) >= 20 and header[0] == 0:
                        scale, ticks = struct.unpack_from(">II", header, 12)
                    elif len(header) >= 32 and header[0] == 1:
                        scale = struct.unpack_from(">I", header, 20)[0]
                        ticks = struct.unpack_from(">Q", header, 24)[0]
                    else:
                        raise ToolError("La duración del MP4 no se puede interpretar.")
                    if scale:
                        duration = ticks / scale
                if subtype != b"trak":
                    continue
                handler, track_size = None, None
                for child, c, d in boxes(handle, a, b):
                    if child == b"tkhd" and d - c >= 8:
                        handle.seek(d - 8)
                        w, h = struct.unpack(">II", handle.read(8))
                        track_size = (w >> 16, h >> 16)
                    if child == b"mdia":
                        for leaf, e, f in boxes(handle, c, d):
                            if leaf == b"hdlr" and f - e >= 12:
                                handle.seek(e + 8)
                                handler = handle.read(4).decode("ascii", errors="replace")
                if handler:
                    tracks.append(handler)
                if handler == "vide" and track_size:
                    dimensions = track_size
    if not {b"ftyp", b"moov", b"mdat"} <= top or "vide" not in tracks:
        raise ToolError("No se encontró una grabación MP4 completa con pista de vídeo.")
    if duration is None or duration <= 0:
        raise ToolError("El MP4 no tiene una duración válida.")
    result = {"format": "MP4", "duration_seconds": round(duration, 3),
              "audio": "soun" in tracks, "tracks": tracks}
    if dimensions:
        result.update(width=dimensions[0], height=dimensions[1])
    return result


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for part in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(part)
    return digest.hexdigest()


def image_source(value: str) -> dict:
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        raise ToolError("Elige un archivo de imagen existente en tu computadora.")
    size_bytes = path.stat().st_size
    if not 0 < size_bytes <= 25 * 1024 * 1024:
        raise ToolError("La imagen debe ocupar entre 1 byte y 25 MiB.")
    with path.open("rb") as handle:
        header = handle.read(32)
    if header.startswith(b"\x89PNG\r\n\x1a\n"):
        png_info(path.read_bytes())
        mime, extension = "image/png", ".png"
    elif header.startswith(b"\xff\xd8\xff"):
        mime, extension = "image/jpeg", ".jpg"
    elif header.startswith((b"GIF87a", b"GIF89a")) and len(header) >= 13:
        mime, extension = "image/gif", ".gif"
    elif header.startswith(b"RIFF") and header[8:12] == b"WEBP":
        mime, extension = "image/webp", ".webp"
    else:
        raise ToolError("Formato no admitido. Elige una imagen PNG, JPEG, GIF o WebP.")
    return {"path": str(path), "bytes": size_bytes, "mime": mime, "extension": extension}


def foreground_activity(text: str):
    for label in ("topResumedActivity", "mResumedActivity", "ResumedActivity"):
        records = set()
        for body in re.findall(r"\b" + label + r"\s*[:=]\s*ActivityRecord\{([^}\r\n]+)\}", text):
            component = re.search(r"(?:^|\s)([A-Za-z0-9_.]+/[A-Za-z0-9_.$]+)(?=\s|$)", body)
            if component:
                records.add((body.split()[0], component[1]))
        if records:
            return next(iter(records)) if len(records) == 1 else None
    return None


def active_tool_image(text: str):
    foreground = foreground_activity(text)
    if foreground is None:
        return None
    token, component = foreground
    record = re.search(r"(?m)^\s*\*\s*Hist\s+#\d+:\s*ActivityRecord\{" + re.escape(token) + r"\s[^\r\n]*\}", text)
    if record is None:
        return None
    body = text[record.end():record.end()+8192]
    body = re.split(r"(?m)^\s*(?:\*\s*Hist\s+#|Running activities|mResumedActivity|ResumedActivity|Stack #)", body, maxsplit=1)[0]
    intent = re.search(r"(?m)^\s*(?:Intent\s*|intent=)\{([^\r\n]*)\}", body)
    if intent is None or "act=android.intent.action.VIEW" not in intent[1]:
        return None
    image = re.search(r"\bdat=file://((?:/sdcard/Pictures/TVBoxTools|/data/(?:user/\d+|data)/com\.dogo\.tvbox\.viewer/files)/imagen-[a-f0-9]{32}\.(?:png|jpg|gif|webp))(?=[\s}])", intent[1])
    target = re.search(r"\bcmp=([A-Za-z0-9_.]+/[A-Za-z0-9_.$]+)(?=[\s}])", intent[1])
    def expanded(value):
        package, activity = value.split("/", 1)
        return package + "/" + (package + activity if activity.startswith(".") else activity)
    if image is None or target is None or expanded(target[1]) != expanded(component):
        return None
    if image[1].startswith("/data/") and expanded(component) != "com.dogo.tvbox.viewer/com.dogo.tvbox.viewer.ViewerActivity":
        return None
    return {"record": token, "viewer": component, "remote_path": image[1]}


def publish(temporary: Path, destination: Path, overwrite: bool):
    """Publish without clobbering; support shared Android storage without hard links."""
    try:
        if overwrite:
            os.replace(temporary, destination)
        elif os.name == "nt":
            os.rename(temporary, destination)
        else:
            try:
                link = getattr(os, "link", None)
                if link is None:
                    raise OSError(errno.ENOSYS, "El intérprete no ofrece enlaces duros")
                link(temporary, destination)
            except OSError as error:
                if error.errno not in (errno.EPERM, errno.EOPNOTSUPP, errno.ENOSYS, errno.EXDEV):
                    raise
                # FUSE/exFAT may reject links. Exclusive creation still prevents overwrites.
                with temporary.open("rb") as source:
                    descriptor = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                    identity = os.fstat(descriptor)
                    try:
                        with os.fdopen(descriptor, "wb") as output:
                            shutil.copyfileobj(source, output)
                            output.flush()
                            os.fsync(output.fileno())
                    except BaseException:
                        with contextlib.suppress(OSError):
                            current = destination.stat()
                            if (current.st_dev, current.st_ino) == (identity.st_dev, identity.st_ino):
                                destination.unlink()
                        raise
            temporary.unlink()
    except FileExistsError as error:
        raise ToolError(f"El archivo ya existe: {destination}. Usa --overwrite para sustituirlo.") from error


def temporary_for(destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix="." + destination.name + ".", suffix=".part", dir=destination.parent)
    os.close(descriptor)
    return Path(name)


def load_config(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise ToolError(f"No se pudo leer la configuración {path}: {error}") from error
    if not isinstance(config, dict):
        raise ToolError("La configuración debe ser un objeto JSON.")
    for name in ("device", "output_dir", "adb", "scrcpy", "scrcpy_server", "stream_profile"):
        if name in config and config[name] is not None and not isinstance(config[name], str):
            raise ToolError(f"El campo de configuración '{name}' debe ser una cadena o null.")
    if config.get("stream_profile", "equilibrado") not in PROFILES:
        raise ToolError("stream_profile debe ser movil, fluido, equilibrado o nitido.")
    appearance_settings(config.get("appearance", {}))
    return config


def process_identity(pid: int) -> dict | None:
    """Linux process identity, including birth time to protect against PID reuse."""
    if not runtime.linux_processes():
        raise ToolError("Detener un directo desde otra sesión requiere Linux. Puedes cerrar su ventana o usar Ctrl+C.")
    if not isinstance(pid, int) or pid <= 1 or pid == os.getpid():
        return None
    directory = Path("/proc") / str(pid)
    try:
        stat = (directory / "stat").read_text()
        fields = stat[stat.rfind(")") + 2:].split()
        if len(fields) < 20 or fields[0] == "Z":
            return None
        command = (directory / "cmdline").read_bytes()
        if not command:
            return None
        return {"start_ticks": fields[19], "command_sha256": hashlib.sha256(command).hexdigest(),
                "owner_uid": directory.stat().st_uid,
                "argv": [os.fsdecode(value) for value in command.rstrip(b"\0").split(b"\0")]}
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        return None


def session_matches(record: dict, identity: dict | None) -> bool:
    if identity is None:
        return False
    expected = record.get("identity", {})
    if any(expected.get(key) != identity.get(key) for key in ("start_ticks", "command_sha256", "owner_uid")):
        return False
    if identity.get("owner_uid") != os.getuid():
        return False
    argv = identity.get("argv", [])
    marker = "[TVBOX:" + record["session_id"] + "]"
    return ("--serial=" + record["device"] in argv
            and any(value.startswith("--window-title=") and value.endswith(marker) for value in argv))


def normalize_mac(value: str) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.replace("-", ":").upper()
    if not re.fullmatch(r"(?:[0-9A-F]{2}:){5}[0-9A-F]{2}", value):
        return None
    if value == "00:00:00:00:00:00" or int(value[:2], 16) & 1:
        return None
    return value


def mac_address(value: str) -> str:
    normalized = normalize_mac(value.strip())
    if normalized is None:
        raise argparse.ArgumentTypeError("Introduce una MAC unicast válida, por ejemplo 2C:73:60:F1:78:D0.")
    return normalized


def local_networks(access=None) -> list[dict]:
    binary = shutil.which("ip")
    if not runtime.linux_processes() or not binary:
        raise ToolError("El descubrimiento por vecinos requiere iproute2. " + runtime.install_hint("ip"))
    def query(arguments):
        result = access.query(["-4", *arguments]) if access else subprocess.run([binary, "-j", "-4", *arguments], capture_output=True, timeout=10)
        if result.returncode:
            raise ToolError("No se pudo consultar la red local con iproute2. "
                            "En Android puede estar restringido; usa la opción 10 con subred manual "
                            "o discover --method tcp --network SUBRED.")
        try:
            data = json.loads(result.stdout)
            if not isinstance(data, list):
                raise ValueError("formato inesperado")
            return data
        except ValueError as error:
            raise ToolError("El comando ip no devuelve JSON compatible. " + runtime.install_hint("ip")) from error
    try:
        defaults = {route.get("dev") for route in query(["route", "show", "default"])}
    except ToolError:
        if runtime.android_host() and not access:
            fallback = network_access.wifi_networks()
            if fallback:
                return fallback
        raise
    links = {link["ifname"]: link for link in query(["link", "show"])}
    networks = []
    for interface in query(["addr", "show"]):
        if ("UP" not in interface.get("flags", []) or "LOOPBACK" in interface.get("flags", [])
                or "NO-CARRIER" in interface.get("flags", []) or "NOARP" in interface.get("flags", [])):
            continue
        for address in interface.get("addr_info", []):
            if address.get("scope") != "global":
                continue
            cidr = ipaddress.ip_network(f"{address['local']}/{address['prefixlen']}", strict=False)
            networks.append({"interface": interface["ifname"], "ip": address["local"],
                             "mac": normalize_mac(links.get(interface["ifname"], {}).get("address", "")),
                             "network": str(cidr), "default": interface["ifname"] in defaults})
    return sorted(networks, key=lambda item: (not item["default"], item["interface"]))


def network_scope(networks: list[dict], network: str | None, interface: str | None) -> tuple[dict, ipaddress.IPv4Network]:
    candidates = [item for item in networks if not interface or item["interface"] == interface]
    try:
        requested = ipaddress.IPv4Network(network, strict=False) if network else None
    except ValueError as error:
        raise ToolError("Usa una subred IPv4 válida, por ejemplo 192.168.0.0/24.") from error
    if requested:
        candidates = [item for item in candidates if requested.subnet_of(ipaddress.IPv4Network(item["network"]))]
    elif not interface:
        candidates = [item for item in candidates if item["default"]]
    if len(candidates) != 1:
        raise ToolError("No hay una red local inequívoca. Usa networks y elige --interface y/o --network.")
    selected = candidates[0]
    scope = requested or ipaddress.IPv4Network(selected["network"])
    if scope.num_addresses > 1024:
        raise ToolError("El descubrimiento admite hasta 1024 direcciones; indica una subred menor con --network.")
    return selected, scope


def local_ipv6_networks(access=None) -> list[dict]:
    binary = shutil.which("ip")
    if not runtime.linux_processes() or not binary:
        raise ToolError("El descubrimiento IPv6 requiere iproute2. " + runtime.install_hint("ip"))
    defaults = set()
    for family in ("-6", "-4"):
        routes = access.query([family, "route", "show", "default"]) if access else subprocess.run([binary, "-j", family, "route", "show", "default"], capture_output=True, timeout=10)
        if routes.returncode == 0:
            defaults.update(route.get("dev") for route in json.loads(routes.stdout))
    links = access.query(["link", "show"]) if access else subprocess.run([binary, "-j", "link", "show"], capture_output=True, timeout=10)
    macs = {link["ifname"]: normalize_mac(link.get("address", "")) for link in json.loads(links.stdout)} if links.returncode == 0 else {}
    result = access.query(["-6", "address", "show"]) if access else subprocess.run([binary, "-j", "-6", "address", "show"], capture_output=True, timeout=10)
    if result.returncode:
        if runtime.android_host() and not access:
            fallback = network_access.wifi_networks(ipv6=True)
            if fallback:
                return fallback
        raise ToolError("No se pudieron consultar las interfaces IPv6. Android puede restringir esa consulta; "
                        "puedes pegar una IPv6 conocida con %interfaz en las opciones 11 o 17.")
    networks = []
    for link in json.loads(result.stdout):
        flags = link.get("flags", [])
        if "UP" not in flags or "LOOPBACK" in flags or "NO-CARRIER" in flags or "NOARP" in flags:
            continue
        addresses = []
        for item in link.get("addr_info", []):
            if item.get("family") != "inet6" or any(item.get(flag) for flag in ("tentative", "dadfailed")):
                continue
            address = ipaddress.IPv6Address(item["local"])
            if address.is_loopback or address.is_multicast or address.is_unspecified:
                continue
            addresses.append({"ip": str(address), "prefixlen": item["prefixlen"]})
        if not addresses:
            continue
        addresses.sort(key=lambda item: not ipaddress.IPv6Address(item["ip"]).is_link_local)
        primary = addresses[0]
        networks.append({"interface": link["ifname"], "ip": primary["ip"],
                         "addresses": [item["ip"] for item in addresses],
                         "network": str(ipaddress.ip_network(f"{primary['ip']}/{primary['prefixlen']}", strict=False)),
                         "mac": macs.get(link["ifname"]), "default": link["ifname"] in defaults})
    return sorted(networks, key=lambda item: (not item["default"], item["interface"]))


def mac_vendors() -> dict[str, str]:
    candidates = [Path("/usr/share/nmap/nmap-mac-prefixes"), Path("/usr/local/share/nmap/nmap-mac-prefixes")]
    if os.environ.get("PREFIX"):
        candidates.insert(0, Path(os.environ["PREFIX"]) / "share/nmap/nmap-mac-prefixes")
    for path in candidates:
        if path.is_file():
            vendors = {}
            for line in path.read_text(errors="replace").splitlines():
                prefix, _, vendor = line.partition(" ")
                if re.fullmatch(r"[0-9A-Fa-f]{6}", prefix) and vendor.strip():
                    vendors[prefix.upper()] = vendor.strip()
            return vendors
    return {}


class App:
    def __init__(self, args: argparse.Namespace):
        runtime.prepare_environment()
        self.args = args
        self.version = VERSION
        UI.machine = args.json
        self.config_path = Path(args.config).expanduser().absolute()
        self.config = load_config(self.config_path)
        UI.configure(self.config.get("appearance", {}), theme=args.theme, mode=args.color)
        self.device = args.device or os.environ.get("TVBOX_DEVICE") or self.config.get("device")
        if self.device and (self.device.startswith("-") or re.search(r"\s", self.device)):
            raise ToolError("El identificador del dispositivo no puede contener espacios ni empezar por '-'.")
        raw_output = args.output_dir or self.config.get("output_dir") or runtime.default_output()
        self.output = Path(raw_output).expanduser()
        if not self.output.is_absolute():
            self.output = (Path.cwd() if args.output_dir else self.config_path.parent) / self.output
        self.output = self.output.absolute()
        self.output.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.log_path = self.output / "tvbox-tools.log"
        handler = RotatingFileHandler(self.log_path, maxBytes=2_000_000, backupCount=3, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        for previous in list(LOG.handlers):
            previous.close()
            LOG.removeHandler(previous)
        LOG.addHandler(handler)
        LOG.setLevel(logging.DEBUG if args.verbose else logging.INFO)
        if os.name != "nt":
            os.chmod(self.log_path, 0o600)
        self.adb = self.resolve_tool(args.adb or self.config.get("adb"), "adb", required=False)
        try:
            self.network_access = network_access.LocalADB(self.adb, self.config_path.parent / "network-adb.json")
        except network_access.NetworkError as error:
            raise ToolError(str(error)) from error
        self.session_dir = self.config_path.parent / ".tvbox-streams"
        self._stream_children: dict[str, subprocess.Popen] = {}
        self.discovered_hosts: list[dict] = []
        self.last_port_scan: dict | None = None
        self._network_fallback_reason = None

    def networks(self, ipv6=False):
        function = local_ipv6_networks if ipv6 else local_networks
        self._network_fallback_reason = None
        if runtime.android_host() and self.network_access.endpoint:
            try:
                return function(self.network_access)
            except network_access.NetworkError as error:
                # Changing Wi-Fi can invalidate the phone's wireless-debugging
                # port. Keep pairing data and try the phone's own permissions.
                self._network_fallback_reason = str(error)
        try:
            return function()
        except ToolError as error:
            if runtime.android_host() and ipv6:
                fallback = network_access.wifi_networks(ipv6=ipv6)
                if fallback:
                    return fallback
            if self._network_fallback_reason:
                raise ToolError("ADB local del teléfono está desconectado y la consulta básica tampoco está disponible. "
                                "Reconecta con 21 → 2 usando el puerto actual de depuración inalámbrica. "
                                "Detalle: " + str(error)) from error
            raise

    def network_neighbors(self, family, interface):
        if runtime.android_host() and self.network_access.endpoint and not self._network_fallback_reason:
            try:
                return self.network_access.query([family, "neigh", "show", "dev", interface])
            except network_access.NetworkError as error:
                self._network_fallback_reason = str(error)
        binary = shutil.which("ip")
        if not binary:
            return subprocess.CompletedProcess([], 1, b"", b"iproute2 unavailable")
        try:
            return subprocess.run([binary, "-j", family, "neigh", "show", "dev", interface],
                                  capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as error:
            if not runtime.android_host():
                raise
            return subprocess.CompletedProcess([], 1, b"", str(error).encode())

    @staticmethod
    def resolve_tool(value: str | None, name: str, required: bool = True) -> str | None:
        executable = shutil.which(str(Path(value).expanduser()) if value else name)
        if not executable and value:
            raise ToolError(f"No se puede ejecutar {name}: {value}")
        if not executable and name == "scrcpy" and not runtime.android_host():
            local = Path.home() / ".local/share/tvbox-audit-tools/media-local/usr/bin/scrcpy"
            if local.is_file() and os.access(local, os.X_OK):
                executable = str(local)
        if not executable and required:
            raise ToolError(f"No se encontró {name}. " + runtime.install_hint(name) + f" También puedes indicar --{name} RUTA.")
        return executable

    def note(self, message: str):
        LOG.info(message)
        if not self.args.json:
            UI.message(message)

    @staticmethod
    def map_tasks(items, function, **options):
        return parallel_tasks(items, function, **options)

    def run_adb(self, arguments: list[str], *, selected: bool = True,
                timeout: int = 15, check: bool = True) -> subprocess.CompletedProcess:
        if not self.adb:
            raise ToolError("ADB no está disponible. Instala Android Platform Tools o usa --adb RUTA.")
        command = [self.adb]
        if selected:
            if not self.device:
                raise ToolError("No se ha seleccionado un dispositivo.")
            command += ["-s", self.device]
        command += arguments
        LOG.debug("ADB %s", command)
        try:
            process = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout)
        except subprocess.TimeoutExpired as error:
            raise ToolError(f"ADB no respondió en {timeout} segundos. Revisa la red y el dispositivo.") from error
        if check and process.returncode:
            detail = (process.stderr or process.stdout).decode(errors="replace").strip()[-1500:]
            raise ToolError(f"ADB falló: {detail or 'sin información adicional'}")
        return process

    def appearance(self, theme=None, assignments=None, mode=None, reset=False) -> dict:
        config = load_config(self.config_path)
        settings = appearance_settings({} if reset else config.get("appearance", {}))
        if theme:
            settings.update(theme=theme, colors={})
        if mode:
            settings["mode"] = mode
        for assignment in assignments or []:
            role, separator, color = assignment.partition("=")
            if not separator or role not in BASE_THEME:
                raise ToolError("Usa ROL=COLOR, por ejemplo title=rosa o device=#FF8800.")
            color_code(color)
            settings["colors"][role] = color
        settings = appearance_settings(settings)
        changed = bool(theme or assignments or mode or reset)
        if changed:
            config["appearance"] = settings
            temporary = temporary_for(self.config_path)
            try:
                temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                publish(temporary, self.config_path, True)
            finally:
                temporary.unlink(missing_ok=True)
            self.config = config
            UI.configure(settings, mode=self.args.color)
        return {"operation": "appearance", "settings": settings, "saved": changed,
                "themes": list(THEMES), "available_colors": list(COLORS), "roles": ROLE_LABELS}

    def devices(self) -> list[dict]:
        text = self.run_adb(["devices", "-l"], selected=False).stdout.decode(errors="replace")
        devices = []
        for line in text.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 2:
                identity = self.network_access.identity
                if (runtime.android_host() and identity and
                        (parts[0] == self.network_access.endpoint or parts[0].startswith("adb-" + identity + "-"))):
                    continue
                devices.append({"serial": parts[0], "state": parts[1], "details": " ".join(parts[2:])})
        return devices

    def discover(self, network=None, interface=None, passive=False, method="auto", ports=None, timeout=0.5) -> dict:
        if method == "tcp":
            if passive or interface:
                raise ToolError("El descubrimiento TCP usa la ruta del sistema y no admite --passive ni --interface.")
            return self.discover_tcp(network, ports, timeout)
        try:
            selected, scope = network_scope(self.networks(), network, interface)
        except ToolError:
            if runtime.android_host() and not self.network_access.endpoint and network and not interface and not passive:
                self.note("Android no permite enumerar vecinos; se utilizará sondeo TCP de la subred indicada.")
                return self.discover_tcp(network, ports, timeout)
            raise
        binary = shutil.which("ip")
        ping = runtime.ping_executable()
        if not passive and not ping:
            if runtime.android_host():
                self.note("No hay ping disponible en Android; se utilizará descubrimiento TCP.")
                return self.discover_tcp(str(scope), ports, timeout)
            raise ToolError(runtime.install_hint("ping") + " O usa discover --passive para consultar vecinos.")
        responsive = set()
        if not passive:
            self.note(f"Buscando equipos en {scope} por {selected['interface']}…")
            def probe(address):
                host = str(address)
                if host == selected["ip"]:
                    return host
                try:
                    # Android denies SO_BINDTODEVICE to app UIDs. Binding the
                    # interface's verified source IPv4 needs no such capability.
                    binding = selected["ip"] if runtime.android_host() else selected["interface"]
                    result = subprocess.run([ping, "-n", "-c", "1", "-W", "1", "-I",
                                             binding, host],
                                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
                    return host if result.returncode == 0 else None
                except subprocess.TimeoutExpired:
                    return None
            responsive = {host for host in parallel_tasks(scope.hosts(), probe, label="Direcciones comprobadas") if host}
        result = self.network_neighbors("-4", selected["interface"])
        restricted = bool(result.returncode)
        if result.returncode:
            if runtime.android_host() and not passive:
                self.note("Android bloquea las MAC. Se conservan las respuestas ICMP; usa 21 para acceso ADB local.")
                result = subprocess.CompletedProcess([], 0, b"[]")
            else:
                raise ToolError("No se pudo consultar la tabla de vecinos. Android puede restringir ese acceso; usa la opción 21.")
        vendors, hosts = mac_vendors(), {}
        for entry in json.loads(result.stdout):
            try:
                address = ipaddress.IPv4Address(entry.get("dst", ""))
            except ValueError:
                continue
            mac = normalize_mac(entry.get("lladdr", ""))
            states = entry.get("state", [])
            if address not in scope or not mac or any(state in states for state in ("FAILED", "INCOMPLETE")):
                continue
            host = str(address)
            private = bool(int(mac[:2], 16) & 2)
            hosts[host] = {"ip": host, "mac": mac,
                           "vendor": None if private else vendors.get(mac.replace(":", "")[:6]),
                           "locally_administered_mac": private,
                           "evidence": "icmp_reply" if host in responsive else "neighbor_cache",
                           "neighbor_state": states, "is_local": False}
        for host in responsive:
            hosts.setdefault(host, {"ip": host, "mac": None, "vendor": None,
                                    "evidence": "icmp_reply", "is_local": False})
        if ipaddress.IPv4Address(selected["ip"]) in scope:
            hosts[selected["ip"]] = {"ip": selected["ip"], "mac": selected["mac"], "vendor": None,
                                     "evidence": "local_interface", "is_local": True}
        result = {"operation": "discover", "created_at": now(), "interface": selected["interface"],
                "network": str(scope), "mode": "passive" if passive else "icmp_and_neighbors",
                "hosts": sorted(hosts.values(), key=lambda host: ipaddress.IPv4Address(host["ip"])),
                "warnings": ["Una entrada en caché no confirma que el equipo siga conectado.",
                             "La MAC y su fabricante no confirman que el dispositivo sea un TV-box.",
                             "Algunos equipos no responden; las MAC solo son visibles en el mismo segmento local."]}
        fallback_reason = getattr(self, "_network_fallback_reason", None)
        result["network_access"] = "local_adb" if runtime.android_host() and self.network_access.endpoint and not fallback_reason else "native"
        result["mac_available"] = not restricted
        if fallback_reason:
            result["warnings"].append("ADB local del teléfono no está disponible: " + fallback_reason +
                                      ". Se utilizaron permisos básicos; reconecta con 21 → 2.")
        if restricted:
            result["warnings"].append("Android bloquea la tabla de MAC: configura acceso ADB local con la opción 21. Una MAC ausente no indica que el equipo esté desconectado.")
        self.discovered_hosts = result["hosts"]
        return result

    def discover_tcp(self, network, ports=None, timeout=0.5) -> dict:
        """Discover replies without raw sockets or access to Android neighbor tables."""
        if not network:
            raise ToolError("Indica tu subred Wi-Fi con --network CIDR; no se presupone que sea /24.")
        try:
            scope = ipaddress.IPv4Network(network, strict=False)
        except ValueError as error:
            raise ToolError("Introduce una subred IPv4 válida, por ejemplo 192.168.0.0/24.") from error
        if scope.num_addresses > 1024 or scope.is_multicast or scope.is_unspecified or scope.is_loopback:
            raise ToolError("Elige una subred local IPv4 de como máximo 1024 direcciones.")
        ports = ports if ports is not None else DISCOVERY_PORTS[:]
        if not ports or len(ports) > 16 or any(not 1 <= port <= 65535 for port in ports):
            raise ToolError("El descubrimiento TCP admite entre 1 y 16 puertos válidos por dirección.")
        # UDP connect only asks the kernel for a route; no datagram is sent.
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as route:
                route.connect((str(next(scope.hosts())), 9))
                source = ipaddress.IPv4Address(route.getsockname()[0])
        except OSError as error:
            raise ToolError("No se pudo verificar la ruta local. Revisa Wi-Fi y los permisos de red de la app Android.") from error
        if source not in scope:
            raise ToolError(f"La subred indicada no contiene la IP de salida {source}. Comprueba la subred Wi-Fi.")
        timeout = scan_timeout(str(timeout))
        self.note(f"Buscando respuestas TCP en {scope} · {len(ports)} puertos por dirección…")
        def probe(address):
            host = str(address)
            if address == source:
                return {"ip": host, "mac": None, "vendor": None, "is_local": True,
                        "evidence": "local_interface"}
            failures = []
            for port in ports:
                response = tcp_probe(host, port, timeout)
                if response["state"] in ("open", "closed"):
                    return {"ip": host, "mac": None, "vendor": None, "is_local": False,
                            "evidence": "tcp_response", "response_port": port,
                            "response_state": response["state"]}
                if response["state"] == "error":
                    failures.append(response)
            return {"_failure": {"ip": host, **failures[0]}} if failures else None
        observations = parallel_tasks(scope.hosts(), probe, workers=24, label="Direcciones TCP comprobadas")
        errors = [item["_failure"] for item in observations if item is not None and "_failure" in item]
        result = {"operation": "discover", "family": "IPv4", "created_at": now(),
                  "interface": None, "network": str(scope), "mode": "tcp_responses", "ports": ports,
                  "hosts": [item for item in observations if item is not None and "_failure" not in item],
                  "status": "partial" if errors else "completed", "errors": errors,
                  "warnings": ["Solo se muestran direcciones con respuesta TCP o la IP local; no garantiza descubrir todos los equipos.",
                               "Una respuesta puede ser un puerto abierto o rechazado; no identifica un servicio.",
                               "Este método no obtiene MAC ni fabricante y utiliza la ruta del sistema."]}
        if errors:
            result["warnings"].append(f"Hubo errores locales en {len(errors)} direcciones. Revisa los permisos de red de Android y los códigos en el resultado JSON.")
        self.discovered_hosts = result["hosts"]
        return result

    def discover_ipv6(self, interface=None, passive=False, networks=None) -> dict:
        networks = self.networks(ipv6=True) if networks is None else networks
        candidates = [item for item in networks if item["interface"] == interface] if interface else (
            [item for item in networks if item["default"]] or networks)
        if len(candidates) != 1:
            raise ToolError("Elige una interfaz IPv6 activa con --interface; consulta networks --ipv6.")
        selected = candidates[0]
        interface = selected["interface"]
        ping = runtime.ipv6_ping_command()
        if not passive and not ping and not runtime.android_host():
            raise ToolError(runtime.install_hint("ping") + " O utiliza discover --ipv6 --passive.")
        responsive = set()
        partial = False
        warnings = ["IPv6 permite descubrir vecinos aunque falle ARP/IPv4; depende de que IPv6 esté habilitado.",
                    "Se usan multicast y vecinos de la interfaz; no se recorren todas las direcciones de un /64.",
                    "Una entrada en caché no confirma conexión actual; algunos equipos no responden al sondeo."]
        if not passive and not ping:
            partial = True
            warnings.append("No hay ping IPv6 disponible. Se consultan los vecinos conocidos; usa 6 para revisar dependencias o 10 para IPv4.")
        if not passive and ping:
            self.note(f"Buscando vecinos IPv6 por {interface}…")
            try:
                probe = subprocess.run([*ping, "-n", "-c", "2", "-w", "3", "-I", interface,
                                        "ff02::1%" + interface], capture_output=True, text=True, timeout=5,
                                       env={**os.environ, "LC_ALL": "C"})
            except (OSError, subprocess.TimeoutExpired) as error:
                probe = subprocess.CompletedProcess([], 2, "", str(error))
            if probe.returncode not in (0, 1):
                if not runtime.android_host():
                    raise ToolError("No se pudo sondear IPv6: " + (probe.stderr.strip() or "revisa la interfaz y ping"))
                partial = True
                warnings.append("El sondeo multicast IPv6 no está disponible: " +
                                (probe.stderr.strip() or "revisa la interfaz y ping") +
                                ". Se conservan los vecinos conocidos; puedes usar 10 para IPv4.")
                ping = []
            for value in re.findall(r"bytes from ([^\s]+)", probe.stdout):
                try:
                    address = ipaddress.IPv6Address(value.removesuffix(":").split("%", 1)[0])
                except ValueError:
                    continue
                if not address.is_multicast and not address.is_unspecified and not address.is_loopback:
                    responsive.add(str(address))
            # A multicast reply can arrive before an NDP entry exists. Unicast
            # resolves that mapping through the kernel; never derive a MAC from IPv6.
            targets = sorted(responsive - set(selected["addresses"]), key=ipaddress.IPv6Address)
            if len(targets) > 256:
                warnings.append("La resolución de vecinos nuevos se limitó a 256 respuestas.")
            def resolve_neighbor(address):
                host = address + ("%" + interface if ipaddress.IPv6Address(address).is_link_local else "")
                try:
                    subprocess.run([*ping, "-n", "-c", "1", "-W", "1", "-I", interface, host],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
                except (OSError, subprocess.TimeoutExpired):
                    pass
            if ping:
                parallel_tasks(targets[:256], resolve_neighbor, label="Resolviendo vecinos IPv6")
        neighbors = self.network_neighbors("-6", interface)
        if neighbors.returncode:
            if runtime.android_host() and not passive:
                partial = True
                warnings.append("Android bloquea las MAC; se muestran respuestas multicast y direcciones locales. Configura acceso ADB local con la opción 21.")
                entries = []
            else:
                raise ToolError("No se pudo consultar la tabla de vecinos IPv6. Android puede restringir ese acceso.")
        else:
            entries = json.loads(neighbors.stdout)
        vendors, hosts = mac_vendors(), {}
        for entry in entries:
            try:
                address = ipaddress.IPv6Address(entry.get("dst", "").split("%", 1)[0])
            except ValueError:
                continue
            mac = normalize_mac(entry.get("lladdr", ""))
            states = entry.get("state", [])
            if (address.is_multicast or address.is_unspecified or address.is_loopback or not mac
                    or any(state in states for state in ("FAILED", "INCOMPLETE"))):
                continue
            private = bool(int(mac[:2], 16) & 2)
            hosts[str(address)] = {"ip": str(address) + ("%" + interface if address.is_link_local else ""),
                                   "mac": mac, "vendor": None if private else vendors.get(mac.replace(":", "")[:6]),
                                   "locally_administered_mac": private, "neighbor_state": states,
                                   "is_local": False, "evidence": "neighbor_cache"}
        local = set(selected["addresses"])
        if not passive and ping:
            pending = sorted(set(hosts) - responsive - local, key=ipaddress.IPv6Address)
            if len(pending) > 256:
                warnings.append("Se limitó la comprobación unicast a 256 vecinos; los demás conservan evidencia de caché.")
            def probe_neighbor(address):
                try:
                    result = subprocess.run([*ping, "-n", "-c", "1", "-W", "1", "-I", interface,
                                             hosts[address]["ip"]], stdout=subprocess.DEVNULL,
                                            stderr=subprocess.DEVNULL, timeout=2)
                    return address if result.returncode == 0 else None
                except (OSError, subprocess.TimeoutExpired):
                    return None
            responsive.update(address for address in parallel_tasks(pending[:256], probe_neighbor,
                               label="Vecinos IPv6 comprobados") if address)
        for address in responsive:
            parsed = ipaddress.IPv6Address(address)
            host = hosts.setdefault(address, {"ip": address + ("%" + interface if parsed.is_link_local else ""),
                                               "mac": None, "vendor": None, "is_local": False})
            host["evidence"] = "icmp_reply"
        for address in local:
            parsed = ipaddress.IPv6Address(address)
            hosts[address] = {"ip": address + ("%" + interface if parsed.is_link_local else ""),
                              "mac": selected["mac"], "vendor": None, "is_local": True,
                              "evidence": "local_interface"}
        fallback_reason = getattr(self, "_network_fallback_reason", None)
        if fallback_reason:
            partial = True
            warnings.append("ADB local del teléfono no está disponible: " + fallback_reason +
                            ". La búsqueda continúa con permisos básicos. Reconecta el teléfono con 21 → 2; "
                            "el puerto puede cambiar al cambiar de Wi-Fi.")
        if not any(not host["is_local"] for host in hosts.values()):
            warnings.append("Solo se detectaron direcciones de este equipo. No confirma que la TV-box esté apagada: "
                            "la red puede bloquear multicast o aislar clientes. Prueba 10 para IPv4 y comprueba que ambos estén en la misma red local.")
        result = {"operation": "discover", "family": "IPv6", "created_at": now(), "interface": interface,
                  "network": selected["network"], "mode": "passive" if passive else "icmpv6_and_neighbors",
                  "status": "partial" if partial else "completed",
                  "hosts": [hosts[address] for address in sorted(hosts, key=ipaddress.IPv6Address)],
                  "warnings": warnings}
        result["network_access"] = "local_adb" if runtime.android_host() and self.network_access.endpoint and not fallback_reason else "native"
        result["mac_available"] = not neighbors.returncode
        self.discovered_hosts = result["hosts"]
        return result

    def find_mac(self, mac=None, network=None, interface=None, passive=False, select=False, port=None, connect=False, ipv6=False):
        saved = self.config.get("selected_target") or {}
        if not isinstance(saved, dict):
            saved = {}
        target = normalize_mac(mac or saved.get("mac") or "")
        if target is None:
            raise ToolError("Indica una MAC válida; no hay una MAC guardada para buscar.")
        if connect and not select:
            raise ToolError("--connect requiere --select para actualizar la selección de forma explícita.")
        if ipv6 and network:
            raise ToolError("La búsqueda MAC por IPv6 usa la interfaz local; no admite subred IPv4.")
        discovery = self.discover_ipv6(interface, passive) if ipv6 else self.discover(network, interface, passive)
        if discovery.get("mac_available") is False or discovery.get("mode") == "tcp_responses":
            raise ToolError("Android bloquea las MAC. Configura el acceso ADB local en la opción 21 antes de buscar por MAC.")
        matches = [host for host in discovery["hosts"] if host.get("mac") == target]
        fresh = [host for host in matches if host["evidence"] == "icmp_reply" and not host["is_local"]]
        status = "ambiguous" if len(matches) > 1 else "found" if fresh else "cached" if matches else "not_found"
        result = {"operation": "find-mac", "mac": target, "status": status,
                  "network": discovery["network"], "interface": discovery["interface"], "matches": matches,
                  "selected": False, "warnings": discovery["warnings"] + [
                      "La MAC puede cambiar entre Wi-Fi y Ethernet, aleatorizarse o suplantarse; no es autenticación."]}
        if select:
            if status != "found":
                raise ToolError("No hay una coincidencia única con respuesta actual. No se modificó la selección. "
                                "Consulta find-mac sin --select para ver caché o coincidencias ambiguas.")
            default_port = saved.get("port", 5555) if normalize_mac(saved.get("mac") or "") == target else 5555
            chosen_port = port if port is not None else default_port
            result["selection"] = self.select_target(fresh[0]["ip"], chosen_port, connect=connect, mac=target)
            result["selected"] = True
        return result

    def scan_ports(self, ports: list[int], timeout: float = 1.0, save_report: bool = True,
                   host: str | None = None, interface: str | None = None) -> dict:
        explicit_host = host is not None
        host = ip_host(host, interface) if explicit_host else device_ip(self.device, interface)
        if (not ports or len(ports) > 4096 or any(type(port) is not int or not 1 <= port <= 65535 for port in ports)
                or not 0.1 <= timeout <= 10):
            raise ToolError("Puertos o tiempo de espera inválidos.")
        ports = sorted(set(ports))
        self.note(f"Comprobando {len(ports)} puertos TCP de {host}…")
        started = time.monotonic()
        results = parallel_tasks(ports, lambda port: tcp_probe(host, port, timeout), label="Puertos comprobados")
        result = {"operation": "port-scan", "created_at": now(), "tool_version": VERSION,
                  "tool_name": APP_NAME, "author": AUTHOR,
                  "device": host if explicit_host else self.device, "ip": host,
                  "family": "IPv6" if ":" in host else "IPv4", "method": "tcp_connect", "timeout_seconds": timeout,
                  "elapsed_seconds": round(time.monotonic() - started, 3), "ports": results,
                  "summary": {state: sum(item["state"] == state for item in results)
                              for state in ("open", "closed", "no_response", "unreachable", "error")},
                  "warnings": ["Sin respuesta no confirma filtrado: puede haber pérdida de red o un equipo apagado.",
                               "Un puerto abierto no identifica el servicio, su versión ni una vulnerabilidad."]}
        self.last_port_scan = result
        if not save_report:
            return result
        path = self.destination(None, ".json", False)
        result["report_path"] = str(path)
        temporary = temporary_for(path)
        try:
            temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            publish(temporary, path, False)
        finally:
            temporary.unlink(missing_ok=True)
        return result

    def select_target(self, address: str, port: int = 5555, connect: bool = True, mac=None, interface=None) -> dict:
        host = ip_host(address, interface)
        target = adb_address(host, port)
        # Commit the selection only after ADB has verified a requested connection.
        previous_device = self.device
        try:
            if connect:
                self.connect(target)
            config = load_config(self.config_path)
            config["device"] = target
            config["selected_target"] = {"ip": host, "port": port, "mac": normalize_mac(mac or ""),
                                         "family": "IPv6" if ":" in host else "IPv4", "selected_at": now()}
            temporary = temporary_for(self.config_path)
            try:
                temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                publish(temporary, self.config_path, True)
            finally:
                temporary.unlink(missing_ok=True)
        except BaseException:
            self.device = previous_device
            raise
        self.config, self.device = config, target
        return {"operation": "select", "device": target, "connected": connect,
                "saved_to": str(self.config_path), "mac": config["selected_target"]["mac"]}

    def connect(self, address: str, interface=None, timeout=20) -> dict:
        address = normalize_adb_address(address, interface)
        response = self.run_adb(["connect", address], selected=False, timeout=timeout, check=False).stdout.decode(errors="replace").strip()
        state = self.run_adb(["-s", address, "get-state"], selected=False, timeout=min(timeout, 15), check=False)
        if state.returncode or state.stdout.strip() != b"device":
            detail = state.stderr.decode(errors="replace").strip() or state.stdout.decode(errors="replace").strip()
            if "unauthorized" in (detail + response).lower():
                raise ToolError("ADB requiere autorización. Acepta la clave de esta computadora en la pantalla del dispositivo y vuelve a conectar.")
            raise ToolError(f"No se pudo verificar la conexión ADB: {response or detail or 'dispositivo no disponible'}")
        self.device = address
        return {"device": address, "state": "device", "message": response}

    def adb_ipv4_target(self, host, mac=None):
        """Find an IPv4 neighbor of the selected IPv6 peer on the same interface."""
        base, _, interface = host.partition("%")
        if not interface:
            raise ToolError("El servicio 5000 no responde por IPv6. Usa 10 para elegir la IPv4 del TV-box.")
        if interface.isdecimal():
            interface = socket.if_indextoname(int(interface))

        def neighbors(family):
            result = self.network_neighbors(family, interface)
            if result.returncode:
                raise ToolError("No se pudo comprobar la MAC para buscar la IPv4. Usa 10 para elegir la IPv4; en Android revisa también 21.")
            try:
                return json.loads(result.stdout)
            except (ValueError, TypeError) as error:
                raise ToolError("No se pudo leer la tabla de vecinos para buscar la IPv4 del equipo.") from error

        def usable(entry):
            return not any(state in entry.get("state", []) for state in ("FAILED", "INCOMPLETE"))

        row = next((item for item in self.discovered_hosts if item["ip"] == host), {})
        expected = normalize_mac(mac or row.get("mac") or "")
        current = {normalize_mac(entry.get("lladdr", "")) for entry in neighbors("-6")
                   if entry.get("dst", "").split("%", 1)[0] == base and usable(entry)} - {None}
        if len(current) > 1 or expected and current and expected not in current:
            raise ToolError("La MAC de la IPv6 elegida cambió. Repite el descubrimiento antes de activar ADB.")
        expected = expected or next(iter(current), None)
        if not expected:
            raise ToolError("No hay una MAC comprobable para relacionar esta IPv6 con una IPv4. Usa 10 y elige la IPv4 del TV-box.")

        def ipv4(value):
            try:
                address = ipaddress.IPv4Address(value)
            except (ValueError, TypeError):
                return None
            return str(address) if not (address.is_loopback or address.is_multicast or address.is_unspecified) else None

        entries = neighbors("-4")
        candidates = {ipv4(entry.get("dst")) for entry in entries
                      if normalize_mac(entry.get("lladdr", "")) == expected and usable(entry)} - {None}
        saved = self.config.get("selected_target") or {}
        for item in [saved, *self.discovered_hosts]:
            candidate = ipv4(item.get("ip"))
            if candidate and normalize_mac(item.get("mac") or "") == expected and not item.get("is_local"):
                candidates.add(candidate)
        if not candidates:
            self.note(f"Buscando la IPv4 de MAC {expected} por {interface}…")
            original_hosts = self.discovered_hosts
            try:
                discovery = self.discover(interface=interface)
            finally:
                self.discovered_hosts = original_hosts
            candidates = {ipv4(item.get("ip")) for item in discovery["hosts"]
                          if normalize_mac(item.get("mac") or "") == expected and not item.get("is_local")} - {None}
        if len(candidates) > 8:
            raise ToolError("Hay demasiadas IPv4 asociadas a esa MAC. Usa 10 y elige una IPv4 concreta.")
        verified = []
        for candidate in sorted(candidates, key=ipaddress.IPv4Address):
            # Refresh the neighbor mapping through a read-only TCP probe before
            # sending any activation command to a remembered DHCP address.
            response = tcp_probe(candidate, 5555, 0.5)
            if response["state"] not in ("open", "closed"):
                response = tcp_probe(candidate, 5000, 0.5)
            if response["state"] not in ("open", "closed"):
                continue
            mapping = [entry for entry in neighbors("-4") if entry.get("dst") == candidate and usable(entry)]
            if mapping and all(normalize_mac(entry.get("lladdr", "")) == expected for entry in mapping):
                verified.append(candidate)
        if len(verified) > 1:
            raise ToolError("Hay varias IPv4 con esa MAC: " + ", ".join(verified) + ". Elige la IPv4 concreta con 26.")
        if not verified:
            raise ToolError("El servicio 5000 no responde por IPv6 y no encontré una IPv4 con la misma MAC y respuesta actual. Usa 10 para buscar la IPv4 del TV-box.")
        return verified[0], expected

    def enable_adb(self, address=None, interface=None, timeout=20, save=True, mac=None) -> dict:
        from tvbox_adb_bootstrap import ADB_PORT, SERVICE_PORT, BootstrapError, register_adb
        host = ip_host(address, interface) if address else device_ip(self.device, interface)
        if type(timeout) is not int or not 1 <= timeout <= 60:
            raise ToolError("La espera de activación ADB debe estar entre 1 y 60 segundos.")
        if not self.adb:
            raise ToolError("Instala ADB antes de activar el acceso remoto. " + runtime.install_hint("adb"))
        target, previous = adb_address(host, ADB_PORT), self.device
        result = {"operation": "enable-adb", "ip": host, "device": target,
                  "requested_ip": host, "ipv4_fallback": False,
                  "service_port": SERVICE_PORT, "adb_port": ADB_PORT,
                  "task_registered": False, "task_existing": False, "saved": False, "warnings": []}
        try:
            available = tcp_probe(host, ADB_PORT, 1.0)["state"] == "open"
            if not available and ":" in host and tcp_probe(host, SERVICE_PORT, 1.0)["state"] != "open":
                self.note("El servicio 5000 no responde por IPv6. Buscando la IPv4 del mismo equipo…")
                host, mac = self.adb_ipv4_target(host, mac)
                target = adb_address(host, ADB_PORT)
                result.update(ip=host, device=target, ipv4_fallback=True, mac=mac)
                self.note(f"IPv4 comprobada: {host} · MAC {mac}")
                available = tcp_probe(host, ADB_PORT, 1.0)["state"] == "open"
            result["already_available"] = available
            if not available:
                self.note(f"Consultando el servicio TCP {SERVICE_PORT} de {host} para activar ADB…")
                try:
                    result.update(register_adb(host, timeout=2.0))
                except BootstrapError as error:
                    raise ToolError(str(error)) from error
                result["warnings"].append("La tarea de activación reside en memoria; comprueba ADB tras reiniciar el TV-box o el servicio 5000.")
                self.note(f"Esperando ADB en {target} (hasta {timeout} segundos)…")
                deadline = time.monotonic() + timeout
                while time.monotonic() < deadline:
                    remaining = max(0.001, deadline - time.monotonic())
                    if tcp_probe(host, ADB_PORT, min(0.5, remaining))["state"] == "open":
                        break
                    time.sleep(min(0.5, max(0.0, deadline - time.monotonic())))
                else:
                    raise ToolError(f"La tarea ADB quedó registrada en el servicio 5000, pero {target} no abrió en {timeout} segundos. "
                                    "El registro permanece; puedes volver a comprobar la conexión sin duplicarlo.")
            self.connect(target, timeout=min(timeout, 5))
            if save:
                saved = self.config.get("selected_target", {})
                mac = mac or next((item.get("mac") for item in self.discovered_hosts if item["ip"] == host), None)
                if not mac and saved.get("ip") == host:
                    mac = saved.get("mac")
                selection = self.select_target(host, ADB_PORT, connect=True, mac=mac)
                result.update(saved=True, saved_to=selection["saved_to"])
            result["state"] = "device"
            return result
        except BaseException:
            self.device = previous
            raise

    def ensure_device(self):
        if not self.device:
            available = [item for item in self.devices() if item["state"] == "device"]
            if len(available) != 1:
                raise ToolError("Selecciona un dispositivo con --device SERIAL. Usa 'devices' para listar los disponibles.")
            self.device = available[0]["serial"]
        try:
            state = self.run_adb(["get-state"], check=False)
        except ToolError as error:
            state = subprocess.CompletedProcess([], 1, b"", str(error).encode())
        if state.returncode or state.stdout.strip() != b"device":
            if b"unauthorized" in state.stderr + state.stdout:
                raise ToolError("ADB requiere autorización en la pantalla del equipo.")
            from tvbox_equipment import recover
            if recover(self):
                return
            if ":" in self.device:
                self.connect(self.device)
            else:
                raise ToolError("El dispositivo no está conectado o requiere autorización ADB en pantalla.")
        from tvbox_equipment import active, verified
        item = active(self)
        if item:
            verified(self, item)

    def interactive_shell(self) -> dict:
        if self.args.json or not sys.stdin.isatty() or not sys.stdout.isatty():
            raise ToolError("La shell interactiva requiere una terminal de entrada/salida y no admite --json.")
        self.ensure_device()
        self.note(f"Abriendo shell ADB en {self.device}. Escribe exit o pulsa Ctrl+D para salir.")
        snapshot = terminal_snapshot()
        try:
            with unframed_terminal():
                try:
                    code = framed_shell([self.adb, "-s", self.device, "shell", "-t"],
                                        f"{APP_NAME} · Shell ADB · {SIGNATURE}",
                                        border=color_spec(UI, "border") or "default")
                except RuntimeError as error:
                    raise ToolError(str(error)) from error
        finally:
            restore_terminal(snapshot)
        LOG.info("Shell ADB cerrada: dispositivo=%s, código=%s", self.device, code)
        return {"operation": "adb-shell", "device": self.device, "exit_code": code}

    def image_viewers(self, mime: str) -> list[str]:
        result = self.run_adb(["shell", "cmd", "package", "query-activities", "--brief",
                               "-a", "android.intent.action.VIEW", "-t", mime,
                               "-d", "file:///sdcard/Pictures/tvbox-image"], check=False)
        if result.returncode:
            raise ToolError("No se pudieron consultar los visores de imágenes del dispositivo.")
        viewers = []
        for line in result.stdout.decode(errors="replace").splitlines():
            component = line.strip()
            if (re.fullmatch(r"[A-Za-z0-9_.]+/[A-Za-z0-9_.$]+", component)
                    and not component.startswith("android/") and component not in viewers):
                viewers.append(component)
        return viewers

    def show_image(self, value: str, viewer: str | None = None) -> dict:
        source = image_source(value)
        self.ensure_device()
        if viewer is None:
            import tvbox_image_viewer
            try:
                return tvbox_image_viewer.show(self, source)
            except tvbox_image_viewer.ViewerError as error:
                raise ToolError(str(error)) from error
        viewers = self.image_viewers(source["mime"])
        if not viewers:
            raise ToolError("No se encontró un visor compatible con esta imagen en el TV-box.")
        if viewer is not None and viewer not in viewers:
            raise ToolError("El visor elegido no está entre las actividades compatibles del dispositivo.")
        viewer = viewer or viewers[0]
        remote_dir = "/sdcard/Pictures/TVBoxTools"
        remote = remote_dir + "/imagen-" + uuid.uuid4().hex + source["extension"]
        uri = "file://" + remote
        self.note(f"Enviando imagen a {self.device}…")
        self.run_adb(["shell", "mkdir", "-p", remote_dir])
        try:
            self.run_adb(["push", source["path"], remote], timeout=60)
            opened = self.run_adb(["shell", "am", "start", "-W", "-a", "android.intent.action.VIEW",
                                   "-d", uri, "-t", source["mime"], "-n", shlex.quote(viewer)],
                                  timeout=20, check=False)
            output = (opened.stdout + opened.stderr).decode(errors="replace")
            if opened.returncode or "Exception" in output or "Error:" in output or not re.search(r"(?m)^\s*Status:\s*ok\s*$", output):
                raise ToolError("Android no confirmó la apertura de la imagen: " + output.strip()[-1200:])
        except BaseException:
            with contextlib.suppress(OSError, ToolError):
                self.run_adb(["shell", "rm", "-f", remote], check=False, timeout=5)
            raise
        return {"operation": "show-image", "device": self.device, "source_path": source["path"],
                "bytes": source["bytes"], "mime": source["mime"], "remote_path": remote,
                "viewer": viewer, "state": "viewer_opened"}

    def hide_image(self) -> dict:
        self.ensure_device()
        def snapshot():
            return self.run_adb(["shell", "dumpsys", "activity", "activities"], timeout=10).stdout.decode(errors="replace")
        image = active_tool_image(snapshot())
        if image is None:
            return {"operation": "hide-image", "device": self.device, "state": "not_active"}
        for navigation, key in (("back", "KEYCODE_BACK"), ("home", "KEYCODE_HOME")):
            self.run_adb(["shell", "input", "keyevent", key])
            last = ""
            for _ in range(3):
                time.sleep(0.3)
                last = snapshot()
                if foreground_activity(last) is not None and active_tool_image(last) is None:
                    return {"operation": "hide-image", "device": self.device, "state": "hidden",
                            "navigation": navigation, "remote_path": image["remote_path"]}
            if active_tool_image(last) is None:
                break
        raise ToolError("No se pudo confirmar que la imagen saliera del primer plano. Revisa la pantalla del TV-box.")

    def status(self) -> dict:
        self.ensure_device()
        info = {"device": self.device, "state": "device", "output_dir": str(self.output)}
        for field, prop in [("model", "ro.product.model"), ("android_release", "ro.build.version.release"),
                            ("api_level", "ro.build.version.sdk"), ("security_patch", "ro.build.version.security_patch")]:
            info[field] = self.run_adb(["shell", "getprop", prop]).stdout.decode(errors="replace").strip()
        return info

    def destination(self, given: str | None, extension: str, overwrite: bool) -> Path:
        if given:
            path = Path(given).expanduser().absolute()
            if path.suffix.lower() != extension:
                raise ToolError(f"El archivo de salida debe terminar en {extension}.")
        else:
            stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            path = self.output / (f"tvbox-{stamp}-{uuid.uuid4().hex[:6]}" + extension)
        if path.is_symlink():
            raise ToolError("La salida no puede ser un enlace simbólico.")
        if path.exists() and (not overwrite or not path.is_file()):
            raise ToolError(f"La salida ya existe: {path}. Usa --overwrite para sustituir un archivo.")
        return path

    def finish_file(self, path: Path, operation: str, info: dict, metadata: bool, overwrite: bool) -> dict:
        result = {"operation": operation, "created_at": now(), "tool_version": VERSION,
                  "tool_name": APP_NAME, "author": AUTHOR,
                  "device": self.device, "path": str(path), "bytes": path.stat().st_size,
                  "sha256": file_hash(path), **info}
        if metadata:
            sidecar = path.with_suffix(path.suffix + ".json")
            temporary = temporary_for(sidecar)
            try:
                temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                publish(temporary, sidecar, overwrite)
                result["metadata_path"] = str(sidecar)
            except OSError as error:
                result["metadata_warning"] = str(error)
            except ToolError as error:
                result["metadata_warning"] = str(error)
            finally:
                temporary.unlink(missing_ok=True)
        return result

    def capture(self, args: argparse.Namespace) -> dict:
        self.ensure_device()
        path = self.destination(args.file, ".png", args.overwrite)
        self.note("Obteniendo captura de pantalla…")
        data = self.run_adb(["exec-out", "screencap", "-p"], timeout=25).stdout
        info = png_info(data)
        temporary = temporary_for(path)
        try:
            with temporary.open("wb") as output:
                output.write(data)
                output.flush()
                os.fsync(output.fileno())
            publish(temporary, path, args.overwrite)
        finally:
            temporary.unlink(missing_ok=True)
        return self.finish_file(path, "capture", info, not args.no_metadata, args.overwrite)

    def stop_recording(self, pid_file: str, remote_file: str) -> bool:
        """Stop only our encoder, checking its unique output path before signaling."""
        pid = self.run_adb(["shell", "cat", pid_file], check=False, timeout=5).stdout.strip()
        if not re.fullmatch(rb"[1-9][0-9]*", pid):
            return False
        command_line = self.run_adb(["shell", "cat", "/proc/" + pid.decode() + "/cmdline"],
                                    check=False, timeout=5)
        if command_line.returncode:
            return False
        if remote_file.encode() not in command_line.stdout.split(b"\0"):
            raise ToolError("No se detuvo el proceso: su identidad ya no coincide con esta grabación.")
        self.run_adb(["shell", "kill", "-INT", pid.decode()], timeout=5)
        return True

    def record(self, args: argparse.Namespace) -> dict:
        self.ensure_device()
        path = self.destination(args.file, ".mp4", args.overwrite)
        token = uuid.uuid4().hex
        remote = f"/data/local/tmp/tvbox-tools-{token}.mp4"
        pid_file = f"/data/local/tmp/tvbox-tools-{token}.pid"
        width, height = args.size
        command = shlex.join(["screenrecord", "--time-limit", str(args.duration), "--size", f"{width}x{height}",
                              "--bit-rate", str(args.bitrate), remote])
        script = ("umask 077; " + command + " & TVBOX_RECORD_PID=$!; printf '%s' \"$TVBOX_RECORD_PID\" > "
                  + shlex.quote(pid_file) + "; wait \"$TVBOX_RECORD_PID\"")
        self.note(f"Grabando {args.duration} segundos, {width}×{height}, {args.bitrate / 1_000_000:g} Mbps. Ctrl+C cancela.")
        process = subprocess.Popen([self.adb, "-s", self.device, "shell", script], stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=(os.name != "nt"))
        committed, cancelled, temporary = False, False, None
        warnings = []
        try:
            try:
                stdout, stderr = process.communicate(timeout=args.duration + 25)
            except (KeyboardInterrupt, subprocess.TimeoutExpired) as error:
                cancelled = isinstance(error, KeyboardInterrupt)
                self.note("Deteniendo la grabación de esta sesión…")
                with contextlib.suppress(ToolError):
                    self.stop_recording(pid_file, remote)
                try:
                    process.communicate(timeout=8)
                except subprocess.TimeoutExpired:
                    process.terminate()
                    process.communicate(timeout=5)
                raise ToolError("Grabación cancelada." if cancelled else "El grabador excedió su tiempo de espera.",
                                130 if cancelled else 1) from error
            if process.returncode:
                detail = (stderr or stdout).decode(errors="replace").strip()[-1500:]
                raise ToolError(f"El grabador del dispositivo falló: {detail}. Si otro directo usa el codificador, ciérralo y vuelve a intentar.")
            temporary = temporary_for(path)
            self.note("Transfiriendo y validando el vídeo…")
            self.run_adb(["pull", remote, str(temporary)], timeout=max(30, args.duration))
            info = mp4_info(temporary)
            publish(temporary, path, args.overwrite)
            committed = True
        except BaseException:
            if not cancelled:
                self.note(f"Si se generó un vídeo remoto, se conserva para recuperación en {remote}")
            raise
        finally:
            if process.poll() is None:
                with contextlib.suppress(Exception):
                    self.stop_recording(pid_file, remote)
                try:
                    process.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    process.terminate()
                    with contextlib.suppress(subprocess.TimeoutExpired):
                        process.communicate(timeout=5)
            if temporary is not None:
                temporary.unlink(missing_ok=True)
            remove = [pid_file] + ([remote] if committed or cancelled else [])
            try:
                self.run_adb(["shell", "rm", "-f", *remove], timeout=8)
            except ToolError as error:
                warnings.append("No se pudieron limpiar los temporales: " + str(error))
        info.update(requested_seconds=args.duration, temporary_device_copy_removed=not warnings)
        if abs(info["duration_seconds"] - args.duration) > 2:
            warnings.append("La duración del contenedor difiere de la solicitada; una pantalla estática puede producir menos cuadros.")
        if warnings:
            info["warnings"] = warnings
        return self.finish_file(path, "record", info, not args.no_metadata, args.overwrite)

    def scrcpy_setup(self) -> tuple[str, dict]:
        binary = self.resolve_tool(self.args.scrcpy or self.config.get("scrcpy"), "scrcpy")
        env = os.environ.copy()
        local = Path.home() / ".local/share/tvbox-audit-tools"
        if not runtime.android_host() and str(Path(binary).resolve()).startswith(str((local / "media-local").resolve()) + os.sep):
            libraries = local / "media-local/usr/lib/x86_64-linux-gnu"
            env["LD_LIBRARY_PATH"] = str(libraries) + (os.pathsep + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
            icon = local / "media-local/usr/share/icons/hicolor/256x256/apps"
            if icon.exists():
                env["SCRCPY_ICON_DIR"] = str(icon)
            server = local / "scrcpy-server-v4.1"
            if server.exists():
                env["SCRCPY_SERVER_PATH"] = str(server)
        configured = self.args.scrcpy_server or self.config.get("scrcpy_server")
        if configured:
            server = Path(configured).expanduser().absolute()
            if not server.is_file():
                raise ToolError(f"No existe el servidor de scrcpy: {server}")
            env["SCRCPY_SERVER_PATH"] = str(server)
        if self.adb:
            env["ADB"] = self.adb
        try:
            version = subprocess.run([binary, "--version"], env=env, capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as error:
            raise ToolError(f"No se pudo iniciar scrcpy: {error}") from error
        if version.returncode:
            raise ToolError("scrcpy no pudo cargar sus dependencias: " + version.stderr.decode(errors="replace")[-1000:])
        match = re.search(rb"scrcpy\s+(\d+)\.", version.stdout + version.stderr)
        if not match or int(match[1]) < 2:
            raise ToolError("Se necesita scrcpy 2.0 o posterior para estas opciones.")
        return binary, env

    def stream_command(self, args: argparse.Namespace, binary: str) -> tuple[list[str], dict]:
        profile = dict(PROFILES[args.profile])
        saved = self.stream_quality()
        if saved["profile"] == args.profile:
            profile.update({key: saved[key] for key in profile})
        for key in ("max_size", "fps", "bitrate"):
            if getattr(args, key, None) is not None:
                profile[key] = getattr(args, key)
        width, height = args.window_size
        command = [binary, "--serial=" + self.device, "--no-audio", "--no-control", "--no-clipboard-autosync",
                   "--max-size=" + str(profile["max_size"]), "--max-fps=" + str(profile["fps"]),
                   "--video-bit-rate=" + str(profile["bitrate"]), "--window-title=" + args.title,
                   "--window-width=" + str(width), "--window-height=" + str(height), "--print-fps"]
        if runtime.android_host():
            command += ["--fullscreen", "--render-driver=software"]
        return command, profile

    def _session_path(self, session_id: str) -> Path:
        if not re.fullmatch(r"[a-f0-9]{32}", session_id):
            raise ToolError("El identificador de sesión no es válido.")
        return self.session_dir / (session_id + ".json")

    def _save_session(self, record: dict):
        self.session_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(self.session_dir, 0o700)
        path = self._session_path(record["session_id"])
        temporary = temporary_for(path)
        try:
            temporary.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
            publish(temporary, path, False)
        finally:
            temporary.unlink(missing_ok=True)

    def _session_records(self) -> list[dict]:
        records = []
        if not self.session_dir.exists():
            return records
        for path in self.session_dir.glob("*.json"):
            if path.is_symlink() or not re.fullmatch(r"[a-f0-9]{32}", path.stem):
                continue
            try:
                if path.stat().st_size > 16_384:
                    continue
                record = json.loads(path.read_text(encoding="utf-8"))
                if (record.get("session_id") == path.stem and isinstance(record.get("pid"), int)
                        and isinstance(record.get("device"), str) and isinstance(record.get("identity"), dict)):
                    records.append(record)
            except (OSError, ValueError, AttributeError):
                LOG.warning("Registro de directo no interpretable: %s", path)
        return records

    @staticmethod
    def _public_session(record: dict) -> dict:
        result = {key: value for key, value in record.items() if key != "identity"}
        stats = tvbox_video.statistics(record.get("log_path", ""))
        if stats:
            result["video_stats"] = stats
        return result

    def stream_quality(self):
        from tvbox_equipment import quality
        return quality(self)

    def compatibility(self, encoders=False):
        result = {"operation": "compatibility", "device": self.device, "checks": {}, "warnings": []}
        for name, function in (("adb", self.ensure_device), ("capture", lambda: png_info(self.run_adb(["exec-out", "screencap", "-p"], timeout=15).stdout))):
            try:
                value = function()
                result["checks"][name] = {"available": True, "detail": value}
            except (ToolError, OSError, ValueError) as error:
                result["checks"][name] = {"available": False, "reason": str(error)}
                if name == "adb":
                    break
        result["device"] = self.device
        try:
            binary, env = self.scrcpy_setup()
            result["checks"]["scrcpy"] = {"available": True, "path": binary}
            if encoders and result["checks"].get("adb", {}).get("available"):
                listing = subprocess.run([binary, "--serial=" + self.device, "--list-encoders"],
                                         stdin=subprocess.DEVNULL, capture_output=True, timeout=25, env=env)
                result["checks"]["encoders"] = {"available": listing.returncode == 0,
                    "detail": (listing.stdout + listing.stderr).decode(errors="replace")[-8000:]}
        except (ToolError, OSError, subprocess.SubprocessError) as error:
            result["checks"]["scrcpy"] = {"available": False, "reason": str(error)}
        result["checks"]["display"] = {"available": runtime.gui_available() or bool(runtime.android_host() and android_display.installed())}
        result["ready_for_stream_test"] = all(result["checks"].get(key, {}).get("available") for key in ("adb", "capture", "scrcpy", "display"))
        result["warnings"].append("Esta comprobación no inicia un directo ni garantiza la captura de aplicaciones con contenido protegido.")
        return result

    def list_streams(self) -> list[dict]:
        sessions = []
        for record in self._session_records():
            identity = process_identity(record["pid"])
            if session_matches(record, identity):
                sessions.append(self._public_session(record))
            else:
                self._session_path(record["session_id"]).unlink(missing_ok=True)
        for session_id, child in list(self._stream_children.items()):
            if child.poll() is not None:
                del self._stream_children[session_id]
        return sessions

    def _stop_session(self, record: dict) -> bool:
        """Signal only the exact child identity registered by this tool."""
        pid = record["pid"]
        signals = [(signal.SIGINT, 5), (signal.SIGTERM, 3), (signal.SIGKILL, 2)]
        sent = False
        for signum, timeout in signals:
            if not session_matches(record, process_identity(pid)):
                return sent
            try:
                os.kill(pid, signum)
            except ProcessLookupError:
                return sent
            sent = True
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                child = self._stream_children.get(record["session_id"])
                if child is not None:
                    child.poll()
                if not session_matches(record, process_identity(pid)):
                    return True
                time.sleep(0.1)
        raise ToolError(f"El directo {record['session_id']} no respondió a las señales de cierre.")

    def stop_streams(self, session_id: str | None = None, all_devices: bool = False) -> dict:
        if not runtime.linux_processes():
            raise ToolError("El cierre entre sesiones está disponible en Linux. En otros sistemas, cierra la ventana o usa Ctrl+C.")
        if session_id is not None:
            self._session_path(session_id)
        records = self._session_records()
        if session_id is not None:
            records = [item for item in records if item["session_id"] == session_id]
        elif not all_devices and self.device:
            records = [item for item in records if item["device"] == self.device]
        elif not all_devices and len({item["device"] for item in records}) > 1:
            raise ToolError("Hay directos de varios dispositivos: indica --device, --session o --all.")
        result = {"operation": "stream-stop", "stopped": [], "stale_removed": [], "errors": []}
        for record in records:
            try:
                stopped = self._stop_session(record)
                key = "stopped" if stopped else "stale_removed"
                result[key].append(self._public_session(record))
                self._session_path(record["session_id"]).unlink(missing_ok=True)
                child = self._stream_children.pop(record["session_id"], None)
                if child is not None:
                    child.poll()
            except (OSError, ToolError) as error:
                result["errors"].append({"session_id": record["session_id"], "error": str(error)})
        if not records:
            result["message"] = "No hay directos registrados para detener."
        return result

    def close_menu_streams(self):
        for session_id in list(self._stream_children):
            result = self.stop_streams(session_id=session_id)
            for error in result["errors"]:
                LOG.warning("No se pudo cerrar el directo del menú: %s", error)

    def stream(self, args: argparse.Namespace) -> dict:
        if not runtime.gui_available():
            if runtime.android_host():
                try:
                    android_display.require_available()
                except android_display.DisplayError as error:
                    raise ToolError(str(error)) from error
            else:
                raise ToolError("El directo necesita una pantalla gráfica y DISPLAY o WAYLAND_DISPLAY configurado.")
        background = getattr(args, "background", False)
        if background and not runtime.linux_processes():
            raise ToolError("El directo en segundo plano está disponible en Linux; omite --background en este sistema.")
        self.ensure_device()
        binary, env = self.scrcpy_setup()
        if runtime.android_host():
            try:
                env = android_display.prepare(self.output, env)
            except android_display.DisplayError as error:
                raise ToolError(str(error)) from error
        command, profile = self.stream_command(args, binary)
        session_id = uuid.uuid4().hex
        marker = " [TVBOX:" + session_id + "]"
        command = [value + marker if value.startswith("--window-title=") else value for value in command]
        if os.name == "posix" and shutil.which("stdbuf"):
            command = [shutil.which("stdbuf"), "-oL", "-eL", *command]
        stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        log_path = self.output / f"directo-{stamp}.log"
        self.note(f"Abriendo directo: {profile['max_size']} px máximo, hasta {profile['fps']} fps, {profile['bitrate'] / 1_000_000:g} Mbps.")
        self.note("Cierra la ventana o pulsa Ctrl+C para terminar. Sin audio, grabación ni control remoto.")
        started, cancelled = now(), False
        with log_path.open("w", encoding="utf-8") as log_file:
            if os.name != "nt":
                os.chmod(log_path, 0o600)
            process = subprocess.Popen(command, env=env, stdin=subprocess.DEVNULL,
                                       stdout=log_file, stderr=subprocess.STDOUT,
                                       start_new_session=(os.name != "nt"))
        record = {"session_id": session_id, "device": self.device, "pid": process.pid,
                  "started_at": started, "profile": args.profile, **profile,
                  "log_path": str(log_path), "state": "running"}
        registered = False
        try:
            if runtime.linux_processes():
                deadline = time.monotonic() + 3
                while time.monotonic() < deadline:
                    identity = process_identity(process.pid)
                    if (identity and identity["argv"]
                            and Path(identity["argv"][0]).resolve() == Path(binary).resolve()
                            and any(value.startswith("--window-title=") and value.endswith(marker.strip())
                                    for value in identity["argv"])):
                        record["identity"] = identity
                        break
                    if process.poll() is not None:
                        break
                    time.sleep(0.03)
                if "identity" not in record:
                    raise ToolError(f"No se pudo registrar la identidad del directo. Revisa {log_path}")
                if runtime.android_host():
                    try:
                        android_display.wait_video(process, log_path)
                    except android_display.DisplayError as error:
                        raise ToolError(str(error)) from error
                self._save_session(record)
                registered = True
            if runtime.android_host():
                try:
                    android_display.show()
                except android_display.DisplayError as error:
                    self.note(str(error))
            if background:
                self._stream_children[session_id] = process
                self.note("Directo en segundo plano. Usa la opción 8 del menú o el comando stream-stop para cortarlo.")
                return {"operation": "stream", **self._public_session(record), "audio": False, "recorded": False}
            try:
                process.wait()
            except KeyboardInterrupt:
                cancelled = True
                process.send_signal(signal.SIGINT if os.name != "nt" else signal.SIGTERM)
                try:
                    process.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
        finally:
            if not background or not registered:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                if registered:
                    self._session_path(session_id).unlink(missing_ok=True)
        stop_codes = {-int(getattr(signal, name, fallback))
                      for name, fallback in (("SIGINT", 2), ("SIGTERM", 15), ("SIGKILL", 9))}
        stopped_by_signal = process.returncode in stop_codes
        if process.returncode and not cancelled and not stopped_by_signal:
            detail = log_path.read_text(errors="replace")[-2000:]
            raise ToolError(f"La transmisión terminó con error. Registro: {log_path}\n{detail}")
        return {"operation": "stream", "device": self.device, "started_at": started, "ended_at": now(),
                "session_id": session_id, "profile": args.profile, **profile, "audio": False, "recorded": False,
                "log_path": str(log_path), "state": "stopped"}

    def doctor(self) -> dict:
        checks = {"python": sys.version.split()[0], "adb": self.adb, "output_dir": str(self.output),
                  "log_path": str(self.log_path), "config_path": str(self.config_path),
                  "runtime": runtime.information()}
        try:
            checks["devices"] = self.devices()
        except ToolError as error:
            checks["adb_error"] = str(error)
        try:
            binary, env = self.scrcpy_setup()
            checks["scrcpy"] = binary
            checks["scrcpy_server"] = env.get("SCRCPY_SERVER_PATH", "Incluido con la instalación de scrcpy")
        except ToolError as error:
            checks["scrcpy_error"] = str(error)
        online = [item for item in checks.get("devices", []) if item["state"] == "device"]
        selected_online = (any(item["serial"] == self.device for item in online)
                           if self.device else len(online) == 1)
        checks["tmux"] = shutil.which("tmux")
        checks["ip"] = shutil.which("ip")
        checks["ping"] = runtime.ping_executable()
        if runtime.android_host():
            checks["termux_x11"] = android_display.installed()
        try:
            checks["network_listing"] = {"available": True, "ipv4_interfaces": len(self.networks()),
                                         "mac_access": "local_adb" if self.network_access.endpoint else "native_or_restricted"}
        except (ToolError, OSError, ValueError, subprocess.SubprocessError) as error:
            checks["network_listing"] = {"available": False, "reason": str(error),
                                         "alternative": "discover --method tcp --network TU_SUBRED"}
        try:
            import prompt_toolkit
            checks["prompt_toolkit"] = prompt_toolkit.__version__
        except ImportError:
            checks["prompt_toolkit"] = None
        checks["ready_for_framed_shell"] = bool(checks["tmux"]) and selected_online
        checks["selected_device"] = self.device
        checks["ready_for_capture"] = bool(self.adb) and "adb_error" not in checks and selected_online
        display_ready = runtime.gui_available() or bool(checks.get("termux_x11"))
        checks["ready_for_stream"] = checks["ready_for_capture"] and "scrcpy_error" not in checks and display_ready
        if not display_ready:
            checks["stream_limitation"] = "En Termux instala scrcpy y Termux:X11 (paquete y APK). La opción 5 prepara DISPLAY automáticamente."
        return checks


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=f"{APP_NAME} — control, multimedia y auditoría Android por ADB. {SIGNATURE}.",
                                formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--version", action="version", version=f"{APP_NAME} {VERSION} · {SIGNATURE}")
    p.add_argument("--device", "--serial", help="Identificador ADB o HOST:PUERTO")
    p.add_argument("--config", default=str(runtime.default_config(ROOT)), help="Archivo de configuración JSON; privado en Android")
    p.add_argument("--output-dir", help="Carpeta de salida")
    p.add_argument("--adb", help="Ruta del ejecutable adb")
    p.add_argument("--scrcpy", help="Ruta del ejecutable scrcpy")
    p.add_argument("--scrcpy-server", help="Servidor correspondiente a la versión de scrcpy")
    p.add_argument("--json", action="store_true", help="Devolver resultado JSON; mensajes de error por stderr")
    p.add_argument("--verbose", action="store_true", help="Guardar detalles de diagnóstico en el registro")
    p.add_argument("--color", choices=("auto", "always", "never"), default=None,
                   help="Colores de terminal; auto respeta NO_COLOR y las redirecciones")
    p.add_argument("--theme", choices=THEMES, help="Tema temporal para esta ejecución")
    sub = p.add_subparsers(dest="command")
    sub.add_parser("menu", help="Menú interactivo; también es el modo por defecto")
    audit = sub.add_parser("audit", help="Auditoría por etapas de la IP seleccionada, con reporte y evidencias")
    audit.add_argument("--ports", type=port_list, default=None,
                       help="Puertos TCP a revisar, máximo 4096; por defecto una selección, no todos los puertos")
    audit.add_argument("--rounds", type=bounded(2, 3), default=2, help="Rondas de comprobación TCP, de 2 a 3")
    audit.add_argument("--timeout", type=scan_timeout, default=1.0, help="Espera por puerto, de 0.1 a 10 segundos")
    audit.add_argument("--services", action="store_true", help="Sondas activas de versión con Nmap en puertos confirmados abiertos")
    audit.add_argument("--adb-inventory", action="store_true", help="Consultar inventario y configuración mediante la conexión ADB seleccionada")
    appearance = sub.add_parser("appearance", help="Ver y guardar temas y colores; sin opciones muestra una vista previa")
    appearance.add_argument("--theme", dest="appearance_theme", choices=THEMES, help="Guardar este tema y limpiar colores personalizados")
    appearance.add_argument("--set", dest="assignments", action="append", help="Personalizar ROL=COLOR; repetible")
    appearance.add_argument("--mode", choices=("auto", "always", "never"), help="Guardar el modo de color")
    appearance.add_argument("--reset", action="store_true", help="Restaurar el tema neon y los valores predeterminados")
    sub.add_parser("devices", help="Listar dispositivos ADB")
    networks = sub.add_parser("networks", help="Listar interfaces locales; sujeto a permisos de Android")
    networks.add_argument("--ipv6", action="store_true", help="Mostrar interfaces IPv6")
    scan = sub.add_parser("scan-ports", help="Comprobar puertos TCP de una IP IPv4 o IPv6 elegida")
    scan.add_argument("--host", help="IP a comprobar sin cambiar la selección ADB; admite IPv6%%interfaz")
    scan.add_argument("--interface", help="Interfaz para una IPv6 link-local sin %%interfaz")
    scan.add_argument("--ports", required=True, type=port_list, help="Lista o rangos: 22,80,443,8000-8010 (máximo 4096)")
    scan.add_argument("--timeout", type=scan_timeout, default=1.0, help="Espera por puerto, de 0.1 a 10 segundos")
    vuln = sub.add_parser("vuln-scan", help="Revisar servicios y configuraciones inseguras de una IPv4/IPv6")
    vuln.add_argument("--host", help="IP elegida; por defecto usa la IP del dispositivo seleccionado")
    vuln.add_argument("--interface", help="Interfaz para una IPv6 link-local sin %%interfaz")
    vuln.add_argument("--ports", type=port_list, help="Puertos o rangos TCP; por defecto una selección de servicios comunes")
    vuln.add_argument("--timeout", type=scan_timeout, default=2.0, help="Espera por puerto; sondas de servicio limitadas a 5 segundos")
    vuln.add_argument("--cves", action="store_true", help="Consultar posibles CVE por producto/versión en NVD; solo envía esos datos")
    discovery = sub.add_parser("discover", help="Descubrir equipos locales por vecinos o respuestas TCP")
    discovery.add_argument("--network", help="Subred IPv4 conectada, máximo 1024 direcciones")
    discovery.add_argument("--interface", help="Interfaz local, por ejemplo eth0")
    discovery.add_argument("--passive", action="store_true", help="Consultar vecinos sin enviar sondas")
    discovery.add_argument("--ipv6", action="store_true", help="Buscar vecinos por IPv6 multicast y caché, sin ARP")
    discovery.add_argument("--method", choices=("auto", "tcp"), default="auto",
                           help="tcp funciona sin acceso a vecinos; requiere --network y no obtiene MAC")
    discovery.add_argument("--ports", type=port_list, help="Puertos del descubrimiento TCP, máximo 16; por defecto 22,80,443,3222,5000,5555")
    discovery.add_argument("--timeout", type=scan_timeout, default=0.5, help="Espera por puerto del descubrimiento TCP")
    lookup = sub.add_parser("find-mac", help="Buscar la IP de una MAC exacta; por defecto usa la MAC guardada")
    lookup.add_argument("--ipv6", action="store_true", help="Buscar la MAC mediante vecinos IPv6")
    lookup.add_argument("mac", nargs="?", type=mac_address, help="MAC con dos puntos o guiones")
    lookup.add_argument("--network", help="Subred IPv4 conectada a consultar")
    lookup.add_argument("--interface", help="Interfaz local")
    lookup.add_argument("--passive", action="store_true", help="Consultar solo la caché, sin sondas")
    lookup.add_argument("--select", action="store_true", help="Guardar la nueva IP si hay una coincidencia única con respuesta actual")
    lookup.add_argument("--port", type=bounded(1, 65535), help="Puerto ADB; conserva el guardado si la MAC coincide")
    lookup.add_argument("--connect", action="store_true", help="Conectar ADB antes de guardar; requiere --select")
    selection = sub.add_parser("select", help="Elegir y guardar una IP para siguientes operaciones")
    selection.add_argument("address", help="Dirección IPv4 o IPv6")
    selection.add_argument("--interface", help="Interfaz para una IPv6 link-local sin %%interfaz")
    selection.add_argument("--port", type=bounded(1, 65535), default=5555, help="Puerto ADB configurado en el TV-box")
    selection.add_argument("--no-connect", action="store_true", help="Guardar la selección sin conectar todavía")
    connect = sub.add_parser("connect", help="Conectar un dispositivo por red")
    connect.add_argument("address", help="HOST:PUERTO o [IPv6%%interfaz]:PUERTO")
    connect.add_argument("--interface", help="Interfaz para una IPv6 link-local sin %%interfaz")
    enable = sub.add_parser("enable-adb", help="Activar ADB 5555 mediante el servicio compatible del puerto 5000 y conectar")
    enable.add_argument("--host", help="IP elegida; por defecto usa la IP del destino seleccionado")
    enable.add_argument("--interface", help="Interfaz para una IPv6 link-local sin %%interfaz")
    enable.add_argument("--timeout", type=bounded(1, 60), default=20, help="Espera máxima a que abra ADB, en segundos")
    enable.add_argument("--no-save", action="store_true", help="Conectar temporalmente sin guardar el destino")
    sub.add_parser("status", help="Consultar el estado y la versión declarada")
    sub.add_parser("shell", help="Abrir una shell ADB interactiva del dispositivo seleccionado; requiere terminal")
    image = sub.add_parser("show-image", help="Enviar una imagen local y abrirla en la pantalla del dispositivo")
    image.add_argument("file", help="Archivo PNG, JPEG, GIF o WebP de la computadora, máximo 25 MiB")
    image.add_argument("--viewer", help="Usar una galería Android concreta; por defecto utiliza el visor universal Dogo")
    sub.add_parser("hide-image", help="Quitar de pantalla una imagen mostrada por la herramienta; conserva el archivo")
    equipment = sub.add_parser("equipment", help="Guardar y conectar varios decodificadores")
    equipment_actions = equipment.add_subparsers(dest="equipment_action", required=True)
    equipment_actions.add_parser("list")
    saved = equipment_actions.add_parser("save")
    saved.add_argument("name")
    saved.add_argument("--offline", action="store_true", help="Guardar dirección sin verificar identidad todavía")
    saved.add_argument("--overwrite", action="store_true")
    for action in ("use", "delete", "endpoint"):
        subaction = equipment_actions.add_parser(action)
        subaction.add_argument("name")
        if action == "endpoint":
            subaction.add_argument("address")
    quality = sub.add_parser("quality", help="Consultar o guardar los ajustes del próximo directo")
    quality.add_argument("--profile", choices=PROFILES)
    quality.add_argument("--max-size", type=bounded(320, 3840))
    quality.add_argument("--fps", type=bounded(1, 60))
    quality.add_argument("--bitrate", type=bitrate)
    compatibility = sub.add_parser("compatibility", help="Comprobar ADB, captura y componentes de vídeo")
    compatibility.add_argument("--encoders", action="store_true", help="Consultar codificadores con scrcpy; no inicia vídeo")
    update = sub.add_parser("update", help="Revisar/aplicar ZIP con respaldo o restaurar código")
    updates = update.add_subparsers(dest="update_action", required=True)
    for action in ("inspect", "apply"):
        update_action = updates.add_parser(action)
        update_action.add_argument("archive")
        update_action.add_argument("--sha256")
    updates.add_parser("backups")
    rollback = updates.add_parser("rollback")
    rollback.add_argument("backup_id")
    sub.add_parser("doctor", help="Comprobar dependencias y configuración")
    sub.add_parser("streams", help="Listar directos activos creados por esta herramienta")
    stop = sub.add_parser("stream-stop", help="Detener los directos registrados del dispositivo seleccionado")
    target = stop.add_mutually_exclusive_group()
    target.add_argument("--session", help="Detener solo este identificador de sesión")
    target.add_argument("--all", dest="all_devices", action="store_true", help="Detener los directos registrados de todos los dispositivos")
    capture = sub.add_parser("capture", help="Capturar pantalla como PNG")
    record = sub.add_parser("record", help="Grabar un MP4, sin audio, de 1 a 180 segundos")
    for command in (capture, record):
        command.add_argument("-o", "--file", help="Archivo de salida; por defecto se genera un nombre único")
        command.add_argument("--overwrite", action="store_true", help="Permitir sustituir la salida indicada")
        command.add_argument("--no-metadata", action="store_true", help="No crear el archivo JSON adicional")
    record.add_argument("--duration", type=bounded(1, 180), default=10, help="Duración en segundos")
    record.add_argument("--size", type=size, default=(1280, 720), help="Resolución ANCHOxALTO")
    record.add_argument("--bitrate", type=bitrate, default=4_000_000, help="Bitrate, por ejemplo 4M")
    stream = sub.add_parser("stream", help="Mostrar la pantalla en una ventana de scrcpy")
    stream.add_argument("--profile", choices=PROFILES, default=None, help="Perfil de calidad")
    stream.add_argument("--max-size", type=bounded(320, 3840), help="Límite del lado mayor de la imagen")
    stream.add_argument("--fps", type=bounded(1, 60), help="Límite de imágenes por segundo")
    stream.add_argument("--bitrate", type=bitrate, help="Bitrate, por ejemplo 6M")
    stream.add_argument("--window-size", type=size, default=(1280, 720), help="Tamaño inicial de ventana")
    stream.add_argument("--title", default=f"{APP_NAME} · Directo", help="Título de la ventana")
    stream.add_argument("--background", action="store_true", help="Abrir el directo y devolver la terminal; Linux")
    return p


def show_hosts(hosts):
    width = max([16] + [len(host["ip"]) for host in hosts])
    compact = width + 55 > terminal_width()-4
    if not compact:
        print(f" Nº  {'IP':<{width}} MAC                Fabricante / evidencia")
    for index, host in enumerate(hosts, 1):
        label = " (este equipo)" if host["is_local"] else ""
        evidence = {"icmp_reply": "respondió", "tcp_response": "respondió TCP", "neighbor_cache": "en caché", "local_interface": "local"}[host['evidence']]
        style = "ok" if host['evidence'] in ("icmp_reply", "tcp_response") else "muted" if host['is_local'] else "warning"
        if compact:
            UI.message(f"{index:3}. {host['ip']}{label}", style)
            print(f"     MAC: {host['mac'] or 'desconocida'} · {host.get('vendor') or 'desconocido'} · {evidence}")
        else:
            UI.message(f"{index:3}  {host['ip']:<{width}} {host['mac'] or 'desconocida':<18} "
                       f"{host.get('vendor') or 'desconocido'} / {evidence}{label}", style)
    if not hosts:
        UI.message("No se observaron equipos en esta consulta.", "warning")


def show(result):
    with output_frame(ui=UI):
        _show(result)


def _show(result):
    if isinstance(result, dict) and result.get("operation") == "enable-adb":
        UI.message("ADB verificado: " + result["device"], "ok")
        if result.get("ipv4_fallback"):
            print("Se utilizó la IPv4 del mismo equipo, comprobada por MAC: " + result["mac"])
        print("El puerto ADB ya estaba disponible." if result["already_available"] else
              "Se utilizó la tarea ADB existente." if result["task_existing"] else
              "Se registró la tarea de activación en el servicio 5000.")
        if result["saved"]:
            print("Destino guardado para las próximas sesiones.")
        for warning in result["warnings"]:
            UI.message(warning, "warning")
        return
    if isinstance(result, dict) and result.get("operation") == "hide-image":
        UI.message("Imagen quitada de la pantalla." if result["state"] == "hidden" else
                   "No se identificó una imagen de la herramienta en primer plano.",
                   "ok" if result["state"] == "hidden" else "muted")
        return
    if isinstance(result, dict) and result.get("operation") == "show-image":
        universal = result.get("display_mode") == "universal"
        UI.message("Imagen mostrada completa y centrada en el TV-box." if universal else
                   "Imagen enviada y visor abierto en el TV-box.", "ok")
        if result.get("selection_source") == "gallery":
            print("Origen: selector de imágenes.")
        else:
            print("Archivo local:", result["source_path"])
        print("Copia en el dispositivo:", result["remote_path"])
        if universal:
            print(f"Ajuste proporcional · Pantalla: {result['display_width']} × {result['display_height']}")
        print("Usa Atrás o Inicio en el mando para salir del visor.")
        return
    if isinstance(result, dict) and result.get("operation") == "adb-shell":
        UI.message(f"Shell ADB finalizada · {result['device']} · código {result['exit_code']}",
                   "ok" if result["exit_code"] == 0 else "warning")
        return
    if isinstance(result, dict) and result.get("operation") == "vulnerability-scan":
        status = {"completed": "completada", "partial": "parcial", "cancelled": "cancelada", "inconclusive": "inconclusa"}.get(result["status"], result["status"])
        UI.message(f"Revisión de vulnerabilidades · {result['ip']} · {status}", "title")
        for service in result["services"]:
            identified = [check for check in service["checks"] if check.get("service") not in (None, "unknown")]
            if not identified:
                UI.message(f"{service['port']}/tcp: servicio no identificado; consulta las evidencias.", "warning")
            elif identified[0]["service"] != "adb":
                UI.message(f"{service['port']}/tcp: {identified[0]['service'].upper()} identificado", "accent")
            for check in service["checks"]:
                if check.get("service") == "adb":
                    text = ("ADB exige autenticación" if check["status"] == "authentication_required" else
                            "ADB aceptó el saludo sin autenticar al cliente")
                    UI.message(f"{service['port']}/tcp: {text}", "ok" if check["status"] == "authentication_required" else "error")
        labels = {"confirmed": "COMPROBADO", "observation": "REVISAR"}
        for item in result["findings"]:
            UI.message(f"[{labels[item['status']]} · {item['severity']}] {item['port']}/tcp: {item['title']}",
                       "error" if item["status"] == "confirmed" else "warning")
            print("  Evidencia:", UI.paint(item["evidence"], "muted"))
            print("  Medida:", item["recommendation"])
        for lookup in result["cve_lookups"]:
            UI.message(f"NVD · {lookup['query']} · {lookup['status']}", "warning")
            for candidate in lookup["candidates"]:
                print(f"  {candidate['id']}: por validar · {candidate['url']}")
            if lookup.get("error"):
                UI.message("  " + lookup["error"], "error")
        summary = result["summary"]
        if result.get("error"):
            UI.message("La revisión quedó incompleta: " + result["error"], "error")
        print(f"Problemas comprobados: {summary['confirmed']} · Observaciones: {summary['observations']} · CVE por validar: {summary['cve_candidates']}")
        if not result["findings"]:
            UI.message("No hubo acceso suficiente para revisar servicios; no se puede evaluar este equipo." if result["status"] == "inconclusive" else
                       "No se comprobaron problemas con estas pruebas; esto no demuestra ausencia de vulnerabilidades.", "warning")
        print("Reporte:", result["report_path"])
        print("Evidencias:", result["evidence_path"])
        return
    if isinstance(result, dict) and result.get("operation") == "find-mac":
        labels = {"found": "coincidencia con respuesta actual", "cached": "solo caché o interfaz local",
                  "not_found": "no visible en la red consultada", "ambiguous": "varias IP: revisar antes de elegir"}
        UI.message(f"MAC {result['mac']}: {labels[result['status']]}", "ok" if result['status'] == "found" else "warning")
        for host in result["matches"]:
            UI.message(f"IP: {host['ip']} · Evidencia: {host['evidence']}")
        if result["selected"]:
            UI.message("Selección guardada: " + result["selection"]["device"], "ok")
        for warning in result["warnings"]:
            UI.message("Aviso: " + warning, "warning")
        return
    if isinstance(result, dict) and result.get("operation") == "audit":
        states = {"completed": "completada", "partial": "parcial", "cancelled": "cancelada", "skipped": "omitida", "error": "error"}
        UI.message(f"Auditoría {states[result['status']]} · {result['ip']}", "title")
        for stage in result["stages"]:
            UI.message(f"{stage['name']}: {states[stage['status']]}", "error" if stage['status'] == "error" else "accent")
        for finding in result["findings"]:
            UI.message(f"[{finding['priority']}] {finding['title']}", "warning")
        print("Reporte:", result["report_path"])
        print("Evidencias:", result["evidence_path"])
        print("No es una certificación de seguridad: consulta los límites y etapas omitidas en el reporte.")
        return
    if isinstance(result, dict) and result.get("operation") == "appearance":
        UI.preview()
        print("Temas:", ", ".join(result["themes"]))
        print("Colores:", ", ".join(result["available_colors"]), "o #RRGGBB")
        print("Preferencias guardadas." if result["saved"] else "Opción 12 del menú para personalizar y guardar.")
        return
    if isinstance(result, dict) and result.get("operation") == "port-scan":
        UI.message(f"Puertos de {result['ip']} · TCP · {result['elapsed_seconds']} s", "title")
        labels = {"open": "abierto", "closed": "cerrado", "no_response": "sin respuesta",
                  "unreachable": "inalcanzable", "error": "error local"}
        for item in result["ports"]:
            UI.message(f"{item['port']:5}/tcp  {labels[item['state']]:<15} {item['elapsed_ms']} ms",
                       {"open": "ok", "closed": "muted", "error": "error"}.get(item["state"], "warning"))
        summary = result["summary"]
        UI.message(f"Abiertos: {summary['open']} · Cerrados: {summary['closed']} · "
                   f"Sin respuesta: {summary['no_response']} · Inalcanzables: {summary['unreachable']} · Errores: {summary['error']}")
        opened = [str(item["port"]) for item in result["ports"] if item["state"] == "open"]
        UI.message("Puertos TCP abiertos: " + (", ".join(opened) if opened else "ninguno observado"), "ok" if opened else "warning")
        if result.get("report_path"):
            print("Reporte JSON:", result["report_path"])
        for warning in result["warnings"]:
            UI.message("Aviso: " + warning, "warning")
        return
    if isinstance(result, dict) and result.get("operation") == "discover":
        interface = result['interface'] or "ruta del sistema · sondeo TCP"
        partial_label = " · resultado parcial" if result.get("status") == "partial" else ""
        UI.message(f"Equipos {result.get('family', 'IPv4')} de {result['network']} · Interfaz: {interface}{partial_label}", "title")
        show_hosts(result["hosts"])
        for warning in result["warnings"]:
            UI.message("Aviso: " + warning, "warning")
        return
    if isinstance(result, list):
        if not result:
            print("No hay elementos disponibles.")
        for item in result:
            if "serial" in item:
                UI.message(f"{item['serial']}  [{item['state']}]  {item['details']}",
                           "ok" if item['state'] == "device" else "warning")
            elif "session_id" in item:
                UI.message(f"Directo: {item['device']} · Sesión {item['session_id']}", "ok")
                if item.get("log_path"):
                    print("Registro:", item["log_path"])
                if item.get("video_stats"):
                    stats = item["video_stats"]
                    print(f"Muestra reciente: {stats['recent_fps']} FPS · cuadros omitidos/s: {stats['recent_skipped_per_second']}")
                    if stats["suggest_mobile"]:
                        UI.message("Hay cuadros omitidos. Prueba el perfil movil o reduce tamaño/FPS con la opción 23.", "warning")
            else:
                print(json.dumps(item, ensure_ascii=False, indent=2))
    elif isinstance(result, dict):
        if "path" in result:
            UI.message(f"Guardado: {result['path']}", "ok")
            if "width" in result:
                print(f"Resolución: {result['width']} × {result['height']}")
            if "duration_seconds" in result:
                print(f"Duración real: {result['duration_seconds']} s · Audio: {'sí' if result['audio'] else 'no'}")
            print(f"Tamaño: {result['bytes']:,} bytes · SHA-256: {result['sha256']}")
            if "metadata_path" in result:
                print(f"Metadatos: {result['metadata_path']}")
            if result.get("metadata_warning"):
                print("Aviso de metadatos:", result["metadata_warning"])
            for warning in result.get("warnings", []):
                print("Aviso:", warning)
        elif result.get("operation") == "stream-stop":
            UI.message(f"Directos detenidos: {len(result['stopped'])}", "ok")
            if result.get("message"):
                print(result["message"])
            for error in result["errors"]:
                UI.message(f"Sesión {error['session_id']}: {error['error']}", "error")
        elif result.get("state") == "running":
            UI.message(f"Directo iniciado en {result['device']}", "ok")
            print("Puedes detenerlo con la opción 8 o con stream-stop.")
        elif result.get("operation") == "select":
            UI.message(f"Dispositivo guardado: {result['device']}", "ok")
            print("ADB:", "conectado" if result["connected"] else "pendiente de conexión")
        else:
            labels = {"device": "Dispositivo", "state": "Estado ADB", "model": "Modelo",
                      "android_release": "Android declarado", "api_level": "Nivel API",
                      "security_patch": "Parche de seguridad", "output_dir": "Carpeta de salida",
                      "ready_for_capture": "Listo para capturas", "ready_for_stream": "Listo para directo",
                      "selected_device": "Dispositivo elegido", "message": "Información"}
            for key, value in result.items():
                if isinstance(value, bool):
                    UI.message(f"{labels.get(key, key)}: {'sí' if value else 'no'}", "ok" if value else "warning")
                elif isinstance(value, (dict, list)):
                    UI.message(labels.get(key, key) + ":", "accent")
                    print(json.dumps(value, ensure_ascii=False, indent=2))
                else:
                    UI.message(f"{labels.get(key, key)}: {value if value is not None else 'no disponible'}",
                               "error" if key.endswith("error") else "accent")


def ask(prompt: str, default: str, validate=lambda value: value):
    while True:
        value = read_input(f"{prompt} [{default}]: ").strip() or default
        try:
            return validate(value)
        except (ValueError, argparse.ArgumentTypeError) as error:
            UI.message("Valor inválido: " + str(error), "warning")


def choose_scan_host(app, interface=None, ipv6_only=False):
    if app.discovered_hosts and not ipv6_only:
        UI.message("Equipos del último descubrimiento:", "title")
        show_hosts(app.discovered_hosts)
    try:
        default = app.last_port_scan["ip"] if app.last_port_scan else device_ip(app.device)
    except ToolError:
        default = ""
    if ipv6_only:
        default = "0"
    def parse(value):
        if value == "0":
            return None
        if value.isdecimal():
            index = int(value)
            if not 1 <= index <= len(app.discovered_hosts):
                raise argparse.ArgumentTypeError("Elige una fila disponible o escribe una IP completa.")
            value = app.discovered_hosts[index - 1]["ip"]
        try:
            host = ip_host(value, interface)
            if ipv6_only and ":" not in host:
                raise ToolError("Elige una IPv6; para comprobar IPv4 utiliza la opción 11.")
            return host
        except ToolError as error:
            raise argparse.ArgumentTypeError(str(error)) from error
    prompt = ("IPv6 destino: pega la dirección o elige una fila; 0 vuelve al menú" if ipv6_only else
              "Destino: número de fila o IP IPv4/IPv6%interfaz; 0 cancela")
    return ask(prompt, default, parse)


def scan_ports_menu(app, interface=None, ipv6_only=False):
    host = choose_scan_host(app, interface, ipv6_only)
    if host is None:
        return
    ports = ask("Puertos TCP (lista o rangos)", ",".join(map(str, DISCOVERY_PORTS)), port_list)
    timeout = ask("Espera por puerto en segundos", "1", scan_timeout)
    result = app.scan_ports(ports, timeout, host=host)
    show(result)
    UI.message("Opciones: 16 revisa vulnerabilidades · 17 conecta ADB a esta IP.", "network")
    if any(item["port"] == 5000 and item["state"] == "open" for item in result["ports"]):
        UI.message("26 activa ADB en 5555 mediante el servicio compatible del puerto 5000.", "network")


def enable_adb_menu(app):
    host = choose_scan_host(app)
    if host is None:
        return
    if any(item["ip"] == host and item.get("is_local") for item in app.discovered_hosts):
        raise ToolError("Has elegido esta computadora. Elige la dirección del TV-box.")
    show(app.enable_adb(host))
    UI.message("Usa 18 para abrir la shell o 5 para iniciar el directo.", "ok")


def connect_adb_menu(app):
    scopes = {host["ip"].partition("%")[2] for host in app.discovered_hosts if "%" in host["ip"]}
    if app.last_port_scan and "%" in app.last_port_scan["ip"]:
        scopes = {app.last_port_scan["ip"].partition("%")[2]}
    interface = next(iter(scopes)) if len(scopes) == 1 else None
    host = choose_scan_host(app, interface)
    if host is None:
        return
    default_port = 5555
    if app.device and ":" in app.device and app.device.rsplit(":", 1)[1].isdecimal():
        default_port = int(app.device.rsplit(":", 1)[1])
    recent = app.last_port_scan
    if recent and recent["ip"] == host:
        opened = [item["port"] for item in recent["ports"] if item["state"] == "open"]
        if opened:
            print("Puertos abiertos observados:", ", ".join(map(str, opened)))
            default_port = next((port for port in (default_port, 3222, 5555) if port in opened), default_port)
    port = ask("Puerto ADB del dispositivo", str(default_port), bounded(1, 65535))
    save = ask("Guardar como destino para próximas sesiones: 1 sí / 0 conexión temporal", "1", bounded(0, 1))
    target = adb_address(host, port)
    app.note(f"Conectando ADB a {target}…")
    if save:
        mac = next((item.get("mac") for item in app.discovered_hosts if item["ip"] == host), None)
        show(app.select_target(host, port, connect=True, mac=mac))
    else:
        show(app.connect(target))
    UI.message("ADB verificado. Usa 2 para consultar el estado, 3 para capturar o 5 para iniciar el directo.", "ok")


def image_menu(app):
    print("1. Elegir imagen en galería / selector visual")
    print("2. Escribir o pegar una ruta · 0. Volver")
    mode = ask("Cómo elegir la imagen", "1", bounded(0, 2))
    if mode == 0:
        return
    if mode == 1:
        UI.message("Abriendo selector. Elige la imagen para enviarla al TV box; cancelar vuelve al menú.", "network")
        try:
            with image_picker.select_image() as selected:
                if not selected.path:
                    UI.message("Selección cancelada.", "muted")
                    return
                send_selected_image(app, selected.path, selected.automatic_viewer, gallery=True)
        except image_picker.PickerError as error:
            raise ToolError(str(error)) from error
        return
    value = read_input("Ruta de imagen en este equipo (PNG/JPEG/GIF/WebP; vacío cancela): ").strip()
    if not value:
        return
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
        value = value[1:-1]
    send_selected_image(app, value)


def send_selected_image(app, value, automatic_viewer=False, gallery=False):
    source = image_source(value)
    result = app.show_image(source["path"])
    if gallery:
        result["selection_source"] = "gallery"
    show(result)


def vulnerability_menu(app):
    from tvbox_vuln import DEFAULT_PORTS, run_vulnerability_scan
    host = choose_scan_host(app)
    if host is None:
        return
    recent = app.last_port_scan
    defaults = [item["port"] for item in recent["ports"]] if recent and recent["ip"] == host else DEFAULT_PORTS
    ports = ask("Puertos TCP a revisar", ",".join(map(str, defaults)), port_list)
    timeout = ask("Espera por puerto en segundos", "2", scan_timeout)
    cves = ask("Consultar posibles CVE en NVD por producto/versión: 1 sí / 0 solo comprobaciones locales", "0", bounded(0, 1))
    show(run_vulnerability_scan(app, host, ports, timeout, bool(cves)))


def appearance_menu(app):
    settings = appearance_settings(app.config.get("appearance", {}))
    original = UI.mode, UI.theme, dict(UI.palette)
    saved = False
    try:
        while True:
            UI.configure(settings)
            UI.preview()
            print("\n1. Elegir tema\n2. Cambiar un color\n3. Modo de color\n4. Restaurar valores\n5. Guardar y volver\n0. Cancelar cambios")
            choice = read_input("Apariencia: ").strip()
            if choice == "0":
                return
            if choice == "1":
                names = list(THEMES)
                for index, name in enumerate(names, 1):
                    print(f"{index}. {name}")
                index = ask("Tema (0 cancela)", "0", bounded(0, len(names)))
                if index:
                    settings.update(theme=names[index - 1], colors={})
            elif choice == "2":
                roles = list(ROLE_LABELS)
                for index, role in enumerate(roles, 1):
                    UI.message(f"{index:2}. {ROLE_LABELS[role]} ({role})", role)
                index = ask("Elemento (0 cancela)", "0", bounded(0, len(roles)))
                if index:
                    for name in COLORS:
                        print(UI.paint(name, "accent") if not UI.enabled() else f"\033[{COLORS[name]}m{name}\033[0m", end="  ")
                    print("\nTambién puedes escribir #RRGGBB (requiere terminal con color RGB).")
                    role = roles[index - 1]
                    def validate_color(value):
                        try:
                            color_code(value)
                        except ToolError as error:
                            raise ValueError(str(error)) from error
                        return value
                    settings["colors"][role] = ask("Color", settings["colors"].get(role, THEMES[settings["theme"]][role]), validate_color)
            elif choice == "3":
                index = ask("1 automático / 2 siempre / 3 sin color", "1", bounded(1, 3))
                settings["mode"] = ("auto", "always", "never")[index - 1]
            elif choice == "4":
                settings = appearance_settings({})
            elif choice == "5":
                result = app.appearance(theme=settings["theme"], mode=settings["mode"], reset=True,
                                        assignments=[f"{role}={color}" for role, color in settings["colors"].items()])
                show(result)
                saved = True
                return
            else:
                UI.message("Elige una opción de 0 a 5.", "warning")
    finally:
        if not saved:
            UI.mode, UI.theme, UI.palette = original


def panel_line(value, width, style="accent"):
    value = re.sub(r"[\x00-\x1f\x7f-\x9f]", " ", str(value))
    for line in wrap_cells(value, width-4):
        print(UI.paint("│ ", "border") + UI.paint(line + " "*(width-4-cells(line)), style) + UI.paint(" │", "border"), flush=True)


def panel_edge(width, title=None, bottom=False):
    if bottom:
        UI.message("╰" + "─" * (width-2) + "╯", "border")
    else:
        label = next(wrap_cells(" " + title + " ", width-4)) if title else ""
        UI.message("╭─" + label + "─" * (width-3-cells(label)) + "╮", "border")


def panel_segments(parts, width):
    """Keep independently styled labels and values inside the same bounded row."""
    row, plain = [], ""
    def emit():
        content = "".join(UI.paint(value, style) for value, style in row)
        print(UI.paint("│ ", "border") + content + " " * (width-4-cells(plain))
              + UI.paint(" │", "border"), flush=True)
    for value, style in parts:
        value = re.sub(r"[\x00-\x1f\x7f-\x9f]", " ", str(value))
        for character in value:
            if cells(plain + character) > width-4:
                emit()
                row, plain = [], ""
            plain += character
            if row and row[-1][1] == style:
                row[-1] = (row[-1][0] + character, style)
            else:
                row.append((character, style))
    emit()


def menu_panel(app):
    width = terminal_width()
    print()
    panel_edge(width)
    brand, version = f"▌ {APP_NAME}", f"v{VERSION}"
    if width >= 48:
        panel_segments([(brand, "title"), (" " * (width-4-cells(brand)-cells(version)), "muted"),
                        (version, "muted")], width)
        caption = "Android · ADB · Multimedia"
        if cells(caption) + cells(SIGNATURE) + 2 <= width-4:
            panel_segments([(caption, "muted"), (" " * (width-4-cells(caption)-cells(SIGNATURE)), "muted"),
                            (SIGNATURE, "muted")], width)
        else:
            panel_line(caption, width, "muted")
            panel_line(SIGNATURE, width, "muted")
    else:
        panel_line(brand, width, "title")
        if cells(f"{version} · {SIGNATURE}") <= width-4:
            panel_line(f"{version} · {SIGNATURE}", width, "muted")
        else:
            panel_line(version, width, "muted")
            panel_line(SIGNATURE, width, "muted")
    UI.message("├" + "─" * (width-2) + "┤", "border")
    panel_segments([("Destino activo: ", "muted"),
                    (app.device or "Sin seleccionar · conecta con 17", "device" if app.device else "warning")], width)
    panel_segments([("Archivos: ", "muted"), (str(app.output), "muted")], width)
    if runtime.android_host():
        panel_line("Red: " + ("ADB local · acceso a MAC" if app.network_access.endpoint else "básico · acceso MAC sujeto a Android"), width, "network")
    groups = [("DISPOSITIVO Y RED", [(10, "Descubrir IPv4"), (15, "Descubrir IPv6"),
                (17, "Conectar ADB (IPv4/IPv6)"), (18, "Shell ADB interactiva"),
                (26, "Activar ADB por puerto 5000"),
                (14, "Buscar dispositivo por MAC"), (21, "Acceso de red Android / MAC"),
                (22, "Equipos guardados"), (24, "Comprobar compatibilidad"),
                (1, "Conexión temporal / USB"),
                (2, "Estado y modelo"), (7, "Dispositivos ADB")], "network"),
              ("PANTALLA Y MULTIMEDIA", [(3, "Capturar pantalla PNG"), (4, "Grabar vídeo MP4"),
                (5, "Iniciar directo"), (8, "Detener directo"), (19, "Mostrar imagen o logo"),
                (20, "Quitar imagen de pantalla"), (9, "Ver directos activos"), (23, "Ajustar calidad del directo")], "media"),
              ("AUDITORÍA Y SOPORTE", [(11, "Puertos TCP (IPv4/IPv6)"), (16, "Buscar vulnerabilidades"),
                (13, "Auditoría por etapas"), (6, "Diagnóstico de dependencias"), (12, "Temas y colores"), (25, "Actualización y respaldos")], "audit")]
    actions = sorted((number, label, style) for _, items, style in groups for number, label in items)
    UI.message("├" + "─" * (width-2) + "┤", "border")
    panel_segments([("OPCIONES", "title"), ("  /  elige un número", "muted")], width)
    areas = {"network": "RED / ADB", "media": "MULTIMEDIA", "audit": "SOPORTE"}
    if width >= 72:
        heading = " N.º ACCIÓN"
        panel_segments([(heading, "muted"), (" " * (width-4-cells(heading)-12), "muted"),
                        ("ÁREA".ljust(12), "muted")], width)
    panel_line("", width)
    for number, label, style in actions:
        parts = [(f"{number:3}  ", "warning" if number == 8 else "network"),
                 (label, "warning" if number == 8 else "accent")]
        if width >= 72:
            parts.extend([(" " * (width-4-5-cells(label)-12), "muted"),
                          (areas[style].ljust(12), "muted")])
        panel_segments(parts, width)
    panel_line("", width)
    UI.message("├" + "─" * (width-2) + "┤", "border")
    panel_segments([("  0  ", "warning"), ("Salir y cerrar directos", "accent")], width)
    panel_segments([("  m  ", "network"), ("Mostrar de nuevo las opciones", "muted")], width)
    panel_edge(width, bottom=True)


def network_access_menu(app):
    if not runtime.android_host():
        raise ToolError("El acceso ADB local es para Android; en Linux se consulta la interfaz directamente.")
    access = app.network_access
    print("Acceso actual:", access.endpoint or "básico; Android puede bloquear las MAC")
    print("1. Vincular ADB local seguro · 2. Conectar/reconectar · 3. Volver al acceso básico · 0. Volver")
    choice = ask("Acción", "0", bounded(0, 3))
    try:
        if choice == 0:
            return
        if choice == 3:
            access.path.unlink(missing_ok=True)
            access.endpoint, access.identity, access.checked = None, None, 0.0
            print("Acceso básico activado. Puedes desactivar depuración inalámbrica en los ajustes Android.")
            return
        if choice == 1:
            print("En Opciones de desarrollador activa Depuración inalámbrica y elige vincular con código.")
            print("Usa los puertos que aparecen en ese teléfono. El puerto de vinculación y el de conexión son distintos.")
            pairing = network_access.loopback_endpoint(ask("Vinculación: 127.0.0.1:PUERTO", ""))
            code = ask("Código de vinculación de seis dígitos", "")
            if not re.fullmatch(r"[0-9]{6}", code):
                raise ToolError("El código debe tener seis dígitos.")
            # The code is never written to the application log or configuration.
            access.run(["pair", pairing, code])
        endpoint = ask("Conexión: 127.0.0.1:PUERTO", access.endpoint or "")
        show(access.connect(endpoint))
        print("Listo. Usa 10 para IPv4, 15 para IPv6 o 14 para buscar por MAC.")
    except network_access.NetworkError as error:
        raise ToolError(str(error)) from error


def menu_action(app, option):
    common = dict(file=None, overwrite=False, no_metadata=False)
    if option == "0":
        return
    if option == "1":
        address = read_input("HOST:PUERTO, [IPv6%interfaz]:PUERTO o identificador USB: ").strip()
        if not address:
            return
        if ":" in address:
            show(app.connect(address))
        else:
            app.device = address
            app.ensure_device()
            print("Dispositivo seleccionado:", app.device)
    elif option == "2":
        show(app.status())
    elif option == "3":
        show(app.capture(argparse.Namespace(**common)))
    elif option == "4":
        duration = ask("Duración, de 1 a 180 segundos", "10", bounded(1, 180))
        dimensions = ask("Resolución", "1280x720", size)
        rate = ask("Bitrate", "4M", bitrate)
        show(app.record(argparse.Namespace(**common, duration=duration, size=dimensions, bitrate=rate)))
    elif option == "5":
        if runtime.linux_processes() and any(item["device"] == app.device for item in app.list_streams()):
            UI.message("Ya hay un directo de este destino. Usa 9 para verlo u 8 para detenerlo antes de abrir otro.", "warning")
            return
        default = app.stream_quality()["profile"]
        print("movil: 960 px / 15 FPS / 2 Mbps · fluido: 720p máx / 4 Mbps · equilibrado: 1080p máx / 6 Mbps · nitido: 1080p máx / 10 Mbps")
        profile = ask("Perfil: movil / fluido / equilibrado / nitido", default)
        if profile not in PROFILES:
            raise ToolError("Perfil desconocido.")
        show(app.stream(argparse.Namespace(profile=profile, max_size=None, fps=None, bitrate=None,
                                           title=f"{APP_NAME} · Directo", window_size=(1280, 720),
                                           background=runtime.linux_processes())))
    elif option == "6":
        show(app.doctor())
    elif option == "7":
        show(app.devices())
    elif option == "8":
        show(app.stop_streams())
    elif option == "9":
        show(app.list_streams())
    elif option == "10":
        try:
            networks = app.networks()
            if not networks:
                raise ToolError("No se encontraron interfaces IPv4 activas.")
        except ToolError as error:
            if not runtime.android_host():
                raise
            UI.message(str(error), "warning")
            UI.message("Puedes buscar por TCP indicando la subred real de tu Wi-Fi; no se obtendrán MAC.", "network")
            subnet = ask("Subred Wi-Fi en formato CIDR (consulta los ajustes de red)", "")
            ports = ask("Puertos TCP para descubrir equipos, máximo 16", ",".join(map(str, DISCOVERY_PORTS)), port_list)
            discovery = app.discover(subnet, method="tcp", ports=ports)
        else:
            for index, item in enumerate(networks, 1):
                print(f"{index}. {item['interface']} · {item['network']} · IP local {item['ip']}")
            chosen = networks[ask("Interfaz de red", "1", bounded(1, len(networks))) - 1]
            subnet = ask("Subred a consultar", chosen["network"])
            discovery = app.discover(subnet, chosen["interface"])
        show(discovery)
        number = ask("Número de equipo para seleccionar; 0 cancela", "0", bounded(0, len(discovery["hosts"])))
        if not number:
            return
        host = discovery["hosts"][number - 1]
        if host["is_local"]:
            raise ToolError("Has elegido este ordenador. Elige la IP del TV-box.")
        default_port = "5555"
        if app.device and app.device.rsplit(":", 1)[0] == host["ip"]:
            default_port = app.device.rsplit(":", 1)[1]
        port = ask("Puerto ADB del TV-box", default_port, bounded(1, 65535))
        connect_now = ask("Conectar ADB ahora: 1 sí / 0 guardar para auditoría de red", "0", bounded(0, 1))
        show(app.select_target(host["ip"], port, connect=bool(connect_now), mac=host["mac"]))
    elif option == "11":
        scan_ports_menu(app)
    elif option == "12":
        appearance_menu(app)
    elif option == "13":
        from tvbox_audit import run_audit, default_ports
        ports = ask("Puertos TCP", ",".join(map(str, default_ports(app.device))), port_list)
        services = ask("Identificar versiones con sondas de Nmap: 1 sí / 0 no", "0", bounded(0, 1))
        inventory = ask("Consultar Android por ADB: 1 sí / 0 no", "0", bounded(0, 1))
        show(run_audit(app, argparse.Namespace(ports=ports, rounds=2, timeout=1.0,
                                             services=bool(services), adb_inventory=bool(inventory))))
    elif option == "14":
        saved = app.config.get("selected_target") or {}
        target = ask("MAC a buscar", saved.get("mac") or "", mac_address)
        family = ask("Buscar mediante 1 IPv4 / 2 IPv6", "2" if runtime.android_host() else "1", bounded(1, 2))
        result = app.find_mac(target, ipv6=family == 2)
        show(result)
        if result["status"] == "found":
            choice = ask("Actualizar IP: 0 no / 1 guardar / 2 conectar ADB y guardar", "0", bounded(0, 2))
            if choice:
                default_port = str(saved.get("port", 5555)) if saved.get("mac") == target else "5555"
                port = ask("Puerto ADB", default_port, bounded(1, 65535))
                show(app.select_target(result["matches"][0]["ip"], port, connect=choice == 2, mac=target))
    elif option == "15":
        networks = app.networks(ipv6=True)
        if not networks:
            raise ToolError("No se encontraron interfaces IPv6 activas. Comprueba el Wi-Fi del teléfono y usa 10 para descubrir por IPv4.")
        for index, item in enumerate(networks, 1):
            print(f"{index}. {item['interface']} · {item['network']} · IPv6 local {item['ip']}")
        chosen = networks[ask("Interfaz IPv6", "1", bounded(1, len(networks))) - 1]
        show(app.discover_ipv6(chosen["interface"], networks=networks))
        UI.message("Puedes pegar una IPv6 encontrada o elegir su fila para reconocer sus puertos.", "network")
        scan_ports_menu(app, chosen["interface"], ipv6_only=True)
    elif option == "16":
        vulnerability_menu(app)
    elif option == "17":
        connect_adb_menu(app)
    elif option == "18":
        show(app.interactive_shell())
    elif option == "19":
        image_menu(app)
    elif option == "20":
        show(app.hide_image())
    elif option == "21":
        network_access_menu(app)
    elif option == "22":
        from tvbox_menus import equipment_menu
        equipment_menu(app)
    elif option == "23":
        from tvbox_menus import quality_menu
        quality_menu(app)
    elif option == "24":
        show(app.compatibility())
    elif option == "25":
        from tvbox_menus import update_menu
        update_menu(app)
    elif option == "26":
        enable_adb_menu(app)
    else:
        print("Selecciona una opción del 0 al 26.")


def menu(app: App):
    if not sys.stdin.isatty():
        raise ToolError("El menú requiere una terminal. Usa --help para los comandos no interactivos.")
    menu_panel(app)
    while True:
        try:
            option = read_input(UI.paint(f"\n {APP_NAME} › Opción (m: ver menú): ", "accent")).strip()
            if option == "0":
                return
            if option.lower() in ("m", "menu", "menú", "?"):
                menu_panel(app)
                continue
            with output_frame(f"{APP_NAME} · Opción {option}", UI):
                menu_action(app, option)
        except ToolError as error:
            LOG.warning("Operación no completada: %s", error)
            with output_frame(APP_NAME + " · Aviso", UI):
                UI.message("No se completó la operación: " + str(error), "error")
        except InputDependencyError as error:
            raise ToolError(str(error)) from error
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            LOG.exception("Operación de menú fallida")
            with output_frame(APP_NAME + " · Aviso", UI):
                UI.message("No se completó la operación: " + str(error), "error")
            with output_frame(ui=UI):
                UI.message("Puedes reintentar o usar 6 para diagnóstico. Registro: " + str(app.log_path), "warning")
        except KeyboardInterrupt:
            with output_frame(ui=UI):
                UI.message("Operación cancelada. Regresando al menú.", "warning")
        except EOFError:
            with output_frame(ui=UI):
                UI.message("Cerrando el menú.", "muted")
            return


def main(argv: list[str] | None = None) -> int:
    p = parser()
    args = p.parse_args(argv)
    if args.json and args.command in (None, "menu", "shell"):
        p.error("--json requiere un comando no interactivo")
    try:
        app = App(args)
        if args.command in (None, "menu"):
            try:
                menu(app)
            finally:
                app.close_menu_streams()
            return 0
        with (contextlib.nullcontext() if args.json else output_frame(ui=UI)):
            if args.command == "devices":
                result = app.devices()
            elif args.command == "audit":
                from tvbox_audit import run_audit
                result = run_audit(app, args)
            elif args.command == "appearance":
                result = app.appearance(args.appearance_theme, args.assignments, args.mode, args.reset)
            elif args.command == "networks":
                result = app.networks(ipv6=args.ipv6)
            elif args.command == "discover":
                if args.ipv6:
                    if args.network or args.method != "auto" or args.ports is not None:
                        raise ToolError("--ipv6 usa vecinos locales; no se combina con --network, --method tcp ni --ports.")
                    result = app.discover_ipv6(args.interface, args.passive)
                else:
                    result = app.discover(args.network, args.interface, args.passive,
                                          method=args.method, ports=args.ports, timeout=args.timeout)
            elif args.command == "find-mac":
                result = app.find_mac(args.mac, args.network, args.interface, args.passive, args.select, args.port, args.connect, ipv6=args.ipv6)
            elif args.command == "select":
                result = app.select_target(args.address, args.port, connect=not args.no_connect, interface=args.interface)
            elif args.command == "scan-ports":
                result = app.scan_ports(args.ports, args.timeout, host=args.host, interface=args.interface)
            elif args.command == "vuln-scan":
                from tvbox_vuln import DEFAULT_PORTS, run_vulnerability_scan
                host = ip_host(args.host, args.interface) if args.host else device_ip(app.device, args.interface)
                result = run_vulnerability_scan(app, host, args.ports if args.ports is not None else DEFAULT_PORTS, args.timeout, args.cves)
            elif args.command == "connect":
                result = app.connect(args.address, interface=args.interface)
            elif args.command == "enable-adb":
                result = app.enable_adb(args.host, interface=args.interface, timeout=args.timeout, save=not args.no_save)
            elif args.command == "status":
                result = app.status()
            elif args.command == "shell":
                result = app.interactive_shell()
            elif args.command == "show-image":
                result = app.show_image(args.file, args.viewer)
            elif args.command == "hide-image":
                result = app.hide_image()
            elif args.command == "equipment":
                import tvbox_equipment as equipment
                action = args.equipment_action
                if action == "list":
                    result = equipment.profiles(app)
                elif action == "save":
                    result = equipment.save(app, args.name, args.offline, args.overwrite)
                elif action == "use":
                    result = equipment.use(app, args.name)
                elif action == "endpoint":
                    result = equipment.add_endpoint(app, args.name, args.address)
                else:
                    result = equipment.delete(app, args.name)
            elif args.command == "quality":
                from tvbox_equipment import set_quality
                value = app.stream_quality()
                changes = {key: getattr(args, key) for key in ("profile", "max_size", "fps", "bitrate") if getattr(args, key) is not None}
                if "profile" in changes and changes["profile"] != value["profile"]:
                    value = {"profile": changes["profile"], **PROFILES[changes["profile"]]}
                result = set_quality(app, {**value, **changes}) if changes else {"operation": "stream-quality", "settings": value, "saved": False}
            elif args.command == "compatibility":
                result = app.compatibility(args.encoders)
            elif args.command == "update":
                from tvbox_updates import Store, UpdateError
                try:
                    store = Store(ROOT, app.config_path)
                    if args.update_action in ("apply", "rollback") and app.list_streams():
                        raise ToolError("Detén los directos antes de actualizar o restaurar código.")
                    if args.update_action == "inspect":
                        result = store.inspect(args.archive, args.sha256)[0]
                    elif args.update_action == "apply":
                        result = store.apply(args.archive, args.sha256)
                    elif args.update_action == "rollback":
                        result = store.rollback(args.backup_id)
                    else:
                        result = store.backups()
                except UpdateError as error:
                    raise ToolError(str(error)) from error
            elif args.command == "doctor":
                result = app.doctor()
            elif args.command == "streams":
                result = app.list_streams()
            elif args.command == "stream-stop":
                result = app.stop_streams(session_id=args.session, all_devices=args.all_devices)
            elif args.command == "capture":
                result = app.capture(args)
            elif args.command == "record":
                result = app.record(args)
            else:
                args.profile = args.profile or app.stream_quality()["profile"]
                result = app.stream(args)
            LOG.info("Operación completada: %s", args.command)
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                show(result)
            if isinstance(result, dict) and result.get("operation") == "audit":
                return 130 if result["status"] == "cancelled" else 1 if result["status"] == "partial" else 0
            if isinstance(result, dict) and result.get("operation") == "vulnerability-scan":
                return {"cancelled": 130, "partial": 1, "inconclusive": 1}.get(result["status"], 0)
            if isinstance(result, dict) and result.get("operation") == "adb-shell":
                code = result["exit_code"]
                return min(code if code >= 0 else 128-code, 255)
            if isinstance(result, dict) and result.get("operation") == "compatibility":
                return 0 if result["ready_for_stream_test"] else 1
            return 1 if isinstance(result, dict) and result.get("errors") else 0
    except ToolError as error:
        LOG.error("%s", error)
        if args.json:
            print(json.dumps({"error": str(error), "code": error.code}, ensure_ascii=False), file=sys.stderr)
        else:
            with output_frame(APP_NAME + " · Error", UI, stream=sys.stderr):
                print("Error:", error)
        return error.code
    except KeyboardInterrupt:
        with output_frame(APP_NAME + " · Aviso", UI, stream=sys.stderr):
            print("Operación cancelada.")
        return 130
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        LOG.exception("Error de ejecución")
        message = f"No se pudo completar la operación: {error}"
        if args.json:
            print(json.dumps({"error": message, "code": 1}, ensure_ascii=False), file=sys.stderr)
        else:
            with output_frame(APP_NAME + " · Error", UI, stream=sys.stderr):
                print("Error:", message)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
