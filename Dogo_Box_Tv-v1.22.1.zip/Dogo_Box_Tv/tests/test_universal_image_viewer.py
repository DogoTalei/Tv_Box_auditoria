import base64
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
import zipfile

import tvbox
import tvbox_image_viewer as viewer


class UniversalViewerTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.image = Path(self.folder.name) / "image ; filename.png"
        self.image.write_bytes(b"image bytes for transport verification")
        self.source = {"path": str(self.image), "extension": ".png", "mime": "image/png"}
        self.name = "imagen-" + "a" * 32 + ".png"
        self.app = Mock(adb="/fake/adb", device="192.168.0.116:5555")
        self.app.run_adb.side_effect = self.adb
        self.installed_apks = []
        self.status = {"state": "ready", "file": self.name,
                       "sha256": hashlib.sha256(self.image.read_bytes()).hexdigest(),
                       "source_width": 800, "source_height": 1200,
                       "display_width": 1280, "display_height": 720}
        token = patch.object(viewer.uuid, "uuid4", return_value=SimpleNamespace(hex="a" * 32))
        token.start(); self.addCleanup(token.stop)

    def adb(self, arguments, **kwargs):
        output = b""
        if arguments[:3] == ["shell", "dumpsys", "package"]:
            output = b"versionCode=1 minSdk=21 targetSdk=28"
        elif arguments[0] == "install":
            self.installed_apks.append(Path(arguments[-1]).read_bytes())
            output = b"Success\n"
        elif arguments[-1] == "pwd":
            output = b"/data/user/0/com.dogo.tvbox.viewer\n"
        elif arguments[:3] == ["shell", "am", "start"]:
            output = b"Status: ok\n"
        elif "cat" in arguments:
            output = json.dumps(self.status).encode()
        return subprocess.CompletedProcess(arguments, 0, output, b"")

    def show(self):
        with patch.object(viewer.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, b"", b"")) as transfer:
            result = viewer.show(self.app, self.source)
        return result, transfer

    def test_bundled_apk_integrity_and_executable_payload(self):
        payload = viewer.apk_bytes()
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            self.assertIn("AndroidManifest.xml", archive.namelist())
            self.assertTrue(archive.read("classes.dex").startswith(b"dex\n"))
        with patch.object(viewer, "APK_BASE64", base64.b64encode(payload + b"corruption").decode()):
            with self.assertRaisesRegex(viewer.ViewerError, "integridad"):
                viewer.apk_bytes()

    def test_verified_rendering_and_exact_private_transfer(self):
        result, transfer = self.show()
        self.assertEqual(result["state"], "image_displayed")
        self.assertEqual(result["scale"], "fit_center")
        self.assertEqual(result["display_mode"], "universal")
        self.assertEqual(transfer.call_args.kwargs["input"], self.image.read_bytes())
        self.assertNotIn(self.image.name, " ".join(transfer.call_args.args[0]))
        self.assertTrue(result["remote_path"].startswith("/data/user/0/com.dogo.tvbox.viewer/files/"))
        self.assertEqual(self.installed_apks, [])

    def test_missing_package_installs_verified_apk_once(self):
        def adb(arguments, **kwargs):
            if arguments[:3] == ["shell", "dumpsys", "package"]:
                return subprocess.CompletedProcess(arguments, 0, b"Unable to find package", b"")
            return self.adb(arguments, **kwargs)
        self.app.run_adb.side_effect = adb
        self.show()
        self.assertEqual(self.installed_apks, [viewer.apk_bytes()])

    def test_failed_install_never_transfers_an_image(self):
        self.app.run_adb.return_value = subprocess.CompletedProcess([], 1, b"Failure", b"")
        self.app.run_adb.side_effect = None
        with patch.object(viewer.subprocess, "run") as transfer:
            with self.assertRaisesRegex(viewer.ViewerError, "instalar"):
                viewer.show(self.app, self.source)
        transfer.assert_not_called()

    def test_unavailable_private_storage_never_transfers_an_image(self):
        def adb(arguments, **kwargs):
            if arguments[-1] == "pwd":
                return subprocess.CompletedProcess(arguments, 1, b"", b"run-as unavailable")
            return self.adb(arguments, **kwargs)
        self.app.run_adb.side_effect = adb
        with patch.object(viewer.subprocess, "run") as transfer:
            with self.assertRaisesRegex(viewer.ViewerError, "almacenamiento privado"):
                viewer.show(self.app, self.source)
        transfer.assert_not_called()

    def test_android_opening_alone_is_insufficient_without_render_confirmation(self):
        def adb(arguments, **kwargs):
            if "cat" in arguments:
                return subprocess.CompletedProcess(arguments, 1, b"", b"not ready")
            return self.adb(arguments, **kwargs)
        self.app.run_adb.side_effect = adb
        with patch.object(viewer.time, "monotonic", side_effect=[0, 0, 11]), patch.object(viewer.time, "sleep"):
            with self.assertRaisesRegex(viewer.ViewerError, "dibujara"):
                self.show()
        cleanup = self.app.run_adb.call_args.args[0]
        self.assertEqual(cleanup, ["shell", "run-as", viewer.PACKAGE, "rm", "-f",
                                   "files/" + self.name, "files/" + self.name + ".json"])

    def test_wrong_image_digest_dimensions_or_native_error_never_report_success(self):
        for invalid in ({"sha256": "0" * 64}, {"display_width": 0},
                        {"file": "unrelated.jpg"}, {"state": "error", "message": "formato inválido"}):
            original = dict(self.status)
            self.status.update(invalid)
            with self.subTest(invalid=invalid), self.assertRaises(viewer.ViewerError):
                self.show()
            self.status = original

    def test_transfer_timeout_cleans_only_current_private_image(self):
        with patch.object(viewer.subprocess, "run", side_effect=subprocess.TimeoutExpired("adb", 60)):
            with self.assertRaisesRegex(viewer.ViewerError, "transferir"):
                viewer.show(self.app, self.source)
        cleanup = self.app.run_adb.call_args.args[0]
        self.assertEqual(cleanup[:5], ["shell", "run-as", viewer.PACKAGE, "rm", "-f"])
        self.assertEqual(cleanup[-2:], ["files/" + self.name, "files/" + self.name + ".json"])

    def test_oversized_image_fails_before_installation_or_transfer(self):
        with patch.object(viewer, "LIMIT", 1), patch.object(viewer.subprocess, "run") as transfer:
            with self.assertRaisesRegex(viewer.ViewerError, "25 MiB"):
                viewer.show(self.app, self.source)
        self.app.run_adb.assert_not_called()
        transfer.assert_not_called()

    def test_default_show_image_does_not_depend_on_a_factory_gallery(self):
        app = object.__new__(tvbox.App)
        app.ensure_device = Mock()
        app.image_viewers = Mock()
        with patch.object(tvbox, "image_source", return_value=self.source), \
                patch.object(viewer, "show", return_value={"state": "image_displayed"}) as show:
            result = app.show_image("image.png")
        app.image_viewers.assert_not_called()
        show.assert_called_once_with(app, self.source)
        self.assertEqual(result["state"], "image_displayed")

    def test_private_viewer_foreground_is_detected_but_unrelated_app_is_not(self):
        component = viewer.COMPONENT
        uri = "file:///data/user/0/" + viewer.PACKAGE + "/files/" + self.name
        def snapshot(component):
            return (f"  * Hist #0: ActivityRecord{{current u0 {component} t1}}\n"
                    f"    Intent {{ act=android.intent.action.VIEW dat={uri} typ=image/png cmp={component} }}\n"
                    f"  mResumedActivity: ActivityRecord{{current u0 {component} t1}}\n")
        self.assertEqual(tvbox.active_tool_image(snapshot(component))["viewer"], component)
        self.assertIsNone(tvbox.active_tool_image(snapshot("unrelated.app/.Main")))


if __name__ == "__main__":
    unittest.main()
