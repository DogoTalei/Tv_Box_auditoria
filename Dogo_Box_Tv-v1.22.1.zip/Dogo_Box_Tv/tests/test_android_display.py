import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import android_display as display


class AndroidDisplayTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)

    def test_explicit_display_is_preserved_without_starting_another_server(self):
        with patch.dict(os.environ, {'DISPLAY': ':42'}), patch.object(display, 'require_available') as require:
            env = display.prepare(self.root)
        require.assert_not_called()
        self.assertEqual(env['DISPLAY'], ':42')

    def test_prepared_display_preserves_selected_adb_and_server_environment(self):
        with patch.dict(os.environ, {'ADB':'wrong-adb', 'SCRCPY_SERVER_PATH':'wrong-server'}):
            env = display.prepare(self.root, {'DISPLAY': ':42', 'ADB': 'selected-adb', 'SCRCPY_SERVER_PATH': 'selected-server'})
        self.assertEqual(env['ADB'], 'selected-adb')
        self.assertEqual(env['SCRCPY_SERVER_PATH'], 'selected-server')

    def test_package_without_android_apk_is_incomplete(self):
        with patch.object(display.shutil, 'which', return_value='/fake/termux-x11'), patch.object(display.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, b'')):
            with self.assertRaisesRegex(display.DisplayError, 'paquete y aplicación'):
                display.require_available()

    def test_package_query_uses_current_android_user_explicitly(self):
        with patch.object(display.shutil, 'which', return_value='/fake/termux-x11'), patch.object(display.os, 'getuid', return_value=1010305), patch.object(display.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, b'package:/data/app/example.apk\n')) as run:
            self.assertEqual(display.installed(), '/fake/termux-x11')
        self.assertIn('10', run.call_args.args[0])

    def test_existing_socket_is_reused_without_touching_global_environment(self):
        with patch.dict(os.environ, {'TMPDIR': str(self.root)}, clear=True), patch.object(display, 'require_available', return_value='/fake/termux-x11'), patch.object(display, 'connected', return_value=True), patch.object(display.subprocess, 'Popen') as start:
            env = display.prepare(self.root)
            self.assertNotIn('DISPLAY', os.environ)
        start.assert_not_called()
        self.assertEqual(env['DISPLAY'], ':1')

    def test_new_server_disables_tcp_and_waits_for_actual_socket(self):
        # Nine initial slot checks, then the readiness check after launch.
        process = Mock()
        with patch.dict(os.environ, {'TMPDIR': str(self.root)}, clear=True), patch.object(display, 'require_available', return_value='/fake/termux-x11'), patch.object(display, 'connected', side_effect=[False]*9+[True]), patch.object(display.subprocess, 'Popen', return_value=process) as start:
            env = display.prepare(self.root)
        self.assertEqual(start.call_args.args[0], ['/fake/termux-x11', ':1', '-nolisten', 'tcp'])
        self.assertEqual(env['DISPLAY'], ':1')
        self.assertEqual((self.root/'termux-x11.log').stat().st_mode & 0o777, 0o600)
        process.terminate.assert_not_called()

    def test_server_start_failure_does_not_claim_ready_display(self):
        process = Mock()
        process.poll.return_value = 1
        with patch.dict(os.environ, {'TMPDIR': str(self.root)}, clear=True), patch.object(display, 'require_available', return_value='/fake/termux-x11'), patch.object(display, 'connected', return_value=False), patch.object(display.subprocess, 'Popen', return_value=process):
            with self.assertRaisesRegex(display.DisplayError, 'no abrió la pantalla'):
                display.prepare(self.root)

    def test_scrcpy_early_decoder_error_is_visible_before_success(self):
        log = self.root/'stream.log'
        log.write_text('ERROR: Could not open video codec')
        process = Mock()
        process.poll.return_value = 1
        with self.assertRaisesRegex(display.DisplayError, 'Could not open video codec'):
            display.wait_video(process, log)

    def test_first_video_texture_confirms_video_start(self):
        log = self.root/'stream.log'
        log.write_text('INFO: Renderer: software\nINFO: Texture: 1280x720\n')
        process = Mock()
        process.poll.return_value = None
        display.wait_video(process, log)

    def test_android_activity_open_failure_has_manual_recovery(self):
        with patch.object(display.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, b'Error: Activity not found', b'')):
            with self.assertRaisesRegex(display.DisplayError, 'Abre la aplicación'):
                display.show()

    def test_activity_launch_uses_termux_am_wrapper_for_app_uid(self):
        with patch.object(display.shutil, 'which', return_value='/termux/bin/am'), patch.object(display.os, 'getuid', return_value=10305), patch.object(display.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, b'Starting: Intent', b'')) as run:
            display.show()
        self.assertEqual(run.call_args.args[0], ['/termux/bin/am', 'start', '--user', '0', '-n', 'com.termux.x11/com.termux.x11.MainActivity'])
