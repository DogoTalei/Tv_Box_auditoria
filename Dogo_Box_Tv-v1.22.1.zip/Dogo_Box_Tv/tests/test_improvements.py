import argparse
from contextlib import redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox
import tvbox_equipment as equipment
import tvbox_video as video
from tvbox_updates import Store, UpdateError


class EquipmentTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)
        self.config = self.root/'config.json'
        self.original = {'device': '192.168.0.101:3222', 'stream_profile': 'fluido',
                         'custom_user_setting': {'keep': True}, 'appearance': {'theme': 'dogo'}}
        self.config.write_text(json.dumps(self.original))
        self.app = tvbox.App(tvbox.parser().parse_args(['--config', str(self.config), '--output-dir', str(self.root/'out'), 'devices']))
        self.addCleanup(self.close_log)

    @staticmethod
    def close_log():
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)

    def save(self, name='TV casa', serial='SERIAL-ONE'):
        with patch.object(self.app, 'ensure_device'), patch.object(equipment, 'identity', return_value={'serial': serial, 'model': 'AndroidTV'}):
            return equipment.save(self.app, name)

    def test_old_config_load_is_read_only_and_old_quality_unchanged(self):
        before = self.config.read_bytes()
        self.assertEqual(self.app.stream_quality(), {'profile': 'fluido', 'max_size': 1280, 'fps': 30, 'bitrate': 4000000})
        self.assertEqual(equipment.profiles(self.app), [])
        self.assertEqual(self.config.read_bytes(), before)

    def test_multiple_equipment_names_are_preserved_with_private_config_backups(self):
        before = self.config.read_bytes()
        first = self.save()
        self.save('Segundo equipo')
        self.assertEqual(len(equipment.profiles(self.app)), 2)
        self.assertEqual(Path(first['backup']).read_bytes(), before)
        self.assertEqual(Path(first['backup']).stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.app.config['custom_user_setting'], self.original['custom_user_setting'])

    def test_duplicate_name_requires_explicit_overwrite(self):
        self.save()
        before = self.config.read_bytes()
        with self.assertRaisesRegex(tvbox.ToolError, '--overwrite'):
            equipment.save(self.app, 'TV CASA')
        self.assertEqual(self.config.read_bytes(), before)

    def test_wrong_identity_cannot_change_selection_or_configuration(self):
        self.save()
        self.app.device = 'other:5555'
        before = self.config.read_bytes()
        def connect(endpoint, **kwargs):
            self.app.device = endpoint
        with patch.object(self.app, 'connect', side_effect=connect), patch.object(equipment, 'identity', return_value={'serial': 'OTHER', 'model': 'Same model'}):
            with self.assertRaisesRegex(tvbox.ToolError, 'identidad'):
                equipment.use(self.app, 'TV casa')
        self.assertEqual(self.app.device, 'other:5555')
        self.assertEqual(self.config.read_bytes(), before)

    def test_verified_alternative_is_added_without_changing_active_device(self):
        self.save()
        endpoint = '[fe80::1234%wlan0]:3222'
        previous = self.app.device
        def connect(target, **kwargs):
            self.app.device = target
        with patch.object(self.app, 'connect', side_effect=connect), patch.object(equipment, 'identity', return_value={'serial': 'SERIAL-ONE', 'model': 'AndroidTV'}):
            equipment.add_endpoint(self.app, 'TV casa', endpoint)
        self.assertEqual(equipment.find(self.app, 'TV casa')['endpoints'], [previous, endpoint])
        self.assertEqual(self.app.device, previous)

    def test_offline_save_never_claims_verified_identity_or_automatic_recovery(self):
        with patch.object(self.app, 'run_adb') as adb:
            equipment.save(self.app, 'Offline', offline=True)
            self.assertFalse(equipment.recover(self.app))
        adb.assert_not_called()
        self.assertIsNone(equipment.find(self.app, 'Offline')['identity'])

    def test_saved_interface_can_be_absent_while_listing_or_deleting_profiles(self):
        self.app.device = '[fe80::abcd%wifi-not-here]:3222'
        equipment.save(self.app, 'Otra red', offline=True)
        self.assertEqual(equipment.profiles(self.app)[0]['endpoints'], [self.app.device])
        equipment.delete(self.app, 'Otra red')
        self.assertEqual(equipment.profiles(self.app), [])

    def test_recovery_only_tries_saved_addresses_and_verifies_before_return(self):
        self.save()
        config = self.app.config
        config['equipment_profiles'][0]['endpoints'].append('[fe80::abcd%wlan0]:3222')
        equipment.commit(self.app, config)
        calls = []
        def connect(endpoint, **kwargs):
            calls.append(endpoint)
            if endpoint == calls[0] and len(calls) == 1:
                raise tvbox.ToolError('offline')
            self.app.device = endpoint
        with patch.object(self.app, 'connect', side_effect=connect), patch.object(equipment, 'identity', return_value={'serial': 'SERIAL-ONE', 'model': 'AndroidTV'}), redirect_stdout(io.StringIO()):
            self.assertTrue(equipment.recover(self.app))
        self.assertEqual(calls, ['192.168.0.101:3222', '[fe80::abcd%wlan0]:3222'])
        self.assertEqual(self.app.device, calls[-1])

    def test_recovery_stops_on_authorization_or_identity_error(self):
        self.save()
        self.app.config['equipment_profiles'][0]['endpoints'].append('192.168.0.102:3222')
        for message in ['requiere autorización', 'identidad distinta']:
            with self.subTest(message=message), patch.object(self.app, 'connect', side_effect=tvbox.ToolError(message)) as connect:
                with self.assertRaises(tvbox.ToolError):
                    equipment.recover(self.app)
                self.assertEqual(connect.call_count, 1)

    def test_using_saved_equipment_can_recover_its_verified_alternative(self):
        self.save()
        self.app.config['equipment_profiles'][0]['endpoints'].append('192.168.0.102:3222')
        equipment.commit(self.app, self.app.config)
        def connect(endpoint, **kwargs):
            if endpoint == '192.168.0.101:3222':raise tvbox.ToolError('offline')
            self.app.device = endpoint
        with patch.object(self.app, 'connect', side_effect=connect), patch.object(equipment, 'identity', return_value={'serial':'SERIAL-ONE', 'model':'AndroidTV'}):
            equipment.use(self.app, 'TV casa')
        self.assertEqual(self.app.config['device'], '192.168.0.102:3222')

    def test_saved_quality_applies_to_only_its_device_and_cli_overrides_it(self):
        self.save()
        equipment.set_quality(self.app, {'profile': 'movil', 'fps': 12})
        args = argparse.Namespace(profile='movil', max_size=None, fps=10, bitrate=None, window_size=(1280,720), title='test')
        command, parameters = self.app.stream_command(args, '/fake/scrcpy')
        self.assertIn('--max-fps=10', command)
        self.assertEqual(parameters['max_size'], 960)
        self.app.device = 'another:5555'
        self.assertEqual(self.app.stream_quality()['profile'], 'fluido')
        self.assertEqual(self.app.config['stream_profile'], 'fluido')

    def test_invalid_quality_never_writes_configuration(self):
        before = self.config.read_bytes()
        for value in [{'profile':'movil','fps':True}, {'profile':'movil','max_size':0}, {'profile':'movil','bitrate':0}]:
            with self.subTest(value=value), self.assertRaises(tvbox.ToolError):
                equipment.set_quality(self.app, value)
        self.assertEqual(self.config.read_bytes(), before)

    def test_deleting_profile_keeps_destination_and_other_settings(self):
        self.save()
        equipment.delete(self.app, 'TV casa')
        self.assertEqual(self.app.config['device'], self.original['device'])
        self.assertNotIn('active_equipment', self.app.config)
        self.assertEqual(self.app.config['equipment_profiles'], [])

    def test_compatibility_does_not_capture_or_start_video_after_adb_failure(self):
        with patch.object(self.app, 'ensure_device', side_effect=tvbox.ToolError('offline')), patch.object(self.app, 'run_adb') as adb, patch.object(self.app, 'scrcpy_setup', side_effect=tvbox.ToolError('missing')), patch.object(self.app, 'stream') as stream:
            result = self.app.compatibility()
        adb.assert_not_called()
        stream.assert_not_called()
        self.assertFalse(result['ready_for_stream_test'])


class VideoStatsTests(unittest.TestCase):
    def test_observed_skips_are_reported_without_claiming_network_loss(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'video.log'
            path.write_text('INFO: 8 fps (+16 frames skipped)\n'*5)
            value = video.statistics(path)
        self.assertEqual(value['recent_fps'], 8)
        self.assertEqual(value['recent_skipped_per_second'], 16)
        self.assertTrue(value['suggest_mobile'])

    def test_low_fps_without_skips_does_not_request_lower_quality(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'video.log'
            path.write_text('INFO: 1 fps\n'*4)
            self.assertFalse(video.statistics(path)['suggest_mobile'])

    def test_log_reading_is_bounded_to_recent_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'video.log'
            path.write_bytes(b'x'*300000+b'\nINFO: 12 fps\n')
            self.assertEqual(len(video.tail(path).encode()), 65536)
            self.assertEqual(video.statistics(path)['recent_fps'], 12)


class UpdatesTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.base = Path(self.folder.name)
        self.root = self.base/'project'
        self.root.mkdir()
        self.config = self.base/'private.json'
        self.config.write_text('{"device":"user-device"}')
        self.store = Store(self.root, self.config)
        (self.root/'branding.py').write_text("VERSION = '1.17.1'\n")
        self.archive = self.base/'update.zip'

    def package(self, extra=None):
        content = {'Dogo_Box_Tv.py':b'# launcher\n', 'tvbox.py':b'# source\n', 'branding.py':b"VERSION = '1.18.0'\n", 'requirements.txt':b'', 'iniciar.sh':b'#!/bin/sh\n', 'config.json':b'{"device":"do-not-install"}'}
        content.update(extra or {})
        with zipfile.ZipFile(self.archive, 'w') as z:
            for name, body in content.items():z.writestr('Dogo_Box_Tv/'+name,body)
        digest = hashlib.sha256(self.archive.read_bytes()).hexdigest()
        self.archive.with_suffix('.sha256').write_text(digest+'  update.zip\n')
        return digest

    def test_inspection_is_read_only_and_requires_integrity_hash(self):
        sha = self.package()
        plan, files = self.store.inspect(self.archive)
        self.assertEqual(plan['version'], '1.18.0')
        self.assertNotIn('config.json', files)
        self.assertFalse(self.store.folder.exists())
        with self.assertRaises(UpdateError):self.store.inspect(self.archive, '0'*64)
        self.archive.with_suffix('.sha256').unlink()
        with self.assertRaises(UpdateError):self.store.inspect(self.archive)

    def test_update_and_rollback_preserve_user_configuration_and_files(self):
        self.package()
        original = (self.root/'branding.py').read_bytes()
        (self.root/'user-capture.png').write_bytes(b'private')
        result = self.store.apply(self.archive)
        self.assertEqual(self.config.read_text(), '{"device":"user-device"}')
        self.assertFalse((self.root/'config.json').exists())
        self.assertEqual((self.store.folder/result['backup_id']/'config-snapshot.json').stat().st_mode & 0o777, 0o600)
        self.config.write_text('{"device":"new-selection-after-update"}')
        self.store.rollback(result['backup_id'])
        self.assertEqual((self.root/'branding.py').read_bytes(), original)
        self.assertFalse((self.root/'Dogo_Box_Tv.py').exists())
        self.assertEqual(self.config.read_text(), '{"device":"new-selection-after-update"}')
        self.assertEqual((self.root/'user-capture.png').read_bytes(), b'private')

    def test_rollback_refuses_to_clobber_subsequent_source_edits(self):
        self.package();result=self.store.apply(self.archive)
        (self.root/'tvbox.py').write_text('# user edit')
        with self.assertRaisesRegex(UpdateError, 'cambios posteriores'):self.store.rollback(result['backup_id'])
        self.assertEqual((self.root/'tvbox.py').read_text(), '# user edit')

    def test_traversal_and_venv_payload_are_rejected_before_writing(self):
        for filename in ['../outside.py', '/absolute.py', '.venv/bin/python', 'tests/../../outside.py']:
            with self.subTest(filename=filename):
                self.package({filename:b'# bad'})
                with self.assertRaises(UpdateError):self.store.apply(self.archive)
                self.assertFalse(self.store.folder.exists())

    def test_python_syntax_failure_does_not_touch_old_code(self):
        before=(self.root/'branding.py').read_bytes()
        self.package({'tvbox.py':b'def invalid(:\n'})
        with self.assertRaises(UpdateError):self.store.apply(self.archive)
        self.assertEqual((self.root/'branding.py').read_bytes(), before)

    def test_source_symlink_is_rejected(self):
        outside=self.base/'outside.py';outside.write_text('# outside')
        (self.root/'tvbox.py').symlink_to(outside)
        self.package()
        with self.assertRaises(UpdateError):self.store.apply(self.archive)
        self.assertEqual(outside.read_text(), '# outside')

    def test_partial_apply_failure_restores_every_written_file(self):
        self.package()
        original=(self.root/'branding.py').read_bytes()
        write=self.store._write
        count=0
        def fail_once(*args):
            nonlocal count
            count+=1
            if count==4:raise OSError('simulated disk failure')
            return write(*args)
        with patch.object(self.store, '_write', side_effect=fail_once):
            with self.assertRaises(OSError):self.store.apply(self.archive)
        self.assertEqual((self.root/'branding.py').read_bytes(), original)
        self.assertFalse((self.root/'Dogo_Box_Tv.py').exists())
        self.assertEqual(self.store.backups()[0]['state'], 'failed_restored')

    def test_empty_checksum_sidecar_is_rejected_without_mutation(self):
        self.package();self.archive.with_suffix('.sha256').write_text('')
        with self.assertRaises(UpdateError):self.store.apply(self.archive)
        self.assertFalse(self.store.folder.exists())

    def test_interrupted_rollback_restores_the_updated_source(self):
        self.package();result=self.store.apply(self.archive)
        before={p.name:p.read_bytes() for p in self.root.iterdir() if p.is_file()}
        original = self.store._write
        failed = False
        def fail_once(*args):
            nonlocal failed
            if not failed:
                failed = True
                raise OSError('simulated failure')
            return original(*args)
        with patch.object(self.store, '_write', side_effect=fail_once):
            with self.assertRaises(OSError):self.store.rollback(result['backup_id'])
        after={p.name:p.read_bytes() for p in self.root.iterdir() if p.is_file()}
        self.assertEqual(after, before)
