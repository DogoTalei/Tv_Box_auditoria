import io
import json
from pathlib import Path
import socket
import socketserver
import subprocess
import sys
import tempfile
import threading
import unittest
from contextlib import contextmanager, redirect_stdout
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tvbox
import tvbox_adb_bootstrap as bootstrap


@contextmanager
def task_service(tasks=(), response=None, accept=True):
    """Local protocol fixture: records requests, never executes received text."""
    class Handler(socketserver.StreamRequestHandler):
        def handle(self):
            for line in self.rfile:
                self.server.requests.append(line)
                if line == b"list \n":
                    output = response if response is not None else b"".join(t + b"\n" for t in self.server.tasks) + b"\n"
                    self.wfile.write(output)
                    self.wfile.flush()
                    if response is not None:
                        return
                elif line.startswith(b"start ") and accept:
                    self.server.tasks.append(line[6:-1])
    with socketserver.ThreadingTCPServer(("127.0.0.1", 0), Handler) as server:
        server.tasks, server.requests = list(tasks), []
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with patch.object(bootstrap, "dial", side_effect=lambda host, port, timeout: socket.create_connection(server.server_address, timeout)):
                yield server
        finally:
            server.shutdown()
            thread.join(timeout=2)


class ProtocolTests(unittest.TestCase):
    def test_registers_fixed_single_line_and_keeps_existing_tasks(self):
        with task_service([b"existing-job"]) as server:
            result = bootstrap.register_adb("192.168.0.116")
        self.assertTrue(result["task_registered"])
        self.assertEqual(server.tasks, [b"existing-job", bootstrap.ADB_TASK.encode()])
        self.assertEqual(server.requests, [b"list \n", ("start " + bootstrap.ADB_TASK + "\n").encode(), b"list \n"])

    def test_repeated_activation_and_legacy_task_do_not_add_duplicates(self):
        for task in (bootstrap.ADB_TASK, bootstrap.LEGACY_ADB_TASK):
            with self.subTest(task=task), task_service([task.encode()]) as server:
                result = bootstrap.register_adb("192.168.0.116")
            self.assertTrue(result["task_existing"])
            self.assertFalse(result["task_registered"])
            self.assertEqual(server.requests, [b"list \n"])

    def test_unrelated_incomplete_or_binary_response_never_receives_start(self):
        for response in (b"HTTP/1.0 200 OK\r\n\r\n", b"incomplete", b"\x00\n\n"):
            with self.subTest(response=response), task_service(response=response) as server:
                with self.assertRaises(bootstrap.BootstrapError):
                    bootstrap.register_adb("192.168.0.116", timeout=.2)
            self.assertEqual(server.requests, [b"list \n"])

    def test_full_table_is_preserved(self):
        tasks = [f"existing-{n}".encode() for n in range(30)]
        with task_service(tasks) as server:
            with self.assertRaisesRegex(bootstrap.BootstrapError, "llena"):
                bootstrap.register_adb("192.168.0.116")
        self.assertEqual(server.tasks, tasks)
        self.assertEqual(server.requests, [b"list \n"])

    def test_unaccepted_registration_is_not_reported_as_success(self):
        with task_service(accept=False):
            with self.assertRaisesRegex(bootstrap.BootstrapError, "no confirmó"):
                bootstrap.register_adb("192.168.0.116")

    def test_fragmented_listing_and_oversized_response(self):
        connection = Mock()
        connection.recv.side_effect = [b"/system/", b"bin/adbd\n", b"\n"]
        self.assertEqual(bootstrap.read_tasks(connection, 1), [b"/system/bin/adbd"])
        connection.recv.side_effect = [b"x" * 4096] * 16
        with self.assertRaises(bootstrap.BootstrapError):
            bootstrap.read_tasks(connection, 1)


class ActivationTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.config = Path(self.folder.name) / "config.json"
        self.config.write_text(json.dumps({"device": "192.168.0.101:3222", "stream_profile": "fluido", "output_dir": "salidas"}))
        self.original = self.config.read_bytes()
        self.old_ui = tvbox.UI.machine, tvbox.UI.mode
        args = tvbox.parser().parse_args(["--config", str(self.config), "--json", "enable-adb", "--host", "192.168.0.116"])
        self.app = tvbox.App(args)
        self.app.adb = "/mock/adb"
        self.addCleanup(self.close_log)

    def close_log(self):
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)
        tvbox.UI.machine, tvbox.UI.mode = self.old_ui

    @staticmethod
    def adb(arguments, **kwargs):
        output = b"connected\n" if arguments[0] == "connect" else b"device\n"
        return subprocess.CompletedProcess([], 0, output, b"")

    def test_full_activation_verifies_adb_before_saving_selected_host(self):
        self.app.discovered_hosts = [{"ip": "192.168.0.116", "mac": "30:4A:26:91:D9:48"}]
        with task_service() as server, patch.object(self.app, "run_adb", side_effect=self.adb) as adb:
            def probe(host, port, timeout):
                self.assertEqual((host, port), ("192.168.0.116", 5555))
                self.assertEqual(self.config.read_bytes(), self.original)
                return {"state": "open" if server.tasks else "closed"}
            with patch.object(tvbox, "tcp_probe", side_effect=probe):
                result = self.app.enable_adb("192.168.0.116")
        saved = json.loads(self.config.read_text())
        self.assertEqual(result["state"], "device")
        self.assertTrue(result["task_registered"])
        self.assertEqual(self.app.device, "192.168.0.116:5555")
        self.assertEqual(saved["device"], self.app.device)
        self.assertEqual(saved["stream_profile"], "fluido")
        self.assertEqual(saved["selected_target"]["mac"], "30:4A:26:91:D9:48")
        self.assertTrue(any(call.args[0][-1] == "get-state" for call in adb.call_args_list))

    def test_existing_adb_connects_without_touching_port_5000(self):
        with patch.object(tvbox, "tcp_probe", return_value={"state": "open"}), patch.object(bootstrap, "register_adb") as register, \
                patch.object(self.app, "run_adb", side_effect=self.adb):
            result = self.app.enable_adb("192.168.0.116", save=False)
        register.assert_not_called()
        self.assertTrue(result["already_available"])
        self.assertFalse(result["saved"])
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_failed_service_preserves_previous_target_and_config(self):
        with patch.object(tvbox, "tcp_probe", return_value={"state": "closed"}), \
                patch.object(bootstrap, "register_adb", side_effect=bootstrap.BootstrapError("servicio incompatible")):
            with self.assertRaisesRegex(tvbox.ToolError, "incompatible"):
                self.app.enable_adb("192.168.0.116")
        self.assertEqual(self.app.device, "192.168.0.101:3222")
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_closed_adb_after_registration_never_saves_and_reports_remaining_task(self):
        with patch.object(tvbox, "tcp_probe", return_value={"state": "closed"}), \
                patch.object(bootstrap, "register_adb", return_value={"task_registered": True, "task_existing": False}):
            with self.assertRaisesRegex(tvbox.ToolError, "registro permanece"):
                self.app.enable_adb("192.168.0.116", timeout=1)
        self.assertEqual(self.app.device, "192.168.0.101:3222")
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_adb_authorization_failure_never_registers_or_saves(self):
        replies = [subprocess.CompletedProcess([], 0, b"connected", b""),
                   subprocess.CompletedProcess([], 1, b"", b"unauthorized")]
        with patch.object(tvbox, "tcp_probe", return_value={"state": "open"}), \
                patch.object(bootstrap, "register_adb") as register, patch.object(self.app, "run_adb", side_effect=replies):
            with self.assertRaisesRegex(tvbox.ToolError, "autorización"):
                self.app.enable_adb("192.168.0.116")
        register.assert_not_called()
        self.assertEqual(self.app.device, "192.168.0.101:3222")
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_missing_adb_invalid_address_and_wait_fail_before_network_changes(self):
        with patch.object(bootstrap, "register_adb") as register, patch.object(tvbox, "tcp_probe") as probe:
            for host in ("192.168.0.116;id", "--help", "fe80::1234"):
                with self.subTest(host=host), self.assertRaises(tvbox.ToolError):
                    self.app.enable_adb(host)
            for timeout in (0, 61, True):
                with self.subTest(timeout=timeout), self.assertRaises(tvbox.ToolError):
                    self.app.enable_adb("192.168.0.116", timeout=timeout)
            self.app.adb = None
            with self.assertRaisesRegex(tvbox.ToolError, "Instala ADB"):
                self.app.enable_adb("192.168.0.116")
        register.assert_not_called()
        probe.assert_not_called()

    def test_readonly_scan_includes_5000_without_registering_tasks(self):
        from tvbox_vuln import DEFAULT_PORTS
        self.assertIn(5000, tvbox.DISCOVERY_PORTS)
        self.assertIn(5000, DEFAULT_PORTS)
        with patch.object(tvbox, "tcp_probe", return_value={"port": 5000, "state": "open"}), \
                patch.object(bootstrap, "register_adb") as register:
            self.app.scan_ports([5000], save_report=False, host="192.168.0.116")
        register.assert_not_called()

    def test_menu_and_cli_route_to_activation(self):
        with patch.object(tvbox, "choose_scan_host", return_value="192.168.0.116"), \
                patch.object(self.app, "enable_adb", return_value={}) as enable, patch.object(tvbox, "show"), redirect_stdout(io.StringIO()):
            tvbox.menu_action(self.app, "26")
        enable.assert_called_once_with("192.168.0.116")
        with patch.object(tvbox, "App", return_value=self.app), patch.object(self.app, "enable_adb", return_value={"state": "device"}) as enable, redirect_stdout(io.StringIO()):
            code = tvbox.main(["--json", "enable-adb", "--host", "192.168.0.116", "--timeout", "30", "--no-save"])
        self.assertEqual(code, 0)
        enable.assert_called_once_with("192.168.0.116", interface=None, timeout=30, save=False)

    def test_scoped_ipv6_uses_same_scope_for_adb_and_service(self):
        with patch.object(tvbox.socket, "if_nametoindex", return_value=2), patch.object(tvbox.socket, "if_indextoname", return_value="eth0"), \
                patch.object(tvbox, "tcp_probe", side_effect=[{"state": "closed"}, {"state": "open"}, {"state": "open"}]) as probe, \
                patch.object(bootstrap, "register_adb", return_value={"task_registered": True, "task_existing": False}) as register, \
                patch.object(self.app, "run_adb", side_effect=self.adb):
            result = self.app.enable_adb("fe80::1234", interface="eth0", save=False)
        register.assert_called_once_with("fe80::1234%eth0", timeout=2.0)
        self.assertEqual(result["device"], "[fe80::1234%eth0]:5555")
        self.assertTrue(all(call.args[0] == "fe80::1234%eth0" for call in probe.call_args_list))

    @contextmanager
    def ipv6_neighbors(self, ipv4_entries, ipv6_mac="30:4a:26:91:d9:48", row_mac="30:4A:26:91:D9:48"):
        self.ipv6 = "fe80::1234%eth0"
        self.app.discovered_hosts = [{"ip": self.ipv6, "mac": row_mac, "is_local": False}]
        def query(family, interface):
            self.assertEqual(interface, "eth0")
            entries = [{"dst": "fe80::1234", "lladdr": ipv6_mac, "state": ["REACHABLE"]}] if family == "-6" else ipv4_entries
            return subprocess.CompletedProcess([], 0, json.dumps(entries).encode(), b"")
        with patch.object(tvbox.socket, "if_nametoindex", return_value=2), \
                patch.object(tvbox.socket, "if_indextoname", return_value="eth0"), \
                patch.object(self.app, "network_neighbors", side_effect=query):
            yield

    def test_ipv6_refusal_activates_only_ipv4_with_matching_current_mac(self):
        rows = [{"dst": "192.168.0.116", "lladdr": "30:4a:26:91:d9:48", "state": ["STALE"]}]
        with self.ipv6_neighbors(rows), task_service() as server, patch.object(self.app, "run_adb", side_effect=self.adb):
            def probe(host, port, timeout):
                return {"state": "open" if host == "192.168.0.116" and server.tasks else "closed"}
            with patch.object(tvbox, "tcp_probe", side_effect=probe):
                result = self.app.enable_adb(self.ipv6)
        self.assertTrue(result["ipv4_fallback"])
        self.assertTrue(result["task_registered"])
        self.assertEqual(result["requested_ip"], "fe80::1234%eth0")
        saved = json.loads(self.config.read_text())["selected_target"]
        self.assertEqual(saved["ip"], "192.168.0.116")
        self.assertEqual(saved["mac"], "30:4A:26:91:D9:48")
        self.assertEqual(saved["family"], "IPv4")

    def test_working_ipv6_adb_keeps_ipv6_and_does_not_query_neighbors(self):
        with patch.object(tvbox.socket, "if_nametoindex", return_value=2), patch.object(tvbox.socket, "if_indextoname", return_value="eth0"), \
                patch.object(tvbox, "tcp_probe", return_value={"state": "open"}), \
                patch.object(self.app, "network_neighbors") as neighbors, patch.object(bootstrap, "register_adb") as register, \
                patch.object(self.app, "run_adb", side_effect=self.adb):
            result = self.app.enable_adb("fe80::1234%eth0", save=False)
        self.assertFalse(result["ipv4_fallback"])
        self.assertEqual(result["device"], "[fe80::1234%eth0]:5555")
        neighbors.assert_not_called()
        register.assert_not_called()

    def test_missing_mac_never_uses_unrelated_saved_ipv4(self):
        with self.ipv6_neighbors([], ipv6_mac="", row_mac=None), patch.object(tvbox, "tcp_probe", return_value={"state": "closed"}), \
                patch.object(bootstrap, "register_adb") as register:
            with self.assertRaisesRegex(tvbox.ToolError, "MAC comprobable"):
                self.app.enable_adb(self.ipv6)
        register.assert_not_called()
        self.assertEqual(self.config.read_bytes(), self.original)
        self.assertEqual(self.app.device, "192.168.0.101:3222")

    def test_reassigned_saved_ipv4_is_rejected_before_activation(self):
        self.app.config["selected_target"] = {"ip": "192.168.0.116", "mac": "30:4A:26:91:D9:48"}
        rows = [{"dst": "192.168.0.116", "lladdr": "02:11:22:33:44:55", "state": ["REACHABLE"]}]
        with self.ipv6_neighbors(rows), patch.object(tvbox, "tcp_probe", side_effect=lambda host, *args: {"state": "closed" if ":" in host else "open"}), \
                patch.object(bootstrap, "register_adb") as register, patch.object(self.app, "connect") as connect:
            with self.assertRaisesRegex(tvbox.ToolError, "misma MAC"):
                self.app.enable_adb(self.ipv6)
        register.assert_not_called()
        connect.assert_not_called()
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_changed_ipv6_mac_is_rejected_before_probing_saved_ipv4(self):
        with self.ipv6_neighbors([], ipv6_mac="02:11:22:33:44:55"), \
                patch.object(tvbox, "tcp_probe", return_value={"state": "closed"}) as probe, patch.object(bootstrap, "register_adb") as register:
            with self.assertRaisesRegex(tvbox.ToolError, "MAC.*cambió"):
                self.app.enable_adb(self.ipv6)
        self.assertTrue(all(":" in call.args[0] for call in probe.call_args_list))
        register.assert_not_called()

    def test_multiple_matching_ipv4_addresses_require_explicit_selection(self):
        rows = [{"dst": ip, "lladdr": "30:4a:26:91:d9:48", "state": ["REACHABLE"]} for ip in ("192.168.0.116", "192.168.0.117")]
        with self.ipv6_neighbors(rows), patch.object(tvbox, "tcp_probe", return_value={"state": "closed"}), patch.object(bootstrap, "register_adb") as register:
            with self.assertRaisesRegex(tvbox.ToolError, "varias IPv4"):
                self.app.enable_adb(self.ipv6)
        register.assert_not_called()
        self.assertEqual(self.config.read_bytes(), self.original)

    def test_ipv4_discovery_preserves_previous_ipv6_rows(self):
        rows = []
        with self.ipv6_neighbors(rows), patch.object(tvbox, "tcp_probe", return_value={"state": "closed"}):
            original_hosts = self.app.discovered_hosts
            def discover(**kwargs):
                rows.append({"dst": "192.168.0.116", "lladdr": "30:4a:26:91:d9:48", "state": ["REACHABLE"]})
                self.app.discovered_hosts = [{"ip": "192.168.0.116", "mac": "30:4A:26:91:D9:48", "is_local": False}]
                return {"hosts": self.app.discovered_hosts}
            with patch.object(self.app, "discover", side_effect=discover) as discovery:
                host, mac = self.app.adb_ipv4_target(self.ipv6)
        discovery.assert_called_once_with(interface="eth0")
        self.assertEqual(host, "192.168.0.116")
        self.assertEqual(mac, "30:4A:26:91:D9:48")
        self.assertIs(self.app.discovered_hosts, original_hosts)

    def test_menu_rejects_local_computer_before_activation(self):
        self.app.discovered_hosts = [{"ip": "192.168.0.115", "is_local": True}]
        with patch.object(tvbox, "choose_scan_host", return_value="192.168.0.115"), patch.object(self.app, "enable_adb") as enable:
            with self.assertRaisesRegex(tvbox.ToolError, "esta computadora"):
                tvbox.menu_action(self.app, "26")
        enable.assert_not_called()


if __name__ == "__main__":
    unittest.main()
