from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager, redirect_stdout
import http.client
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
import urllib.error
import urllib.request

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import image_picker as picker
import tvbox
from test_show_image import sample_png


class GalleryHTTPTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.gallery = picker.Gallery(self.folder.name)
        self.gallery.__enter__()
        self.addCleanup(self.gallery.__exit__, None, None, None)

    def post(self, path, data=b'', origin=None):
        request = urllib.request.Request(self.gallery.url+path, data=data,
                                         headers={'Origin': origin or self.gallery.origin})
        return urllib.request.urlopen(request, timeout=5)

    def test_page_is_local_uncached_and_cannot_be_framed(self):
        self.assertEqual(self.gallery.server.server_address[0], '127.0.0.1')
        with urllib.request.urlopen(self.gallery.url, timeout=3) as response:
            self.assertEqual(response.headers['Cache-Control'], 'no-store')
            self.assertIn("frame-ancestors 'none'", response.headers['Content-Security-Policy'])
            self.assertIn('Elegir imagen', response.read().decode())

    def test_wrong_host_and_origin_cannot_select_or_read_any_image(self):
        request = urllib.request.Request(self.gallery.url, headers={'Host':'attacker.invalid'})
        with self.assertRaises(urllib.error.HTTPError) as error:urllib.request.urlopen(request)
        self.assertEqual(error.exception.code, 403)
        error.exception.close()
        with self.assertRaises(urllib.error.HTTPError) as error:self.post('image', sample_png(), origin='https://other.invalid')
        self.assertEqual(error.exception.code, 403)
        error.exception.close()
        self.assertFalse(self.gallery.ready.is_set())
        self.assertFalse(self.gallery.path.exists())

    def test_random_url_is_required_and_selected_file_is_never_served(self):
        for url in [self.gallery.origin+'/', self.gallery.url+'image', self.gallery.url+'seleccion.imagen']:
            with self.assertRaises(urllib.error.HTTPError) as error:urllib.request.urlopen(url)
            self.assertEqual(error.exception.code, 404)
            error.exception.close()

    def test_oversized_upload_is_rejected_before_creating_a_file(self):
        with patch.object(picker, 'LIMIT', 64):
            with self.assertRaises(urllib.error.HTTPError) as error:self.post('image', b'x'*65)
        self.assertEqual(error.exception.code, 413)
        error.exception.close()
        self.assertFalse(self.gallery.path.exists())

    def test_selected_image_waits_for_real_send_result_before_success(self):
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(self.post, 'image', sample_png())
            self.assertTrue(self.gallery.ready.wait(3))
            self.assertFalse(future.done())
            self.assertEqual(self.gallery.path.read_bytes(), sample_png())
            self.assertEqual(self.gallery.path.stat().st_mode & 0o777, 0o600)
            self.gallery.result = {'ok':True, 'message':'Imagen enviada'}
            self.gallery.done.set()
            with future.result(timeout=3) as response:
                self.assertEqual(json.load(response)['message'], 'Imagen enviada')

    def test_android_cancel_creates_no_copy_and_does_not_claim_success(self):
        with self.post('cancel') as response:self.assertFalse(json.load(response)['ok'])
        self.assertTrue(self.gallery.ready.is_set())
        self.assertFalse(self.gallery.selected)
        self.assertFalse(self.gallery.path.exists())

    def test_incomplete_upload_is_discarded_and_can_be_retried(self):
        connection = http.client.HTTPConnection('127.0.0.1', self.gallery.server.server_port, timeout=3)
        try:
            connection.putrequest('POST', self.gallery.prefix+'image')
            connection.putheader('Origin', self.gallery.origin)
            connection.putheader('Content-Length','100')
            connection.endheaders(b'partial')
            import socket
            connection.sock.shutdown(socket.SHUT_WR)
            response = connection.getresponse()
            self.assertEqual(response.status,400)
            response.read()
        finally:connection.close()
        self.assertFalse(self.gallery.path.exists())
        self.assertFalse(self.gallery.ready.is_set())

    def test_second_image_is_rejected_after_a_selection(self):
        with self.post('cancel'):pass
        with self.assertRaises(urllib.error.HTTPError) as error:self.post('image', sample_png())
        self.assertEqual(error.exception.code,409)
        error.exception.close()


class SelectionTests(unittest.TestCase):
    def test_desktop_cancel_is_not_an_error_or_a_manual_path(self):
        with patch.object(picker.runtime, 'android_host', return_value=False), patch.object(picker, 'desktop_file', return_value=None):
            with picker.select_image() as selected:self.assertIsNone(selected.path)

    def test_desktop_preserves_spaces_and_uses_arguments_without_shell(self):
        with patch.dict(os.environ, {'DISPLAY':':1'}), patch.object(picker.shutil, 'which', side_effect=lambda name:'/bin/zenity' if name=='zenity' else None), patch.object(picker.subprocess, 'run', return_value=subprocess.CompletedProcess([],0,'/home/a logo with spaces .png\n','')) as run:
            self.assertEqual(picker.desktop_file(5),'/home/a logo with spaces .png')
        self.assertNotIn('shell',run.call_args.kwargs)
        self.assertIsInstance(run.call_args.args[0],list)

    def test_android_launcher_uses_termux_am_and_current_user(self):
        with patch.object(picker.shutil,'which',return_value='/termux/bin/am'), patch.object(picker.os,'getuid',return_value=10305), patch.object(picker.subprocess,'run',return_value=subprocess.CompletedProcess([],0,b'',b'')) as run:
            picker.open_android('http://127.0.0.1:1234/token/')
        self.assertEqual(run.call_args.args[0],['/termux/bin/am','start','--user','0','-a','android.intent.action.VIEW','-d','http://127.0.0.1:1234/token/'])

    def test_android_temporary_copy_is_removed_and_failure_is_reported_to_browser(self):
        with tempfile.TemporaryDirectory() as folder, ThreadPoolExecutor(max_workers=1) as pool:
            future = None
            def launch(url):
                nonlocal future
                origin=url.split('/',3)[:3]
                request=urllib.request.Request(url+'image',data=sample_png(),headers={'Origin':'/'.join(origin)})
                def send():
                    try:
                        with urllib.request.urlopen(request,timeout=6) as response:return response.status,json.load(response)
                    except urllib.error.HTTPError as response:
                        try:return response.code,json.load(response)
                        finally:response.close()
                future=pool.submit(send)
            with patch.dict(os.environ,{'TMPDIR':folder}), patch.object(picker.runtime,'android_host',return_value=True), patch.object(picker,'open_android',side_effect=launch), patch.object(picker,'return_to_terminal'):
                with self.assertRaisesRegex(ValueError,'TV desconectado'):
                    with picker.select_image(timeout=3) as selected:
                        path=Path(selected.path)
                        self.assertTrue(path.exists())
                        raise ValueError('TV desconectado')
            self.assertFalse(path.exists())
            status,result=future.result(timeout=3)
            self.assertEqual(status,400)
            self.assertFalse(result['ok'])
            self.assertIn('TV desconectado',result['message'])


class ImageMenuTests(unittest.TestCase):
    def test_cancelled_gallery_never_contacts_the_tv(self):
        app=Mock()
        @contextmanager
        def choose():yield picker.Selection(None,True)
        with patch('builtins.input',return_value='1'), patch.object(tvbox.image_picker,'select_image',choose), redirect_stdout(io.StringIO()):
            tvbox.image_menu(app)
        app.ensure_device.assert_not_called()
        app.show_image.assert_not_called()

    def test_visual_selection_sends_with_universal_viewer_and_no_extra_prompt(self):
        with tempfile.TemporaryDirectory() as folder:
            image=Path(folder)/'private-copy.imagen';image.write_bytes(sample_png())
            app=Mock()
            app.image_viewers.return_value=['com.android.chrome/.Main','com.example.gallery/.Viewer']
            app.show_image.return_value={'operation':'show-image','source_path':str(image),'remote_path':'remote'}
            @contextmanager
            def choose():yield picker.Selection(str(image),True)
            output=io.StringIO()
            with patch('builtins.input',side_effect=['1']) as read, patch.object(tvbox.image_picker,'select_image',choose), redirect_stdout(output):
                tvbox.image_menu(app)
            self.assertEqual(read.call_count,1)
            app.show_image.assert_called_once_with(str(image))
            self.assertNotIn(str(image),output.getvalue())

    def test_nonimage_selection_never_connects_or_uploads_to_tv(self):
        with tempfile.TemporaryDirectory() as folder:
            image=Path(folder)/'wrong';image.write_bytes(b'not an image')
            app=Mock()
            with self.assertRaises(tvbox.ToolError):tvbox.send_selected_image(app,str(image),True)
            app.ensure_device.assert_not_called()
            app.show_image.assert_not_called()
