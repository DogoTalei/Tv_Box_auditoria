"""IPv6 discovery remains useful when Android's local ADB or multicast fails."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import network_access
import tvbox


class AndroidIPv6NetworkChangeTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.config = Path(self.folder.name) / 'config.json'
        self.config.write_text(json.dumps({'device': '192.168.0.116:5555', 'output_dir': 'salidas'}))
        self.original_config = self.config.read_bytes()
        self.app = tvbox.App(tvbox.parser().parse_args(['--config', str(self.config), '--json', 'networks']))
        self.network = {'interface': 'wlan0', 'ip': 'fe80::10', 'addresses': ['fe80::10'],
                        'network': 'fe80::/64', 'mac': None, 'default': True}
        self.neighbors = subprocess.CompletedProcess([], 0, json.dumps([
            {'dst': 'fe80::20', 'lladdr': '30:4A:26:91:D9:48', 'state': ['STALE']}
        ]).encode())

    def tearDown(self):
        self.assertEqual(self.config.read_bytes(), self.original_config)
        self.assertEqual(self.app.device, '192.168.0.116:5555')
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)
        self.folder.cleanup()

    def test_old_phone_adb_port_does_not_block_current_wifi_discovery(self):
        self.app.network_access.endpoint = '127.0.0.1:37000'
        with patch.object(tvbox.runtime, 'android_host', return_value=True), \
                patch.object(tvbox, 'local_ipv6_networks', side_effect=[
                    network_access.NetworkError('ADB local desconectado'), [self.network]]):
            networks = self.app.networks(ipv6=True)
        self.assertEqual(networks, [self.network])
        self.assertEqual(self.app.network_access.endpoint, '127.0.0.1:37000')
        # Keep pairing, but do not repeatedly query the stale phone connection.
        with patch.object(tvbox.runtime, 'android_host', return_value=True), \
                patch.object(self.app.network_access, 'query') as old_phone, \
                patch.object(tvbox.shutil, 'which', return_value='/mock/ip'), \
                patch.object(tvbox.subprocess, 'run', return_value=self.neighbors):
            self.assertEqual(self.app.network_neighbors('-6', 'wlan0'), self.neighbors)
        old_phone.assert_not_called()

    def test_android_ioctl_can_find_wifi_when_iproute_is_restricted(self):
        with patch.object(tvbox.runtime, 'android_host', return_value=True), \
                patch.object(tvbox, 'local_ipv6_networks', side_effect=tvbox.ToolError('iproute2 restringido')), \
                patch.object(network_access, 'wifi_networks', return_value=[self.network]) as wifi:
            self.assertEqual(self.app.networks(ipv6=True), [self.network])
        wifi.assert_called_once_with(ipv6=True)

    def test_both_access_methods_unavailable_explains_how_to_reconnect_phone(self):
        self.app.network_access.endpoint = '127.0.0.1:37000'
        with patch.object(tvbox.runtime, 'android_host', return_value=True), \
                patch.object(tvbox, 'local_ipv6_networks', side_effect=[
                    network_access.NetworkError('puerto desconectado'), tvbox.ToolError('netlink bloqueado')]), \
                patch.object(network_access, 'wifi_networks', return_value=[]):
            with self.assertRaisesRegex(tvbox.ToolError, '21 → 2'):
                self.app.networks(ipv6=True)

    def test_only_phone_is_not_reported_as_tvbox_discovered(self):
        with patch.object(self.app, 'networks', return_value=[self.network]), \
                patch.object(self.app, 'network_neighbors', return_value=subprocess.CompletedProcess([], 0, b'[]')), \
                patch.object(tvbox.runtime, 'ipv6_ping_command', return_value=['/mock/ping6']), \
                patch.object(tvbox.subprocess, 'run', return_value=subprocess.CompletedProcess([], 1, '', '')), \
                redirect_stdout(io.StringIO()):
            result = self.app.discover_ipv6()
        self.assertTrue(all(host['is_local'] for host in result['hosts']))
        self.assertTrue(any('Solo se detectaron' in warning for warning in result['warnings']))

    def test_multicast_rejected_preserves_known_neighbors_as_cache(self):
        with patch.object(self.app, 'networks', return_value=[self.network]), \
                patch.object(tvbox.runtime, 'android_host', return_value=True), \
                patch.object(self.app, 'network_neighbors', return_value=self.neighbors), \
                patch.object(tvbox.runtime, 'ipv6_ping_command', return_value=['/mock/ping6']), \
                patch.object(tvbox.subprocess, 'run', return_value=subprocess.CompletedProcess(
                    [], 2, '', 'Operation not permitted')), redirect_stdout(io.StringIO()):
            result = self.app.discover_ipv6()
        peer = next(host for host in result['hosts'] if not host['is_local'])
        self.assertEqual(peer['ip'], 'fe80::20%wlan0')
        self.assertEqual(peer['evidence'], 'neighbor_cache')
        self.assertEqual(result['status'], 'partial')
        self.assertTrue(any('multicast' in warning and '10' in warning for warning in result['warnings']))

    def test_multicast_timeout_still_reads_neighbors(self):
        with patch.object(self.app, 'networks', return_value=[self.network]), \
                patch.object(tvbox.runtime, 'android_host', return_value=True), \
                patch.object(self.app, 'network_neighbors', return_value=self.neighbors) as neighbors, \
                patch.object(tvbox.runtime, 'ipv6_ping_command', return_value=['/mock/ping6']), \
                patch.object(tvbox.subprocess, 'run', side_effect=subprocess.TimeoutExpired('ping6', 5)), \
                redirect_stdout(io.StringIO()):
            result = self.app.discover_ipv6()
        neighbors.assert_called_once()
        self.assertEqual(result['status'], 'partial')
        self.assertTrue(any(not host['is_local'] for host in result['hosts']))

    def test_phone_adb_lost_after_multicast_keeps_replies_without_mac(self):
        self.app.network_access.endpoint = '127.0.0.1:37000'
        def run(command, **kwargs):
            if '/mock/ip' in command:
                return subprocess.CompletedProcess(command, 1, b'', b'Permission denied')
            return subprocess.CompletedProcess(command, 0,
                '64 bytes from fe80::20%wlan0: icmp_seq=1\n', '')
        with patch.object(self.app, 'networks', return_value=[self.network]), \
                patch.object(tvbox.runtime, 'android_host', return_value=True), \
                patch.object(tvbox.runtime, 'ipv6_ping_command', return_value=['/mock/ping6']), \
                patch.object(self.app.network_access, 'query', side_effect=network_access.NetworkError('puerto cambiado')), \
                patch.object(tvbox.shutil, 'which', return_value='/mock/ip'), \
                patch.object(tvbox.subprocess, 'run', side_effect=run), redirect_stdout(io.StringIO()):
            result = self.app.discover_ipv6()
        peer = next(host for host in result['hosts'] if not host['is_local'])
        self.assertEqual(peer['evidence'], 'icmp_reply')
        self.assertIsNone(peer['mac'])
        self.assertFalse(result['mac_available'])
        self.assertEqual(result['network_access'], 'native')
        self.assertTrue(any('21 → 2' in warning for warning in result['warnings']))

    def test_android_without_ping_can_show_cache_but_not_claim_replies(self):
        with patch.object(self.app, 'networks', return_value=[self.network]), \
                patch.object(self.app, 'network_neighbors', return_value=self.neighbors), \
                patch.object(tvbox.runtime, 'android_host', return_value=True), \
                patch.object(tvbox.runtime, 'ipv6_ping_command', return_value=[]), \
                patch.object(tvbox.subprocess, 'run') as probe, redirect_stdout(io.StringIO()):
            result = self.app.discover_ipv6()
        probe.assert_not_called()
        self.assertEqual(result['status'], 'partial')
        self.assertFalse(any(host['evidence'] == 'icmp_reply' for host in result['hosts']))

    def test_option15_reuses_fresh_interface_list_instead_of_rechecking_old_adb_port(self):
        with patch.object(self.app, 'networks', return_value=[self.network]) as networks, \
                patch.object(self.app, 'discover_ipv6', return_value={}) as discover, \
                patch.object(tvbox, 'ask', return_value=1), patch.object(tvbox, 'show'), \
                patch.object(tvbox, 'scan_ports_menu'), redirect_stdout(io.StringIO()):
            tvbox.menu_action(self.app, '15')
        networks.assert_called_once_with(ipv6=True)
        discover.assert_called_once_with('wlan0', networks=[self.network])


if __name__ == '__main__':
    unittest.main()
