import errno
import io
import json
from contextlib import redirect_stdout
from pathlib import Path
import socket
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import network_access as access
import tvbox
import tvbox_runtime as runtime


class NetworkAccessTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / 'network-adb.json'

    def test_old_android_ip_text_preserves_actual_mac_and_neighbor_state(self):
        text = ('fe80::1234 dev wlan0 lladdr be:3a:ce:8d:f7:f8 REACHABLE\n'
                'fe80::2 dev wlan0 INCOMPLETE\nnot an address\n')
        records = access.parse_ip(text, ['-6', 'neigh', 'show', 'dev', 'wlan0'])
        self.assertEqual(records[0]['lladdr'], 'be:3a:ce:8d:f7:f8')
        self.assertEqual(records[1]['state'], ['INCOMPLETE'])
        self.assertNotIn('lladdr', records[1])

    def test_android_address_parser_keeps_prefix_flags_and_local_mac(self):
        text = ('33: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500\n'
                '    link/ether f6:35:57:22:ac:01 brd ff:ff:ff:ff:ff:ff\n'
                '    inet 192.168.0.113/23 brd 192.168.1.255 scope global dynamic wlan0\n'
                '    inet6 fe80::1234/64 scope link tentative\n')
        result = access.parse_ip(text, ['address', 'show'])
        self.assertEqual(result[0]['address'], 'f6:35:57:22:ac:01')
        self.assertEqual(result[0]['addr_info'][0]['prefixlen'], 23)
        self.assertTrue(result[0]['addr_info'][1]['tentative'])

    def test_wifi_ioctl_uses_real_netmask_and_does_not_guess_mac(self):
        import fcntl
        def index(name):
            if name == 'wlan0':
                return 33
            raise OSError(errno.ENODEV, 'missing interface')
        def ioctl(connection, operation, request):
            value = '192.168.0.113' if operation == 0x8915 else '255.255.254.0'
            return bytes(20) + socket.inet_aton(value) + bytes(232)
        with patch.object(access.socket, 'if_nametoindex', side_effect=index), patch.object(fcntl, 'ioctl', side_effect=ioctl):
            result = access.wifi_networks()
        self.assertEqual(result[0]['network'], '192.168.0.0/23')
        self.assertIsNone(result[0]['mac'])
        self.assertEqual([item['interface'] for item in result], ['wlan0'])

    def test_ipv6_ioctl_fallback_does_not_require_an_ipv4_address(self):
        import fcntl
        connection = MagicMock()
        connection.__enter__.return_value = connection
        connection.getsockname.return_value = ('fe80::1234', 42000, 0, 33)
        def index(name):
            if name != 'wlan0':
                raise OSError(errno.ENODEV, 'missing')
            return 33
        with patch.object(access.socket, 'if_nametoindex', side_effect=index), patch.object(access.socket, 'socket', return_value=connection), patch.object(fcntl, 'ioctl') as ioctl:
            result = access.wifi_networks(ipv6=True)
        ioctl.assert_not_called()
        connection.connect.assert_called_once_with(('ff02::1', 9, 0, 33))
        self.assertEqual(result[0]['addresses'], ['fe80::1234'])

    def test_backend_refuses_tv_box_lan_address_and_shell_injection(self):
        backend = access.LocalADB('/fake/adb', self.path)
        with patch.object(backend, 'run') as run:
            for address in ['192.168.0.101:3222', 'localhost:5555', '127.0.0.1:0', '127.0.0.1:22;id']:
                with self.subTest(address=address), self.assertRaises(access.NetworkError):
                    backend.connect(address)
            run.assert_not_called()

    def test_connection_stores_only_endpoint_and_verified_identity_privately(self):
        backend = access.LocalADB('/fake/adb', self.path)
        with patch.object(backend, 'run'), patch.object(backend, 'remote_identity', return_value='PHONE-123'):
            backend.connect('127.0.0.1:37000')
        self.assertEqual(json.loads(self.path.read_text()), {'endpoint': '127.0.0.1:37000', 'identity': 'PHONE-123'})
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)

    def test_changed_identity_is_never_queried_for_neighbors(self):
        self.path.write_text(json.dumps({'endpoint': '127.0.0.1:37000', 'identity': 'PHONE-123'}))
        backend = access.LocalADB('/fake/adb', self.path)
        with patch.object(backend, 'remote_identity', return_value='OTHER'), patch.object(access, 'wifi_networks', return_value=[]), patch.object(backend, 'run', return_value=subprocess.CompletedProcess([], 0, b'')) as run:
            with self.assertRaisesRegex(access.NetworkError, 'identidad distinta'):
                backend.query(['-6', 'neigh', 'show', 'dev', 'wlan0'])
        self.assertEqual(run.call_args_list[0].args[0], ['mdns', 'services'])
        self.assertEqual(run.call_count, 1)

    def test_mdns_reconnects_changed_port_only_for_own_wifi_and_identity(self):
        self.path.write_text(json.dumps({'endpoint': '127.0.0.1:37000', 'identity': 'PHONE-123'}))
        backend = access.LocalADB('/fake/adb', self.path)
        announcements = ('other\t_adb-tls-connect._tcp\t192.168.0.101:3222\n'
                         'phone\t_adb-tls-connect._tcp\t192.168.0.113:39999\n')
        with patch.object(backend, 'remote_identity', side_effect=[access.NetworkError('offline'), access.NetworkError('port changed'), 'PHONE-123']), patch.object(access, 'wifi_networks', return_value=[{'ip': '192.168.0.113'}]), patch.object(backend, 'run', return_value=subprocess.CompletedProcess([], 0, announcements.encode())) as run:
            backend.ensure()
        self.assertEqual(backend.endpoint, '127.0.0.1:39999')
        self.assertEqual(run.call_args_list[-1].args[0], ['connect', '127.0.0.1:39999'])

    def test_link_metadata_query_does_not_drop_mac_with_family_filter(self):
        backend = access.LocalADB('/fake/adb', self.path)
        backend.endpoint = '127.0.0.1:37000'
        with patch.object(backend, 'ensure'), patch.object(backend, 'run', return_value=subprocess.CompletedProcess([], 0, b'')) as run:
            backend.query(['-4', 'link', 'show'])
        self.assertEqual(run.call_args.args[0][-1], '/system/bin/ip address show')

    def test_network_backend_uses_a_separate_adb_server(self):
        backend = access.LocalADB('/fake/adb', self.path)
        with patch.object(access.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, b'')) as run:
            backend.run(['devices'])
        self.assertEqual(run.call_args.args[0], ['/fake/adb', '-P', '5038', 'devices'])

    def test_android_prefers_separate_ping6_without_invalid_dash6(self):
        with patch.object(runtime, 'android_host', return_value=True), patch.object(runtime.shutil, 'which', return_value=None), patch.object(Path, 'is_file', return_value=True), patch.object(runtime.os, 'access', return_value=True):
            self.assertEqual(runtime.ipv6_ping_command(), ['/system/bin/ping6'])


class DiscoveryAccessTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        args = tvbox.parser().parse_args(['--config', str(Path(self.directory.name)/'config.json'), '--output-dir', str(Path(self.directory.name)/'out'), 'devices'])
        self.app = tvbox.App(args)
        self.addCleanup(self.close_log)

    @staticmethod
    def close_log():
        for handler in list(tvbox.LOG.handlers):
            handler.close()
            tvbox.LOG.removeHandler(handler)

    def test_ipv4_keeps_icmp_replies_when_mac_access_is_denied(self):
        network = {'interface': 'wlan0', 'ip': '192.168.0.1', 'mac': None, 'network': '192.168.0.0/30', 'default': True}
        with patch.object(runtime, 'android_host', return_value=True), patch.object(runtime, 'ping_executable', return_value='/fake/ping'), patch.object(self.app, 'networks', return_value=[network]), patch.object(self.app, 'network_neighbors', return_value=subprocess.CompletedProcess([], 1, b'', b'permission denied')), patch.object(tvbox.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0)) as ping, patch.object(self.app, 'discover_tcp') as tcp, redirect_stdout(io.StringIO()):
            result = self.app.discover()
        self.assertEqual([host['ip'] for host in result['hosts']], ['192.168.0.1', '192.168.0.2'])
        self.assertFalse(result['mac_available'])
        self.assertIn('192.168.0.1', ping.call_args.args[0])
        self.assertNotIn('wlan0', ping.call_args.args[0])
        tcp.assert_not_called()

    def test_ipv6_resolves_multicast_respondents_before_reading_macs(self):
        network = {'interface': 'wlan0', 'ip': 'fe80::1', 'addresses': ['fe80::1'], 'mac': None, 'network': 'fe80::/64', 'default': True}
        resolved = []
        def run(command, **kwargs):
            if 'ff02::1%wlan0' in command:
                return subprocess.CompletedProcess(command, 0, '64 bytes from fe80::abcd: icmp_seq=1\n', '')
            resolved.append(command[-1])
            return subprocess.CompletedProcess(command, 0)
        def neighbors(*args):
            self.assertIn('fe80::abcd%wlan0', resolved)
            return subprocess.CompletedProcess([], 0, json.dumps([{'dst': 'fe80::abcd', 'lladdr': '02:11:22:33:44:55', 'state': ['REACHABLE']}]).encode())
        with patch.object(self.app, 'networks', return_value=[network]), patch.object(runtime, 'ipv6_ping_command', return_value=['/system/bin/ping6']), patch.object(tvbox.subprocess, 'run', side_effect=run), patch.object(self.app, 'network_neighbors', side_effect=neighbors), redirect_stdout(io.StringIO()):
            result = self.app.discover_ipv6()
        self.assertEqual(result['hosts'][1]['mac'], '02:11:22:33:44:55')
        self.assertEqual(result['hosts'][1]['evidence'], 'icmp_reply')

    def test_ipv6_mac_search_finds_tv_without_changing_selected_destination(self):
        original = self.app.device
        discovery = {'network': 'fe80::/64', 'interface': 'wlan0', 'mac_available': True, 'warnings': [], 'hosts': [
            {'ip': 'fe80::abcd%wlan0', 'mac': '2C:73:60:F1:78:D0', 'evidence': 'icmp_reply', 'is_local': False}]}
        with patch.object(self.app, 'discover_ipv6', return_value=discovery), patch.object(self.app, 'discover') as ipv4:
            result = self.app.find_mac('2c:73:60:f1:78:d0', ipv6=True)
        ipv4.assert_not_called()
        self.assertEqual(result['status'], 'found')
        self.assertEqual(self.app.device, original)

    def test_restricted_mac_search_is_not_reported_as_device_missing(self):
        with patch.object(self.app, 'discover', return_value={'mac_available': False}):
            with self.assertRaisesRegex(tvbox.ToolError, 'opción 21'):
                self.app.find_mac('2C:73:60:F1:78:D0')

    def test_helper_phone_is_not_automatically_selected_as_tv_box(self):
        self.app.network_access.identity = 'PHONE-123'
        self.app.network_access.endpoint = '127.0.0.1:37000'
        text = b'List of devices attached\n127.0.0.1:37000 device\nadb-PHONE-123-abc._adb-tls-connect._tcp device\n192.168.0.101:3222 device product:AndroidTV\n'
        with patch.object(runtime, 'android_host', return_value=True), patch.object(self.app, 'run_adb', return_value=subprocess.CompletedProcess([], 0, text)):
            devices = self.app.devices()
        self.assertEqual([item['serial'] for item in devices], ['192.168.0.101:3222'])
