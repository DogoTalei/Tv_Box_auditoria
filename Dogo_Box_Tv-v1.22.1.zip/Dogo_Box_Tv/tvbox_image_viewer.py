"""Offline Android image viewer: private transfers, proportional software rendering."""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import tempfile
import time
import uuid

PACKAGE = "com.dogo.tvbox.viewer"
COMPONENT = PACKAGE + "/.ViewerActivity"
VERSION_CODE = 1
LIMIT = 25 * 1024 * 1024

MANIFEST = '''<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.dogo.tvbox.viewer" android:versionCode="1" android:versionName="1.0">
  <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="28" />
  <uses-feature android:name="android.hardware.touchscreen" android:required="false" />
  <application android:label="Dogo · Visor de imágenes" android:debuggable="true"
      android:allowBackup="false" android:hardwareAccelerated="false"
      android:theme="@android:style/Theme.Material.NoActionBar.Fullscreen">
    <activity android:name=".ViewerActivity" android:exported="true"
        android:launchMode="singleTask" android:excludeFromRecents="true" />
  </application>
</manifest>'''

JAVA_SOURCE = r'''package com.dogo.tvbox.viewer;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import org.json.JSONObject;

public final class ViewerActivity extends Activity {
    private Bitmap bitmap;
    private String name;
    private JSONObject ready;
    private boolean reported;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        showImage();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        showImage();
    }
    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) immersive();
    }
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
    private File statusFile() { return new File(getFilesDir(), name + ".json"); }
    private void status(JSONObject value) {
        try {
            File temporary = new File(getFilesDir(), name + ".json.part");
            FileOutputStream output = new FileOutputStream(temporary);
            try { output.write(value.toString().getBytes("UTF-8")); }
            finally { output.close(); }
            temporary.renameTo(statusFile());
        } catch (Exception ignored) { }
    }
    private void error(String message) {
        ready = null;
        TextView label = new TextView(this);
        label.setGravity(Gravity.CENTER);
        label.setTextColor(Color.WHITE);
        label.setBackgroundColor(Color.BLACK);
        label.setText("Dogo: " + message);
        setContentView(label);
        if (name != null) {
            try { status(new JSONObject().put("state", "error").put("message", message)); }
            catch (Exception ignored) { }
        }
    }
    private String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        FileInputStream input = new FileInputStream(file);
        try {
            byte[] buffer = new byte[65536];
            int length;
            while ((length = input.read(buffer)) != -1) digest.update(buffer, 0, length);
        } finally { input.close(); }
        StringBuilder result = new StringBuilder();
        for (byte value : digest.digest()) result.append(String.format("%02x", value & 255));
        return result.toString();
    }
    private void showImage() {
        ready = null;
        reported = false;
        name = null;
        try {
            String candidate = getIntent().getData() == null ? null : getIntent().getData().getLastPathSegment();
            if (candidate == null || !candidate.matches("imagen-[a-f0-9]{32}\\.(png|jpg|gif|webp)")) {
                error("La imagen recibida no es válida."); return;
            }
            name = candidate;
            File file = new File(getFilesDir(), name);
            if (!file.isFile() || file.length() == 0 || file.length() > 26214400) {
                error("La imagen no llegó completa o supera 25 MiB."); return;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getPath(), options);
            int originalWidth = options.outWidth, originalHeight = options.outHeight;
            if (originalWidth <= 0 || originalHeight <= 0) {
                error("No se pudo decodificar este formato de imagen."); return;
            }
            int sample = 1;
            while ((long)(originalWidth / sample) * (originalHeight / sample) > 4000000L ||
                   originalWidth / sample > 4096 || originalHeight / sample > 4096) sample *= 2;
            options.inJustDecodeBounds = false;
            options.inSampleSize = sample;
            options.inScaled = false;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap decoded = BitmapFactory.decodeFile(file.getPath(), options);
            if (decoded == null) { error("No se pudo cargar la imagen."); return; }
            int orientation = 1;
            try { orientation = new ExifInterface(file.getPath()).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1); }
            catch (Exception ignored) { }
            Matrix matrix = new Matrix();
            switch (orientation) {
                case 2: matrix.setScale(-1, 1); break;
                case 3: matrix.setRotate(180); break;
                case 4: matrix.setScale(1, -1); break;
                case 5: matrix.setRotate(90); matrix.postScale(-1, 1); break;
                case 6: matrix.setRotate(90); break;
                case 7: matrix.setRotate(-90); matrix.postScale(-1, 1); break;
                case 8: matrix.setRotate(-90); break;
            }
            if (!matrix.isIdentity()) {
                Bitmap rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.getWidth(), decoded.getHeight(), matrix, true);
                if (rotated != decoded) decoded.recycle();
                decoded = rotated;
            }
            Bitmap previous = bitmap;
            bitmap = decoded;
            final ImageView picture = new ImageView(this) {
                @Override protected void onDraw(Canvas canvas) {
                    super.onDraw(canvas);
                    if (!reported && ready != null && getWidth() > 0 && getHeight() > 0) {
                        reported = true;
                        try {
                            ready.put("display_width", getWidth()).put("display_height", getHeight());
                            status(ready);
                            for (File old : getFilesDir().listFiles()) {
                                if (old.getName().matches("imagen-[a-f0-9]{32}\\.(png|jpg|gif|webp)(\\.json)?") &&
                                    !old.getName().equals(name) && !old.getName().equals(name + ".json")) old.delete();
                            }
                        } catch (Exception ignored) { }
                    }
                }
            };
            picture.setBackgroundColor(Color.BLACK);
            picture.setScaleType(ImageView.ScaleType.FIT_CENTER);
            picture.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            picture.setContentDescription("Dogo: imagen completa, centrada y proporcional");
            picture.setImageBitmap(bitmap);
            ready = new JSONObject().put("state", "ready").put("file", name)
                .put("sha256", sha256(file)).put("source_width", originalWidth).put("source_height", originalHeight)
                .put("orientation", orientation).put("decoded_width", bitmap.getWidth()).put("decoded_height", bitmap.getHeight());
            setContentView(picture);
            immersive();
            if (previous != null && previous != bitmap && !previous.isRecycled()) previous.recycle();
        } catch (OutOfMemoryError problem) { error("No hay memoria suficiente para esta imagen."); }
          catch (Exception problem) { error("No se pudo mostrar la imagen."); }
    }
    @Override protected void onDestroy() {
        super.onDestroy();
        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        bitmap = null;
    }
}
'''


class ViewerError(Exception):
    pass


def apk_bytes():
    try:
        payload = base64.b64decode(APK_BASE64, validate=True)
    except (ValueError, TypeError) as error:
        raise ViewerError("El visor incluido está dañado; restaura el paquete de Dogo_Box_Tv.") from error
    if hashlib.sha256(payload).hexdigest() != APK_SHA256:
        raise ViewerError("La integridad del visor incluido no coincide.")
    return payload


def ensure_installed(app):
    package = app.run_adb(["shell", "dumpsys", "package", PACKAGE], check=False, timeout=10)
    match = re.search(rb"\bversionCode=(\d+)", package.stdout)
    if not match or int(match[1]) != VERSION_CODE:
        app.note("Preparando el visor de imágenes Dogo en el TV-box…")
        with tempfile.TemporaryDirectory(prefix="dogo-viewer-") as folder:
            apk = Path(folder) / "dogo-image-viewer.apk"
            apk.write_bytes(apk_bytes())
            result = app.run_adb(["install", "-r", str(apk)], check=False, timeout=60)
            if result.returncode or b"Success" not in result.stdout:
                raise ViewerError("No se pudo instalar el visor Dogo: " + (result.stdout + result.stderr).decode(errors="replace")[-700:])
    result = app.run_adb(["shell", "run-as", PACKAGE, "pwd"], check=False, timeout=8)
    directory = result.stdout.decode(errors="replace").strip()
    if result.returncode or not re.fullmatch(r"/data/(?:user/\d+|data)/com\.dogo\.tvbox\.viewer", directory):
        raise ViewerError("Este firmware no permite enviar imágenes al almacenamiento privado del visor Dogo.")
    app.run_adb(["shell", "run-as", PACKAGE, "mkdir", "-p", "files"])
    return directory


def show(app, source):
    payload = Path(source["path"]).read_bytes()
    if not 0 < len(payload) <= LIMIT:
        raise ViewerError("La imagen debe ocupar entre 1 byte y 25 MiB.")
    directory = ensure_installed(app)
    name = "imagen-" + uuid.uuid4().hex + source["extension"]
    remote = directory + "/files/" + name
    script = "umask 077; cat > files/" + name
    command = [app.adb, "-s", app.device, "shell", "-T", "run-as", PACKAGE, "sh", "-c", shlex.quote(script)]
    try:
        try:
            sent = subprocess.run(command, input=payload, capture_output=True, timeout=60)
        except (OSError, subprocess.SubprocessError) as error:
            raise ViewerError("No se pudo transferir la imagen al visor Dogo: " + str(error)) from error
        if sent.returncode:
            raise ViewerError("Falló la transferencia al visor Dogo: " + sent.stderr.decode(errors="replace")[-700:])
        app.note("Mostrando la imagen completa y centrada…")
        opened = app.run_adb(["shell", "am", "start", "-W", "-a", "android.intent.action.VIEW",
                              "-d", "file://" + remote, "-t", source["mime"], "-n", COMPONENT], check=False, timeout=20)
        output = (opened.stdout + opened.stderr).decode(errors="replace")
        if opened.returncode or "Error:" in output or "Exception" in output or not re.search(r"(?m)^\s*Status:\s*ok\s*$", output):
            raise ViewerError("Android no confirmó la apertura del visor Dogo: " + output[-700:])
        expected_hash = hashlib.sha256(payload).hexdigest()
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            status = app.run_adb(["shell", "run-as", PACKAGE, "cat", "files/" + name + ".json"], check=False, timeout=3)
            if not status.returncode:
                try:
                    data = json.loads(status.stdout)
                except (ValueError, TypeError) as error:
                    raise ViewerError("El visor devolvió una confirmación inválida.") from error
                if data.get("state") == "error":
                    raise ViewerError("El visor Dogo informó: " + str(data.get("message", "error de imagen")))
                if (data.get("state") == "ready" and data.get("file") == name and data.get("sha256") == expected_hash
                        and all(type(data.get(key)) is int and data[key] > 0 for key in
                                ("source_width", "source_height", "display_width", "display_height"))):
                    return {**data, "operation": "show-image", "device": app.device, "source_path": source["path"],
                            "bytes": len(payload), "mime": source["mime"], "remote_path": remote, "viewer": COMPONENT,
                            "state": "image_displayed", "display_mode": "universal", "scale": "fit_center"}
                raise ViewerError("La imagen confirmada no coincide con el archivo enviado.")
            time.sleep(.15)
        raise ViewerError("El visor no confirmó que la imagen se dibujara en pantalla.")
    except BaseException:
        try:
            app.run_adb(["shell", "run-as", PACKAGE, "rm", "-f", "files/" + name, "files/" + name + ".json"], check=False, timeout=5)
        except Exception:
            pass
        raise


# Generated from JAVA_SOURCE and MANIFEST by build_image_viewer.py.
APK_SHA256 = "a0085fb2c70c7bbec834d230d5ea6a4d7ce4631745765315b85094588f8ced3a"
APK_BASE64 = (
    "UEsDBBQAAgAIAACQnwGxO7HBGQMAANQHAAATAAAAQW5kcm9pZE1hbmlmZXN0LnhtbJVUPW8TQRB9e2dj54vY+Q5xiIOEhBDEEJCQKJACCFFACpBSIJqLbYLB"
    "X9jnEBqUMhWiQvwARInokBDiN0RAjURHnZIG3kz24vXhSHCn5517OzvzZna9PtL4lgIMcnidAE6g+7xx7GPEReIe8ZJ4R3whvhN74mCAGWKZuE88Ip4Tr4jP"
    "xC5xygPOEFeIFvGW+Ej8JPaIX4TnA1PEMlEndohPxC4xhE2U0UIbFTRQxzX+lsj8PbOKADWdyaJIpoYmZ6pk7nLFY6z1eAOz/+AVZasfxB7hWOF3/5gZhPRs"
    "YYN8eIhPwomW5kwZT9DhrFglckmqCbDOryq/BjX/Oj02+ApftdUHtKqM+RRXaReZqcNagHE8VA0lzgQadYWzRY0nSgIqizKF9C0faCljixEa9Ik8BlVLh4qL"
    "9Lx90Psx9S1ytqPMDa6RXt6hXdR+hawYSHF1nR4yW9GIpxkn5NvEZRT4tjWyaAhoL8X8l+weFcg3WWFB62nrd29caLam7USgO8DTSaaqFT/QumrsVUf3u3TI"
    "Tv/PmlVnH2uqqMI1oi8kN2m1L3Fdg3oatEKe2XVaW7Q36V3mHklEwMd5cudoebQu6XhBxzSztzXqWUJOFDDscJJR1Ha0N+B/Ot7D+HkQHQ36S+el/8KV9WwO"
    "aZ+l/gp5iRqd2hlct1Xk8YFY40xb+5PXvuX5XcMP7XtdlYly2Q2JIbWGeEZulNnXnMpX/vIAtk0aNznOecbkiFbSmDYxTLtJ+DDmBUfDcZTYpv2V4IVkMsQ8"
    "MQ2ZzlC3XlP4zSejdwM7S/69w8szRXuCb8qepawdZS7NP7axnNFeSG3wZ6J4jt9Jy/l6w+z7zdr5cY7Tlpu23IS9Z6O1wk1212YivbdszEjvnNXrOXoTjo5J"
    "yyUdLicxbE/isaIcCYfP9clxhJi3NcxbLtXNMQYnRzyW5NhxNMlz3OZIOjmGu/FMwfNNdj8fFmzeBes34OSVMas3Vq+WrJ7qXk50hDZmpCNvdSRitS7anIuW"
    "G+mTc7QPd9Tpu+f0ZCCWM+IHYz2J+KHYGTUxPjrTfwBQSwMEFAAAAAgAcJ1wXdqVYfAyEgAAdCEAAAsAAABjbGFzc2VzLmRleI1aC3Cc1XU+/79PrVbSalcv"
    "y3r8Xsn2GlvSSn5IsmT8kC1btmw51lo2khPza/fX6rdX/7/eXckSr4pHAiS0kJAWSg0hbSCQ0Edat2WmTNLCtEladzqThAk06QzPQDsMpZOBMm0K/c69/0oL"
    "MRmk+face+7r3HPPOfdeaVPGYiC+dTu9/8GBt8p3v/ViZu7Ea96fLN3RNpfa/t9vP3KlsI4oS0SLE9vC5Pz8mUb0JyTlW4CYi2g76AugFaAJL9Ek6DOgKug9"
    "ZURP1BNdAX22hugHwL8APwNeBd4G3gM21BJtArYDfcAgsBfYDxwEjgBjQAL4HJAEvgL8JfDPwJuAWkfUDuwGTOBLwOPA3wE/A/4HqIAuUaAXOAYUgPuAbwPP"
    "A//H9Q1E+4BZ4A7gq8CfAv8EvA78CqheQ7QeGAJOATngy8ATwPPAL4G2RowDjAGngbPANDADnAdsoAAsArcAtwN3ApeArwHfAJ4A/hj4DvAs8FPgVeA/gf8F"
    "fGuJIoAGXAP0ADuBvcAYMAWcB24AbgO+CDwEPAl8B3ga+C7wD8BPgZeB/wDeBzxNRCGgGYgBg8AB4BhwGkgC9wDfBX4I/BvwDvAB4G9GX6AJiAFxYADYDxwF"
    "xoFJIAXYwEXgDuAh4JvAnwPPAN8HrgA/Al4EXgHeAt4DAi1E64BuYBdwFDgNzAAXgBuBu4FHgSeBvwa+B/wj8CLwBvA28B6gtmI8oAZoAtqALcBWwAc/hvtS"
    "EICbEdyI4CYENyBsM2EbCOYiLJugFmE4QjdCqBBCiKJAG9AOrAc2ABs5doBNwDXAZieeOoBOoAuIA91AD7AV2EYy1nYAvUAfsAc4DBwDxoDjjq6KE6/lDn8l"
    "gvU5/E8ici2q04bj1uPw1STX+3O0CTv8OxHZprKkfaiEry7h1zp8pbP+952+bY68qsjXrPL+GjkX8yFHzrZqcPj1JfwGp2/I4a84ejKv1Uh7bHTm2lu0M+T7"
    "HD4OfsjhWbf9Dt8H+QGH31PCHyrhj5fwp0v460v42RI+C/6gwy+W8Mslbfwl8rtK5PeV8A0l/IPgDzn8oyVy3tNhh3+iRvpEzLHDEYfntY8W5eCPOvzlErm/"
    "hH+mhGcdeB83lezjphL5NY7ci183j4NeFwX10qKgCi058huc8hcd+iXiPQyD5/iqo28Sx5iPrhO0jW4TdAPdK2iMvgLqQkuXoC10h1P+vKBr6U5BY3QXsV/7"
    "yCT2Yw9NkfTnjENzgm6mmwWtpfuEPnLcMuh9hjh+ZLkc7W4SdAvdI2gdPSRoPf0BsQ02iHYVWE+a2P+DZBP7aQM9TBwjDXRKUD+dA40ga7gEbaYvCNpA9wu6"
    "nr4qaBM9IOga+n1BNboktk32q3HaM/09QdfTI075a8KO60S7Wme9tc56a5356px11SHjfEbQTjohaJjGBY1SQtAKOunYPyVogM4L6iZL0DLKO+MtCCr3o87Z"
    "jzpnP+qc/ahDZvxdR/6goJX0qNP+64JupMeceR4nziftQs+1sP9ZQYPi7sH0giO/UVAX3SLoNvotQbvoy8Q5uU30b8L4k4Kq9DvEeVrKmx15M7z5KeKcVU7f"
    "Js5FcUoKWkUzgm6lWUG7aZk4P0n7tWOHTwsapCeIc1UPXS9oNc0Jeg09SZyfZPsN2MnfFrTGobJfrRM/EYeOAMsaztJWWa4jmWddJfUPor5Kk2UXfjmfvx3m"
    "GMS5r/gpqzVgPZXwOBW1Cr2LOraxra3BXiXSfroQ2gTPD/j6fQ845c0oB319vnvJCm3ASAHfLt/d4Nc7/O2iXTh0QbsGLUv7NNJ0sY9ixU+RT2GZXuzryLhH"
    "4nrZi0+hC9oWZxwr1CXGsUJDgq7LhpXtymEaVn2KFdqNNQRdje55srQxZPCAq8/VR0V5IsUjdsAng25LGxX1/a7YSn3U3U7Z0HHUJwzZ0kNBj6V9Bj4edDd6"
    "FCryVujEx0bxYJRrMcoLiqLEnq7wybONz6QF2FRRWh/hM1VxTtzyiNyjk1gb50jVOWVDjvyMArnCeUmR8ReRd4UoPJYtgLmVqCq1VSkxFBCa9VBQbXQpKzxr"
    "iXWp2fguCqnVV5k/gfhhOe+9G3WNEXlHaKRrsf6EsH1UaYKPHEAc1foUaru4CeMfRCmghn8Zdvf0eMnac5Ky7bF3rdAwxoj6pF4+aDouRlinhNXt4bV0CM73"
    "/NYPMfIRzB50hWvbTm6moy6PuxHKXNCOIqcEXax9L72gqkrsF7wC3uVqX4VPjr7Rx+dIhVjJyFXWU07FdXLNJsj5nMmKi0ilsLPq2FnItQFEZiXsLH2/IyLP"
    "uzBNxcth7Rq0aEWMR5RqrHod2ob/y9LaQGsV+tDSNHBRRa4X1lM9wvbrsDtM9zLFChRRjqKtpfVinkQ8gFvZWoy/AT0n2N7KN9A7RVb8NHYqiPKtkncH3azj"
    "EMXUCrf0qa0izoVPHWadeT17IrLOCnXzjoPWC8tHFG+9pdWKNbqctR+IyHuRrSnQlHtAPzVCy/DmOrTIhnZCwraSNjwakXdYO8SSRKgMulcJaoX4Dhmgfo5N"
    "UQ5I24FftfUp505pay5hgT588hyl+3E2Iu+jtuZGbZ/iQYsekmuqwqw+aD+DNn8LhcLK1MvlmOXMS0GaehmeH4rzOQpv9whv71fd5AvHKj4ut3BpZNqnLiqN"
    "roLIED0idt3I6pYy9UqAoqqMr0rOFq8FiCOnB9G+Fz05l5zEfu4DX+6qw1W42+fy9PmOrMjqIbtPYekuH495rRJ1Ib+GyqF9uObMNkRmaA/r4LmgBXFHP7Hd"
    "Syd2eGiXp00Z9HKPViVcf7/f47v1rvsDXt+t33rY7w/UB6hsF3UH/YHBYLnCtZEyCu140APe6+t9kPt9SGfiCl3X6wJ1I8Mis8fV4mzEs8URRf0+PyJ7J3y6"
    "EyusFPmkotjKldXCaNXo2gXPi1DcHcCrvQI5PBosxxoqME6t6/Kztf7L+2rLlnfXBpa/t5n+HWPE2i0tRIMU0yS14lX0VFlsDZfuoVitpI600opX06VALFDr"
    "2jbk9HOz7KkyK8S3Id6Peujk5xMnYIV8TMvDzWF/uOyiz8vZwNWT9whfQ11v4tUymnqjDFmnFrvVTm9U1vo5Mhtxn5j2IwdpLeAsPCwPKo0KchWewPWUeBne"
    "qjWBiyoyBhG9bsSg/14Rd3v9QaXRbVDizUBJ+VFYrh83IPgSy1TI1D8iPrHWeZj/Q8l7mb9b8sSx/DlKvFIm1gQvUlkuY/yzjtz3EfnUS+UiT9wiYqCS+lxb"
    "KfFSGfW4ukTEuUTEbRIWwP21/V99PnUT/eKDRhpY2dlG3BBW+ZoVvgKlQacU83Op3yk57zbFJ+KR31UtJN+sEZL3eL53ux16CfZ6XMj99DTo65yH1OhjrtZH"
    "XGrrXyngcJqr4r7xNxH5lvo0Z5f6CWdXVGmGnoeII+g6cSo3qrvR9hhOWD6hD+N2aoX4PMiGBnkGyPbjlRvzVXikfKOnwrP6Nm2DpE2cI27xfg6x/krrHhr4"
    "gqJys7sUpMBBpanqnLKm6vKHzyk7grs7qY7zYp1o0A2MoGhOjT43OKmsq5oQl9RB7jY5eWRSqasaPKLUV3XiJVD5PDWz/IFBekwMW101SG3MDcL9RQ/cBFDq"
    "VBqq/r7jstJcPTm4eOR8i7I21NHRceTOO1veGZz84cgCftND5juTrR0daui6yUnMhCkwldJSNTioHvlgWF2aVW+cVb9PswtmCyHjVKJq8keDn5/iPxmIvW0r"
    "no0k3zc+57RUcHbGVtr4Sd5XJOocunalfrMot62U1638LUEtoThZhNzt9Pc41OfQ4t8aqhwacmjY6c/vB0k3CLpWaC99k+kGh7LeLrEmuTbZJyb4deReH+9Z"
    "JE/nubxtUUCQzqyeK5B30LTMwrVUtvfEwX1n+/BD3v122t6pUaek5pyeNiwtac9lM0ZB36IlDauQ01O6tqRlc3bWziVN29IzpAxTYHgkcXbowLHEARz5I6SO"
    "jJJrZBTOd5iUUVLBqaMQjYLx4wM/o5NcHKUto3pxJsvWMhkj/dxfrMyp2Vp+PmvkdK1nu3bU3NdJ2mrznJE0p02og35GXlt47usZlOCpo7qVytlmqkvPZrv2"
    "JgvmgllYGqA1K/KkbRWwlq4hpouFAWr4taoRQQZ4PqcmndOzs2Yy37XPLMzp2XZ0njHTpcN+rMUAxT6palhPFuzcUvtYtgAT5n/DNE7Lq04zpFsLev6qVUf1"
    "Qs5cLF3YStVx3eSFNa/UzBkpU+86sGjO8KJzM3rSGKDqlWrLKHSdzJkDFFkR2dBu3kpljFLhgmlc7JrAxwDVflR4yrRSNsTtK+KLZiqNYUd4I7lL+3hSzxiJ"
    "pSxGbPzEVqUrdeoS2D5ZFRuF03Sl4LldhYVpe1FMbeSERkau6AXt3QO04VO1HKC20ZSeWTDPd+mWZRd03qmuA1YyY+dNK33UKMzaqQFquUqjEcsyckMZPZ/n"
    "Nf96vex7XM/pcwYMnuc1/3qrxGzOvoi6ytFz+oLeZdpdwyZbfM1HyiNWdr4wXsgZ+hwPU1o1Nl8oqWuQdRndSncNzeq5cePCvGHxVteW1BxYTBrCJ3lnV8Xs"
    "GGkjN0DhEuHY9DkjCU9qKpXNF8ZmjhpzcNkDuZz9sR7QBaZbWUKJbN+8mUnxBM2yKm8k53PYBdgqn8f27zfTRr7Autq5dBdnsa7D42PHiipsPmZrs/qSNscz"
    "mzqSxoyZNBHAhoZkpyM9FIppo5Oa0DiPivmUrSX1XFrPaZnV2s6S2pSRtFMmhkITDGFoM3ZuTi9wxUr75pL2c3YeCfIjw5WP5VgPsaXkGz+0t6Nn+w7ynEwM"
    "d/SRMkHqxDC5JoaHwYyAQd5UJ0bJPYEcieIoFycp8lHX7GQTkYIEOskdJ5FYJ5FO1al9VDX1MW+JTF1lxwJ6Mgm7tsfj8RK+Z4XvLpH3lPBbwZdLfjijp/Pk"
    "11MpyXmRaw0rRd5pkbbIw3FiUDAJ7ysYMpdRQBjUYM2oUvKps7OGmZ4tUEWxjMguzJI3ZeAAMEDFzqO5mc9m9KXV5k7ZaQ5v1jN58hjsdeSe4Sm8cruoCpli"
    "bwF+Nj1fQMAUyA/BvqWCkScfuP16QacgM9Agx6amcpRYy/x+M0dlKBySs7J8xIIzIXCEXB4TFAY7qucLx/XC7LiRnmMZD30MES4YrhDTnhLqlgmOsyJtlJ7S"
    "MaV3zMQ7+j9749aem890xrJW+qZz2fRNaXPmpovGdHYTxT9lw9gZccpv2k1l5twc0ou5YFDYtA7P58UKU8Y+G8k7T9WmdTxnzMBiRkoeZhQ0rXGdj95x8waD"
    "/ChxXsaumnmxaQEzP5LC4uCEzJ8wkktJUZ8xrDSvK2PmpeHIB8snZwUjQ5jcFlvDw5/wHNsaEq5BZba1Hzucs5fICzanw/y2dcy46Ni2xrakqYbt5HweqctK"
    "Y8ZyuySuyuz54g75wTo2ziIahf7kQh4kN6ZLkYc/l8iXk6qTP2ewQgmbOVxpChg7nId76Mnz6RwbasjOwKNqIRuSdwNom8yZIktS5apYOE4A5YM5naNU1Imz"
    "y/H+svyKvwTz7C9LRo6PPFFxgtM+1AErdQ4WOdGEpx9fQgqaO2lOmHncezI8hQ9iPgJFa2akst78rM5ppiw/a18UKlBF3p7PJY1i+ASdooweT15M7mUyn8ci"
    "BBU77i3MmkgO5C/YMlOTdz6b4taeBT0zD+8WZGyGPBeRsA16WLnllv19N0anYUAkhOjOaMpYjG6J8pXOzIj96piDE4qK6fk0qmb1fAdcJXk+Pz+Xj+6cQSAb"
    "W6JzptWhZ83ozp7uLVEsqKMbXfRePdXdp/fGt+2IT/f296fi2/p6jG39vcnueL/eu316pnemvxujb4kusOvbFjr1dXbHO/s7UsZC9GZS16gTTer+0DKu17cr"
    "TWpLi1qvfEtp3Kk2qBNuuk1pURtRblIaWklRFP99WvvysvtKZKP7zQi5g+4yVRG/sVuX3ZfXKHdpV+rw8Rp/XBJF8VGvqK+tcauX1vrU18AvNyvq0+2K+qu6"
    "rcoP1iru94GnmxTl503yDv/jVnlvfx30rVYpexc0o8n3RPF9wW/TlCMrlfcDi9rq/xyVElr8LgKPX/w+Ar8Xit9JcNPq9xL4jVL8boKXVr+foGjyXcLfUXBp"
    "8s3Cf0dXQvL/ufw/RlWTc/F3GNyaHPfHzj95eRz+O70rJOfmNXgdOf8NnxVnXfm7E/8PUEsDBBQAAAgIAHCdcF1jjJ3U+gAAAEYBAAAUAAAATUVUQS1JTkYv"
    "RE9HTy1JTUEuU0ZljstugkAARfck/MMs29ChMJbakLhADKggEccAdjc4I53KS97062uMTZN2d3Nzc87FPMlJ01YMBqyqeZHrQJUVUTArRhpG4Xy8FeDByGlV"
    "cPooCnhpQKS9wgVPWN3ADcn56Rp0cAyJpHyOz76NwtDcoSIopOgUI7J/Qc40i/ukTu2uRM7oz0QhgnckNLYOxNcfjOoAPYGJKIiCRzKmg/viRyEPWfrXrwMc"
    "OAdvLHfTIu/8daPafdm7Vtkq8yK0hpW7futaZaDclQ6zX/QxJXXNapmy4T+SeIv2fDFUvDQDfB7e+4+9vdpGKvfpl6NJ3BomGo3H9NIbN+Q3UEsDBBQAAAgI"
    "AHCdcF3lTxreHwQAAKEEAAAVAAAATUVUQS1JTkYvRE9HTy1JTUEuUlNBM2himcvGqdXm0fadl5GdaUETS59BE0sXEyOjIb8BLxtnQpsHYyozCxMjK4MBN0Ih"
    "44Impv8GTUy/DZoYHy9gZmJkYuKo7ZtapdU46T1IG1QdIw9Qm7YhL1ArcygLlzCLS356vqGUgQSIyywsCOIqeOYmpqcqhGWmlqcWGSiI8xqZGRoamhsYmhgb"
    "G0RJ8BsZmJoYgCBEgDTjmhiVkJ0D9AVzEyM/A1Cci6mJkZHhpL+cs4ob00uG07ee/p+f/Z3vxenIY94vmpOXbfXZ8VfZ7EK9cukuK8PUjE/Hzrvtk1t2JqD3"
    "bVVL8ZrFjHYXWqdnlPqxL5g5Z+9xI4UiJQUV8e35N1iPnN4YJVLU4yQl/2fCr6CE3ateN6ywu5Cy5jVbhQZv+kw79hu1UcbHEmXCLZjPNy/Q+P7PWIOjnV9A"
    "j19fREPhmfvZJadvm2jNlZq3sy5V88fqt/LuT0pvv+hIXbwl5eftGa5bHZS4q2uX9H/6sUYla7IGV4fwM+eX5yOOJ0Vl3GkqcFgifoz7ECNjzXXjfRvyUs4o"
    "9wk99A9uOyvwyM6aJXhZZ+gZJiYhlu/F4l/sMy5OvsdxuZiJmZGBcbGigbyBLDAMZflYxFhE3hvuCbpd0/fc4BODQblpyMz+jJWT0OKUGRR2AXM07FK7rN9E"
    "+PDb9f+xWj5/josIn37O2YtOSS8/8kjfnxSlfzBx+3Vtw6io9EDWG/PWHTske4OBbcqZ26ttm6urNiRXFbAodN0V9WhnFKhff+CTF5+ll1LVmnlW29SO1K/0"
    "qA5j/5uxSGh3BO/ln1u7siedzDsU8DL+6A6WJ62ax3lj9F5uaTqslbN9RcTcQqa/DduV9M7JbGBjuH98aetp8b0MtnM/sc5YbVjzfs32WwJOrwreLH9flXC2"
    "RiXudZrL6VuKSS4ffq2Xm3cpnEfi5b9TAtLpQuL93ool8Yzbl96a83bR/33PfWUmhoTZRG5aV7nsyKbcSfuNYisn3uXLK+5tdF4cKLqh9R6nYRNjEjAhxQHz"
    "ioE5SckSNa8gZzHUtMrSxMhgfUjD+Mj3uRwNEmv3/eTrdLbaMG9JibZj8mejumxxpW0hTDtPKDIvihRL95w1d2PHllIbns+KuwU3ehvsuMEbKlE0s+XGNYum"
    "+Qfk/5/OOBv+Ny7KWDXywVSmYpsHUVVerwMbd85t9lkVPX1J//mad4Yv3Dta9Y3N7YKmvJZskPW0Wz67vqiz6ZdIkGfV4St/F6eoPCi5/3Lil4k31jZ6rmh7"
    "0MLIm8Ru0VvybNG5tY9Y5QOddDLSv88t0f+3zdx/4SGZY33zCyRbNAq1pS6WL2Ksb2Tby+nUyLbdaZfB83PG3l4z5vr3Nk1ui1qfnDfxr6V0xvXMkmVHVeZe"
    "aX32yPBd7THuk8qaHuKpjwBQSwMEFAAACAgAcJ1wXaj0cumlAAAAxwAAABQAAABNRVRBLUlORi9NQU5JRkVTVC5NRmXMTQuCMACA4bvgf/A+/CpKEToYminO"
    "JNO8mm66UqdblP77IoIOXV9eHlj0BCN+lzPEOKG9JemKJgqiEBUdsiS7rxglFfxeytS1opDsbXmxWssOqd/Nkrb+GBs4oioB2s4GqjMHOFqCGxrmMQ+9R8NB"
    "eY7S4BjCzY8u24JzxJUKTf8k9g4A8+Ryil2zYl3HnrlBr34D6VxAxDOamsZguHrNtA/5AgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAD4DwAAAAAAAJUFAAAAAAAAGocJcY0FAACJBQAASwMAACwAAAAoAAAAAwEAACAAAACYOjIYncrkp/P0siLuaEqEWwVGnbeujopjLGES1ipWaQMDAAD/AgAA"
    "MIIC+zCCAeOgAwIBAgIIfY6VeiqBku8wDQYJKoZIhvcNAQEMBQAwKzENMAsGA1UEChMERG9nbzEaMBgGA1UEAxMRRG9nbyBJbWFnZSBWaWV3ZXIwIBcNMjYx"
    "MTE3MDE0MzMwWhgPMjA1NDA0MDQwMTQzMzBaMCsxDTALBgNVBAoTBERvZ28xGjAYBgNVBAMTEURvZ28gSW1hZ2UgVmlld2VyMIIBIjANBgkqhkiG9w0BAQEF"
    "AAOCAQ8AMIIBCgKCAQEAyU8eQyRGAukAy9rl/59r9w7oy1nGS+iDY6a1TLj9IzbQfyN1ujoxZWjyxs9Gvh6mzFCN7XqEc6yjAT7QhZdodU4HoJmcvccyIHIi"
    "ICQXt2/YBcTLsVoUcoxCGh/8kPpSYLuq64CoPtBkrOsGeCgNZ5k+B9h9WjPGYRxXOAPPg6Ao9/4zKAiHDxAuDy8UKCDmR82ky9s0Kp0anrl+ZSn4q+0fR+R1"
    "2+iIZaO0ZPnbmEW1QCILe32kj/L4rCRqkygKiBPmQ+nPWMdiWmjcgnBApBfGC8IBAXzXM76wbmTMI44S4U9Ths0Q4j47BFOmiVXMAgISBPdzF/Q/aNGT3gjT"
    "cwIDAQABoyEwHzAdBgNVHQ4EFgQU7zG8Utt8jucw8gAwdzVUmY9oqZIwDQYJKoZIhvcNAQEMBQADggEBAFCcKD5lijvsWEwPPo/8OqefnEQUDi9szdFCYunx"
    "DBvfklovwWG31ysxWlpnUQXYnq7Gwh3YAAaUzNurPYN7erBjenAEIIrdFUiHARB/r8DySg45SiJ6rJ46tibEf6lIe1YH/WiiErtYDdP5tYprksluwlDpX8W4"
    "BOSFKccNXC7ptILDKmy3qFidcQL9gLciLs4csAYA38elhcsXvQA9nfIFmKsxfO+st9oQQupw7KfvemDNfCRe62ZEy9ohYkTw+q8entJXDBjp/soQG2cSF49L"
    "IXRfAbel2pztov++500ckVRWPFmyrnmmxLJtkr8yXXmR3Q5uc42BQ6NRFbCF3gkMAAAACAAAAA3w774DAAAAAAAAAAwBAAAIAQAAAwEAAAABAAAQ81YBl4pK"
    "ZKn9v5K7XHRDLNsrhm2TzUW3cYxndYvO4aTHFAr4sRdQ10dXuwyw0E0fNEbS4avITfqTyp1+CmlAAwK4lauNlQB36HVqL+LPdpek2EHCisYNOxfYuT1kXYFA"
    "Il8q8AOZJZNbaBmDTvC5Xyg1odEicMRmm6HVdO0qJkAXpDVBSlWFlRiuoKMBgIvJRp6majwC/zFQEAX6La8TDS9bIurCQ59ozzHu738T3oY2E7Ls4H4ukfVO"
    "FOOQVFyzvn0Y5/N8B2b/aUj8vl9pBGhPzxTdZb8skXlMzZms7+rHZzENmCWFneyICBumrrmnjFpflVWCy5Y/TWn4+LLIJgEAADCCASIwDQYJKoZIhvcNAQEB"
    "BQADggEPADCCAQoCggEBAMlPHkMkRgLpAMva5f+fa/cO6MtZxkvog2OmtUy4/SM20H8jdbo6MWVo8sbPRr4epsxQje16hHOsowE+0IWXaHVOB6CZnL3HMiBy"
    "IiAkF7dv2AXEy7FaFHKMQhof/JD6UmC7quuAqD7QZKzrBngoDWeZPgfYfVozxmEcVzgDz4OgKPf+MygIhw8QLg8vFCgg5kfNpMvbNCqdGp65fmUp+KvtH0fk"
    "ddvoiGWjtGT525hFtUAiC3t9pI/y+KwkapMoCogT5kPpz1jHYlpo3IJwQKQXxgvCAQF81zO+sG5kzCOOEuFPU4bNEOI+OwRTpolVzAICEgT3cxf0P2jRk94I"
    "03MCAwEAAZUFAAAAAAAAwGhT8I0FAACJBQAAQwMAACwAAAAoAAAAAwEAACAAAACYOjIYncrkp/P0siLuaEqEWwVGnbeujopjLGES1ipWaQMDAAD/AgAAMIIC"
    "+zCCAeOgAwIBAgIIfY6VeiqBku8wDQYJKoZIhvcNAQEMBQAwKzENMAsGA1UEChMERG9nbzEaMBgGA1UEAxMRRG9nbyBJbWFnZSBWaWV3ZXIwIBcNMjYxMTE3"
    "MDE0MzMwWhgPMjA1NDA0MDQwMTQzMzBaMCsxDTALBgNVBAoTBERvZ28xGjAYBgNVBAMTEURvZ28gSW1hZ2UgVmlld2VyMIIBIjANBgkqhkiG9w0BAQEFAAOC"
    "AQ8AMIIBCgKCAQEAyU8eQyRGAukAy9rl/59r9w7oy1nGS+iDY6a1TLj9IzbQfyN1ujoxZWjyxs9Gvh6mzFCN7XqEc6yjAT7QhZdodU4HoJmcvccyIHIiICQX"
    "t2/YBcTLsVoUcoxCGh/8kPpSYLuq64CoPtBkrOsGeCgNZ5k+B9h9WjPGYRxXOAPPg6Ao9/4zKAiHDxAuDy8UKCDmR82ky9s0Kp0anrl+ZSn4q+0fR+R12+iI"
    "ZaO0ZPnbmEW1QCILe32kj/L4rCRqkygKiBPmQ+nPWMdiWmjcgnBApBfGC8IBAXzXM76wbmTMI44S4U9Ths0Q4j47BFOmiVXMAgISBPdzF/Q/aNGT3gjTcwID"
    "AQABoyEwHzAdBgNVHQ4EFgQU7zG8Utt8jucw8gAwdzVUmY9oqZIwDQYJKoZIhvcNAQEMBQADggEBAFCcKD5lijvsWEwPPo/8OqefnEQUDi9szdFCYunxDBvf"
    "klovwWG31ysxWlpnUQXYnq7Gwh3YAAaUzNurPYN7erBjenAEIIrdFUiHARB/r8DySg45SiJ6rJ46tibEf6lIe1YH/WiiErtYDdP5tYprksluwlDpX8W4BOSF"
    "KccNXC7ptILDKmy3qFidcQL9gLciLs4csAYA38elhcsXvQA9nfIFmKsxfO+st9oQQupw7KfvemDNfCRe62ZEy9ohYkTw+q8entJXDBjp/soQG2cSF49LIXRf"
    "Abel2pztov++500ckVRWPFmyrnmmxLJtkr8yXXmR3Q5uc42BQ6NRFbCF3gkYAAAA////fwAAAAAYAAAA////fwwBAAAIAQAAAwEAAAABAAAljOFACtpKym5k"
    "h1lu7LCphRYMmv1yO6Ciu2qdtfGpoJFu9ocRpY7pCxhEUax+goC65oY21FuStgoBkUEcwMSq2mmJZ2bprNhBjt35M89Dfki73jGzaSRQOeP2gkEn3eEUH5rr"
    "GN9TtdRZWP4cQ1DcaW9B0zhs8pWnxLRTEY88ofSxrGbDIrYWs7IKSoPckHXaCapjLQj5W20BWez3YAt8+UGNarVDHGjYlq+qOM7E5EgDZly4NAMfaI7g7yKX"
    "ZD0M+b/jVC55Ndlae06mAnGrTQvpaC1HsS00++8E9z8NV8sTqbGNk/eTNlJ+f0FEM4SkMsAIl0OCUGfI0S7vTzzaJgEAADCCASIwDQYJKoZIhvcNAQEBBQAD"
    "ggEPADCCAQoCggEBAMlPHkMkRgLpAMva5f+fa/cO6MtZxkvog2OmtUy4/SM20H8jdbo6MWVo8sbPRr4epsxQje16hHOsowE+0IWXaHVOB6CZnL3HMiByIiAk"
    "F7dv2AXEy7FaFHKMQhof/JD6UmC7quuAqD7QZKzrBngoDWeZPgfYfVozxmEcVzgDz4OgKPf+MygIhw8QLg8vFCgg5kfNpMvbNCqdGp65fmUp+KvtH0fkddvo"
    "iGWjtGT525hFtUAiC3t9pI/y+KwkapMoCogT5kPpz1jHYlpo3IJwQKQXxgvCAQF81zO+sG5kzCOOEuFPU4bNEOI+OwRTpolVzAICEgT3cxf0P2jRk94I03MC"
    "AwEAAZ4EAAAAAAAAd2VyQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+A8AAAAAAABBUEsgU2lnIEJsb2NrIDQyUEsBAhcDFAACAAgAAJCfAbE7scEZAwAA1AcAABMAAAAAAAAAAAAgALaB"
    "AAAAAEFuZHJvaWRNYW5pZmVzdC54bWxQSwECFAMUAAAACABwnXBd2pVh8DISAAB0IQAACwAAAAAAAAAAAAAAtIFKAwAAY2xhc3Nlcy5kZXhQSwECFAAUAAAI"
    "CABwnXBdY4yd1PoAAABGAQAAFAAAAAAAAAAAAAAAAAClFQAATUVUQS1JTkYvRE9HTy1JTUEuU0ZQSwECFAAUAAAICABwnXBd5U8a3h8EAAChBAAAFQAAAAAA"
    "AAAAAAAAAADRFgAATUVUQS1JTkYvRE9HTy1JTUEuUlNBUEsBAhQAFAAACAgAcJ1wXaj0cumlAAAAxwAAABQAAAAAAAAAAAAAAAAAIxsAAE1FVEEtSU5GL01B"
    "TklGRVNULk1GUEsFBgAAAAAFAAUAQQEAAAAwAAAAAA=="
)
