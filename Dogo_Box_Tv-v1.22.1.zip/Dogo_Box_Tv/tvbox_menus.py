"""Optional settings menus; established action numbers remain unchanged."""
from tvbox import ask, bounded, bitrate, show, ToolError, ROOT, PROFILES
import tvbox_equipment as equipment
from tvbox_updates import Store, UpdateError


def equipment_menu(app):
    items = equipment.profiles(app)
    for index, item in enumerate(items, 1):
        print(f"{index}. {item['name']} · {', '.join(item['endpoints'])}")
    print("1 guardar actual · 2 conectar guardado · 3 añadir dirección · 4 eliminar perfil · 0 volver")
    action = ask("Acción", "0", bounded(0, 4))
    if action == 0:
        return
    if action == 1:
        show(equipment.save(app, ask("Nombre para este equipo", "")))
        return
    if not items:
        raise ToolError("Primero guarda un equipo.")
    item = items[ask("Fila de equipo", "1", bounded(1, len(items))) - 1]
    if action == 2:
        show(equipment.use(app, item["id"]))
    elif action == 3:
        show(equipment.add_endpoint(app, item["id"], ask("HOST:PUERTO o [IPv6%interfaz]:PUERTO", "")))
    elif ask("Eliminar solo el perfil guardado: 1 sí / 0 volver", "0", bounded(0, 1)):
        show(equipment.delete(app, item["id"]))


def quality_menu(app):
    current = app.stream_quality()
    print("Actual:", current)
    print("movil: 960 px / 15 FPS / 2 Mbps; fluido, equilibrado y nitido conservan sus valores anteriores.")
    name = ask("Perfil o 0 volver", current["profile"])
    if name == "0":
        return
    if name not in PROFILES:
        raise ToolError("Perfil desconocido.")
    chosen = dict(current) if current["profile"] == name else {"profile": name, **PROFILES[name]}
    chosen["max_size"] = ask("Lado mayor en píxeles", str(chosen["max_size"]), bounded(320, 3840))
    chosen["fps"] = ask("Límite FPS", str(chosen["fps"]), bounded(1, 60))
    chosen["bitrate"] = ask("Bitrate", str(chosen["bitrate"]), bitrate)
    show(equipment.set_quality(app, chosen))


def update_menu(app):
    print("1 revisar/aplicar ZIP local · 2 listar respaldos · 3 restaurar código anterior · 0 volver")
    action = ask("Acción", "0", bounded(0, 3))
    store = Store(ROOT, app.config_path)
    try:
        if action == 0:
            return
        if action == 2:
            show(store.backups())
        elif action == 1:
            path = ask("Ruta al ZIP de Dogo_Box_Tv", "")
            expected = ask("SHA256; vacío utiliza el archivo .sha256 junto al ZIP", "") or None
            plan, _ = store.inspect(path, expected)
            show(plan)
            if ask("Aplicar con respaldo: 1 sí / 0 volver", "0", bounded(0, 1)):
                if app.list_streams():
                    raise ToolError("Detén los directos antes de actualizar el código.")
                show(store.apply(path, expected))
        elif action == 3:
            show(store.backups())
            key = ask("Identificador del respaldo", "")
            if app.list_streams():
                raise ToolError("Detén los directos antes de restaurar el código.")
            show(store.rollback(key))
    except UpdateError as error:
        raise ToolError(str(error)) from error
