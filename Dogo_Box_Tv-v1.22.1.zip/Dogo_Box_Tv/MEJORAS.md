# Dogo_Box_Tv 1.22.1

Firma: H4ckZone_by_Dogo. Actualizado el 17 de noviembre de 2026.

## IPv6 al cambiar de red desde Android (1.22.1)

La opción **15** continúa con permisos básicos si el ADB local del teléfono no se puede recuperar. Conserva su vinculación, informa de la limitación y permite reconectarlo con **21 → 2**. La lista de interfaces medida al entrar se reutiliza para esa búsqueda, evitando un segundo intento inmediato contra el auxiliar desconectado.

Si Android bloquea multicast, falta ping IPv6 o se agota el tiempo, se conservan los vecinos conocidos y se marca el resultado como parcial. No se confunde una entrada en caché con una respuesta actual. Si solo aparece el teléfono, se explica la limitación y se indica **10** como alternativa IPv4.

No cambia el destino ADB elegido, no activa servicios y no borra la configuración del teléfono. Las restricciones de multicast, IPv6 o aislamiento entre clientes del router siguen pudiendo impedir el descubrimiento. La verificación del arreglo incluye casos Android simulados; no se ha ejecutado en el teléfono del propietario dentro de la red nueva.

## Interfaz fuego (1.22.0)

El menú adopta una paleta cálida de naranja, amarillo y texto claro. El tema `fuego` queda como predeterminado y se guardó también en la configuración de esta PC. Los demás temas y los ajustes personalizados siguen disponibles en **12**.

El encabezado muestra nombre, versión, firma y destino sin el dibujo anterior. Los números destacados y los nombres de las acciones se alinean en una sola columna, del 1 al 26. Desde 72 columnas se añade el área de cada acción. En ventanas más estrechas esa columna se oculta y los textos largos se ajustan dentro del marco.

Las preguntas incorporan un indicador de entrada y texto de ayuda secundario; los títulos de resultados usan el color del encabezado. Los resultados continúan al final y el menú solo vuelve a mostrarse con **m**. No cambian las funciones ni la numeración.

Se conserva la salida JSON sin decoración y el modo sin color. Reinicia el menú para ver la nueva versión.

## Visor universal de imágenes (1.21.0)

La opción 19 y `show-image` utilizan por defecto un visor Dogo incluido en el script. Se instala en el TV-box al primer envío, sin permisos de red o almacenamiento compartido. Ajusta la imagen completa al área de pantalla, conserva sus proporciones, centra el contenido sobre fondo negro y corrige orientación EXIF. La representación por software evita depender de la galería de fábrica.

Las imágenes grandes se decodifican con muestreo para limitar memoria. Se confirma el hash del archivo y el primer dibujo en pantalla; abrir una actividad por sí solo ya no cuenta como éxito. Las copias se transfieren directamente al espacio privado de la aplicación. El archivo original permanece intacto y las copias privadas anteriores se limpian después de confirmar un envío nuevo.

Se conserva `--viewer COMPONENTE` para elegir una galería instalada. La opción 20 reconoce ambos modos. Se admiten los formatos anteriores y el límite de 25 MiB; los formatos animados se muestran como imagen estática. Se requiere Android 5.0 o posterior, instalación de aplicaciones por ADB y `run-as` compatible.

## Resultados al final (1.20.4)

El menú se imprime una vez al entrar. Al terminar cada operación, su resultado queda al final seguido del campo de entrada, sin repetir el panel completo. **m** vuelve a mostrar el menú con el destino y las preferencias actuales; **0** conserva su función de salida. Los errores y Ctrl+C vuelven al campo de entrada manteniendo visibles los avisos.

## Menú de una columna (1.20.3)

Las opciones 1 a 26 se muestran siempre en una sola columna, con los números y textos alineados. La salida 0 utiliza la misma alineación. Se retiraron los accesos numéricos repetidos de la cabecera para simplificar la lectura.

## Orden numérico del menú (1.20.2)

El panel principal presenta las opciones 1 a 26 en orden de lectura, con una o dos columnas según el ancho de la terminal. La salida 0 permanece al final. Se conservan las funciones de cada número y sus colores.

## IPv6 del descubrimiento y puerto 5000 por IPv4 (1.20.1)

La opción 26 comprueba primero ADB y el puerto 5000 de la dirección elegida. Si ambos fallan por IPv6, relaciona la MAC observada con una IPv4 de la misma interfaz y comprueba su respuesta actual antes de enviar la orden de activación. Consulta los vecinos y las direcciones conocidas; cuando faltan candidatos, utiliza el descubrimiento IPv4 de esa interfaz conservando la lista IPv6 que se estaba mostrando.

Una MAC cambiada, una IPv4 reasignada, la ausencia de una relación comprobable o varias direcciones candidatas producen un mensaje para elegir la IPv4 explícitamente. La selección guardada solo cambia después de verificar ADB. La fila del propio ordenador se rechaza.

Los campos de entrada comparten el límite de 100 columnas de los otros cuadros y se ajustan al redimensionar. Se comprobó entrada real en una terminal de 180 columnas y después de reducirla a 48, con cuadros de 100 y 48 columnas respectivamente.

## Activación ADB por TCP 5000 (1.20.0)

1. Busca el equipo con **10** o **15**, o revisa su IP con **11**. Las listas predeterminadas de puertos TCP incluyen ahora 5000.
2. Elige **26. Activar ADB por puerto 5000** e indica la IP o la fila del TV-box.
3. El programa comprueba 5555. Si está cerrado, consulta el listado del servicio 5000 y registra la tarea fija para activar ADB, conservando las demás tareas.
4. Espera hasta 20 segundos a que abra 5555. La conexión se guarda después de verificar el estado ADB `device`.
5. Abre la shell con **18** o inicia el directo con **5**.

```bash
bash iniciar.sh enable-adb --host 192.168.0.116
bash iniciar.sh --json enable-adb --host 192.168.0.116 --timeout 30 --no-save
```

La función reconoce el arranque directo anterior y su propia tarea para evitar duplicados. Una tabla llena, un protocolo incompatible, un puerto que no abre o una autorización ADB pendiente conservan la selección previa. La activación es temporal, depende del servicio compatible del firmware y del ejecutable `/system/bin/adbd`; no modifica archivos de arranque. Si falla después del registro, el mensaje indica que la tarea permanece en el servicio y que se puede volver a comprobar sin duplicarla.

Las auditorías y los escaneos conservan su comportamiento de consulta. La opción 26 activa únicamente el destino elegido; las opciones anteriores mantienen sus números.

## Selector visual de imágenes (1.19.0)

1. Abre **19** y elige **1** para usar el selector visual.
2. En Android pulsa **Elegir imagen**: se abre la selección de fotos del sistema desde el navegador. Puedes usar Fotos, Colecciones o Explorar para localizar una imagen.
3. Revisa la vista previa y el nombre del archivo. Puedes cambiar de imagen o cancelar.
4. Pulsa **Enviar al TV**. El resultado del envío se muestra al finalizar y se intenta regresar a Termux.
5. Usa **20** para quitar de la pantalla del TV la imagen administrada por el script.

En un escritorio se abre un diálogo de archivos mediante Zenity, KDialog o Tkinter, según disponibilidad. Desde 1.21.0 el envío utiliza automáticamente el visor Dogo, tanto desde el escritorio como desde la selección Android.

**19 → 2** permite escribir o pegar la ruta como antes. El comando `show-image ARCHIVO` continúa funcionando. Los formatos admitidos siguen siendo PNG, JPEG, GIF y WebP, con un máximo de 25 MiB. La validación usa el contenido del archivo, no solo su nombre o el MIME indicado por el navegador.

La página Android es temporal y local: escucha únicamente en 127.0.0.1, exige una URL aleatoria y comprueba Host y Origin. No enumera archivos ni ofrece una URL para descargar imágenes. El navegador accede a la imagen que el usuario elige; el original se conserva. La copia temporal privada se elimina al terminar, cancelar o fallar. La página espera el resultado real del envío antes de indicar éxito.

El selector permanece disponible hasta cinco minutos para elegir y confirmar. Al cancelarlo vuelve al menú sin enviar. Si cierras todo el navegador, puedes volver a Termux y cancelar con Ctrl+C. Cuando Android no permite regresar automáticamente al terminal, utiliza el selector de aplicaciones.

Se verificó en el teléfono real: apertura del selector, vista previa, envío de una imagen de prueba PNG al TV con hash idéntico y retirada mediante la función existente. La regresión completa ejecutó 233 casos en Linux y 233 en Android, con 7 omitidos de escritorio en Android.

## Directo y calidad

La opción **5** conserva los perfiles `fluido`, `equilibrado` y `nitido` con sus valores anteriores. Añade `movil`: lado mayor de 960 píxeles, límite de 15 FPS y bitrate de 2 Mbps. El tamaño restante conserva la proporción; no significa 960p. Elegir el perfil no modifica un directo ya abierto.

La opción **23** permite guardar perfil, lado mayor, FPS y bitrate para el próximo directo. Si hay un equipo guardado activo, los ajustes pertenecen a ese equipo; en caso contrario, son ajustes generales del cliente. Los argumentos explícitos de comandos tienen prioridad. La configuración antigua sigue siendo válida y no se convierte al leerla.

La opción **9** muestra una muestra reciente de FPS y cuadros omitidos, obtenida del registro de scrcpy. Solo lee sus últimos 64 KiB. Se sugiere probar ajustes más ligeros cuando hay omisiones sostenidas; una imagen estática puede generar pocos FPS sin indicar lentitud o pérdida de red. Estos contadores no miden latencia de extremo a extremo ni identifican por sí solos la causa de las omisiones.

```bash
bash iniciar.sh quality
bash iniciar.sh quality --profile movil
bash iniciar.sh quality --profile movil --max-size 960 --fps 15 --bitrate 2M
bash iniciar.sh stream --profile fluido --background
```

## Equipos guardados

La opción **22** guarda el equipo actualmente seleccionado con nombre, direcciones, MAC cuando se conoce, número de serie observado, modelo y calidad. Requiere conexión para verificar la identidad. El destino se elige con las opciones existentes **10**, **15** y **17**.

```bash
bash iniciar.sh equipment save "TV de casa"
bash iniciar.sh equipment list
bash iniciar.sh equipment use "TV de casa"
bash iniciar.sh equipment endpoint "TV de casa" 192.168.0.101:3222
bash iniciar.sh equipment delete "TV de casa"
```

Una dirección adicional se guarda después de comprobar que devuelve el mismo número de serie. Se pueden conservar hasta ocho direcciones por equipo. Las IPv6 link-local conservan su `%interfaz`; si esa interfaz no existe en otra computadora se puede seguir consultando o eliminando el perfil, pero para conectarse se necesita una dirección utilizable allí.

`equipment save NOMBRE --offline` permite guardar una referencia sin conectar; queda sin identidad verificada y no habilita recuperación automática. `--overwrite` sustituye explícitamente un nombre existente. Eliminar un perfil conserva la selección actual y los archivos del usuario.

Al iniciar una operación, si falla la conexión del equipo guardado, se prueban como máximo tres de sus direcciones, con tiempo acotado y comprobación de número de serie. Una solicitud de autorización o una identidad distinta detienen la recuperación. No se descubre toda la red automáticamente. La recuperación ocurre al iniciar una operación; un directo que se haya cortado se vuelve a iniciar mediante **5**. El número de serie es una comprobación adicional de selección, no sustituye la autenticación ADB.

## Compatibilidad

La opción **24** comprueba conexión ADB, captura PNG en memoria, scrcpy y disponibilidad de visor. No guarda la captura ni inicia un directo. El resultado distingue qué comprobación falla.

```bash
bash iniciar.sh --json compatibility
bash iniciar.sh --json compatibility --encoders
```

La consulta opcional de codificadores usa `scrcpy --list-encoders`. La prueba no demuestra que una aplicación con contenido protegido vaya a poder capturarse; la confirmación final del vídeo se obtiene con **5**.

## Actualización y respaldo

La opción **25** revisa/aplica un ZIP local y permite restaurar el código anterior. Antes de aplicar muestra versión, SHA256 y cantidad de archivos. Debe estar detenido cualquier directo gestionado por el cliente.

```bash
bash iniciar.sh update inspect /ruta/Dogo_Box_Tv-v1.18.0.zip
bash iniciar.sh update apply /ruta/Dogo_Box_Tv-v1.18.0.zip
bash iniciar.sh update backups
bash iniciar.sh update rollback IDENTIFICADOR
```

Conserva el archivo `.sha256` junto al ZIP o indica `--sha256 HASH`. El hash comprueba integridad: utiliza un paquete y un hash obtenidos de una fuente confiable. El actualizador acepta el formato de los paquetes de este proyecto, comprueba sintaxis Python 3.10 y rechaza rutas fuera del proyecto, enlaces, duplicados y tamaños excesivos.

Los archivos reemplazados se respaldan en `.dogo-backups/IDENTIFICADOR`; la configuración tiene una copia privada de referencia. Se conservan la configuración activa, `.venv`, capturas y registros. Las acciones nuevas sobre perfiles/calidad guardan además la configuración previa en `backups-config/`, junto al archivo de configuración utilizado.

La restauración cambia el código y conserva la configuración actual. Se rechaza si hay ediciones posteriores del código que se sobrescribirían o si el respaldo no conserva su integridad. Ante un error de escritura o Ctrl+C durante aplicación/restauración se intenta revertir lo escrito; un apagado brusco no ofrece una transacción atómica de todo el proyecto. Conserva el respaldo para recuperación. Reinicia el programa después de actualizar o restaurar; los menús que ya estaban abiertos conservan los módulos cargados.

## Validación

La regresión completa mantiene las pruebas anteriores y añade casos de configuración antigua, varios equipos, identidad incorrecta, recuperación acotada, calidad independiente por equipo, registros grandes y actualización/restauración con fallos simulados.

En el teléfono del propietario se probaron primero los cambios en una carpeta separada. Funcionaron compatibilidad, captura en memoria, guardado/selección de equipo y arranque/cierre de los perfiles `fluido` y `movil`. Durante la comparación la pantalla estaba estática: se verificó el funcionamiento, pero no se midió una mejora de fluidez con vídeo en movimiento. Se mantienen disponibles ambos perfiles para comparar con el mismo contenido.
